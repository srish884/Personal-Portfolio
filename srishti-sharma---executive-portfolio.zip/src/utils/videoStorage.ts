// IndexedDB utility to store and retrieve executive intro video files
const DB_NAME = 'srishti_portfolio_video_db';
const STORE_NAME = 'videos';
const VIDEO_KEY = 'executive_intro_video';
const VIDEO_URL_STORAGE_KEY = 'srishti_portfolio_video_url';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveVideoFileToDB(file: File | Blob): Promise<string> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction([STORE_NAME], 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const putRequest = store.put(file, VIDEO_KEY);

    putRequest.onsuccess = () => {
      const blobUrl = URL.createObjectURL(file);
      resolve(blobUrl);
    };
    putRequest.onerror = () => reject(putRequest.error);
  });
}

export async function loadSavedVideoFromDB(): Promise<string | null> {
  // Check external URL first
  const externalUrl = localStorage.getItem(VIDEO_URL_STORAGE_KEY);
  if (externalUrl) {
    return externalUrl;
  }

  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const transaction = db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const getRequest = store.get(VIDEO_KEY);

      getRequest.onsuccess = () => {
        const result = getRequest.result;
        if (result instanceof Blob) {
          const blobUrl = URL.createObjectURL(result);
          resolve(blobUrl);
        } else {
          resolve(null);
        }
      };
      getRequest.onerror = () => resolve(null);
    });
  } catch (err) {
    console.error('Failed to load video from IndexedDB', err);
    return null;
  }
}

export async function clearSavedVideoFromDB(): Promise<void> {
  localStorage.removeItem(VIDEO_URL_STORAGE_KEY);
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const transaction = db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const deleteRequest = store.delete(VIDEO_KEY);
      deleteRequest.onsuccess = () => resolve();
      deleteRequest.onerror = () => resolve();
    });
  } catch (err) {
    console.error('Failed to clear video from DB', err);
  }
}

export function saveExternalVideoUrl(url: string): void {
  localStorage.setItem(VIDEO_URL_STORAGE_KEY, url);
}

export function getExternalVideoUrl(): string | null {
  return localStorage.getItem(VIDEO_URL_STORAGE_KEY);
}
