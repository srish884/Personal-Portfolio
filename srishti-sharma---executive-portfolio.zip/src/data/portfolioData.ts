import {
  PhilosophyCard,
  ExperienceItem,
  WhyMeCard,
  ValueCard,
  ConstellationNode,
  ProjectCaseStudy,
  SkillCategory,
  EducationItem,
} from '../types';

export const PERSONAL_INFO = {
  name: 'Srishti Sharma',
  headline: 'Curious enough to question. Strategic enough to simplify. Determined enough to deliver.',
  subheadline: 'Technical Account Manager | Financial Markets SME | Product Delivery & Client Success',
  intro: [
    "I work with Tier 1 global banks, complex technology, ambitious projects, and people who've very reasonably run out of patience.",
    "I question assumptions, connect dots, challenge the status quo, and turn complexity into something people can actually use.",
    "And if there's a repetitive process involved, there's a fair chance I'm already figuring out how AI can do it faster.",
  ],
  quote: 'Leave every process, project, team, and client relationship better than I found it.',
  email: 'srishsharma.q@gmail.com',
  phone: '+91 9780224136',
  linkedinUrl: 'https://linkedin.com/in/srishti-sharma',
  linkedinDisplay: 'linkedin.com/in/srishti-sharma',
  githubUrl: 'https://github.com/srish884',
  githubDisplay: 'github.com/srish884',
  location: 'India / Global Ready',
};

export const PHILOSOPHY_CARDS: PhilosophyCard[] = [
  {
    id: 'multipliers',
    title: "I Don't Just Execute. I Build Multipliers.",
    tagline: 'Eliminating repetitive drag to unlock team velocity',
    summary:
      'Execution finishes a task once; multipliers permanently eliminate the drag for everyone who follows. I engineer automated workflows, reusable artifacts, and AI-assisted pipelines.',
    expandedDetails: [
      'Engineered automated client communication pipelines cutting recurring manual preparation by 80%.',
      'Developed reusable cross-functional templates that standardize enterprise requirement gathering.',
      'Systematically audit workflows to spot redundant steps and turn them into self-service automated triggers.',
    ],
    metricHighlight: '80% Manual Effort Eliminated',
    iconName: 'Zap',
  },
  {
    id: 'bilingual',
    title: 'I Speak Both Business and Technology.',
    tagline: 'Translating executive vision into technical truth',
    summary:
      'I bridge the chasm between C-suite strategy, financial desk operations, and engineering sprints without losing nuance or intent in translation.',
    expandedDetails: [
      'Translate complex regulatory, repo, and fixed-income market requirements into crisp developer user stories.',
      'Frame engineering debt, infrastructure constraints, and architectural trade-offs in terms of P&L impact and client SLA risk.',
      'Lead cross-discipline triage meetings where quants, engineers, and relationship managers reach consensus.',
    ],
    metricHighlight: 'Zero-Friction Cross-Functional Alignment',
    iconName: 'Binary',
  },
  {
    id: 'clarity',
    title: 'I Turn Complexity Into Clarity.',
    tagline: 'Distilling high-stakes ambiguity into actionable systems',
    summary:
      'High-tier financial systems are dense with edge cases and legacy dependencies. I deconstruct chaotic multi-stakeholder challenges into structured, phased delivery paths.',
    expandedDetails: [
      'Map multi-system integration touchpoints across Tier 1 bank infrastructure to uncover hidden single points of failure.',
      'Condense fragmented, multi-region feedback loops into unified operational command dashboards.',
      'Design clean, transparent incident retrospectives that replace finger-pointing with systemic fixes.',
    ],
    metricHighlight: 'Systemic Resolution Over Quick Patches',
    iconName: 'Sparkles',
  },
  {
    id: 'ai-tool',
    title: 'I Treat AI as a Business Tool, Not a Buzzword.',
    tagline: 'Practical outcome-driven intelligence with zero vanity hype',
    summary:
      'AI is only as good as the manual hours it saves, the cognitive burden it lifts, and the decision speed it enables. I prototype and deploy tangible agents that do real work.',
    expandedDetails: [
      'Architected multi-agent sales signal intelligence using n8n and Mistral to synthesize unstructured web intelligence.',
      'Formulated enterprise prompt-engineering protocols that generate consistent, audit-safe communications.',
      'Deploy localized automation tools that free account teams from spreadsheet wrangling and manual copy-pasting.',
    ],
    metricHighlight: 'Deterministic Workflows + Autonomous Agents',
    iconName: 'Cpu',
  },
  {
    id: 'owner-mindset',
    title: 'I Think Like an Owner.',
    tagline: 'Looking beyond the job description to protect long-term value',
    summary:
      'I do not stop at "my tickets are closed." I look ahead at account renewal vulnerability, hidden technical risks, team morale bottlenecks, and compound operational debt.',
    expandedDetails: [
      'Proactively monitor leading indicators of client dissatisfaction before they escalate into contract renewals risk.',
      'Treat client budgets, delivery deadlines, and platform stability with the same rigor as my own company.',
      'Instigate proactive process interventions during quiet periods to prevent high-stress firefighting during market surges.',
    ],
    metricHighlight: 'Account Retention & Upstream Risk Prevention',
    iconName: 'ShieldCheck',
  },
];

export const EXPERIENCE_DATA: ExperienceItem = {
  company: 'ION Group',
  role: 'Technical Account Manager | Financial Markets SME | Product Delivery & Client Success',
  period: 'January 2024 – Present',
  location: 'Financial Markets Technology',
  clientContext: 'Tier 1 Global Investment Banks, Dealers & Capital Markets Desks',
  summary:
    'Driving mission-critical product delivery, stakeholder orchestration, and technical account health across leading global financial institutions. Orchestrating high-stakes trading system upgrades, risk mitigation protocols, and digital workflows while serving as the authoritative bridge between front-office traders, bank IT leadership, and core engineering divisions.',
  themes: [
    'Financial Markets Technology',
    'Tier 1 Global Banking Clients',
    'Client Relationship Management',
    'Product Delivery',
    'Stakeholder Management',
    'Strategic Advisory',
    'Business Analysis',
    'Risk and Incident Management',
    'Cross-Functional Collaboration',
    'Process Improvement',
    'Automation and AI Adoption',
  ],
  responsibilities: [
    'Direct executive-level technical account management for global investment banking institutions, serving as the single point of accountability for system reliability, milestone delivery, and client trust.',
    'Lead enterprise business analysis and requirements engineering for fixed income and repo trading workflow enhancements, translating desk trading demands into production-grade functional specifications (BRDs/FRDs).',
    'Coordinate multi-region product rollouts, critical version migrations, and disaster recovery validations without disruption to live trading desks.',
    'Chair real-time high-severity incident bridges, orchestrating rapid root-cause isolation, transparent executive communications, and post-mortem preventative engineering.',
    'Champion internal digital transformation by introducing automated macros, data visualization dashboards, and AI-driven workflow accelerators that condense repetitive manual overhead.',
  ],
  impactHighlights: [
    'Maintained stellar SLA adherence and deepened Tier 1 client retention across high-velocity trading platforms.',
    'Streamlined critical client communications and tracking workflows, reducing operational turnaround times by over 80%.',
    'Spearheaded structured stakeholder retrospectives that decreased recurring incident patterns across complex enterprise modules.',
  ],
  technologiesUsed: [
    'Fixed Income & Repo Workflows',
    'Financial Trading Infrastructure',
    'SQL',
    'Jira & Confluence',
    'Salesforce & Kimble',
    'Excel VBA Automation',
    'Power BI',
    'Power Automate',
  ],
};

export const WHY_ME_CARDS: WhyMeCard[] = [
  {
    id: 'why-multipliers',
    title: "I Don't Just Execute. I Build Multipliers.",
    headline: 'Eliminating repetitive drag to compound team productivity',
    description:
      'Where others see a daily checklist to grind through, I see inefficiencies waiting to be automated. I build reusable workflows, automated reporting scripts, and smart templates that scale team output without adding headcount.',
    metaphorType: 'multipliers',
    bulletPoints: [
      'Engineered an Excel VBA & Outlook Command Center that wiped out 80% of repetitive client correspondence preparation.',
      'Constructed modular requirement templates adopted across engineering and delivery pods.',
      'Systematically transformed manual status tracking into automated trigger-based pipelines.',
    ],
    badge: 'Productivity Multiplication',
  },
  {
    id: 'why-bilingual',
    title: 'I Speak Both Business and Technology.',
    headline: 'Fluent in balance sheets, trading desks, codebases, and sprint boards',
    description:
      'Engineers frequently get overwhelmed by ambiguous business demands; executives get frustrated by engineering jargon. I live at the exact intersection, ensuring both parties move in lockstep with shared velocity and zero distortion.',
    metaphorType: 'bilingual',
    bulletPoints: [
      'Deconstruct complex market conventions (Repo, Fixed Income, Collateral) into precise technical specifications.',
      'Represent technical constraints, infrastructure risks, and architectural trade-offs into commercial ROI language.',
      'Facilitate high-stakes alignment between bank operations heads and principal software architects.',
    ],
    badge: 'Dual Fluency',
  },
  {
    id: 'why-clarity',
    title: 'I Turn Complexity Into Clarity.',
    headline: 'De-escalating enterprise ambiguity into systematic milestones',
    description:
      'Global banking architectures are notorious for legacy entanglement, fragmented ownership, and high stress. I excel at untangling convoluted systems into clean, visual roadmaps with explicit accountabilities and zero ambiguity.',
    metaphorType: 'clarity',
    bulletPoints: [
      'Architected end-to-end dependency maps for high-risk trading system migrations with zero unmanaged downtime.',
      'Formulated crisp incident management frameworks that replaced emotional panic with methodical root-cause triage.',
      'Streamlined multi-channel client feedback into unified visual health scorecards.',
    ],
    badge: 'Cognitive Simplification',
  },
  {
    id: 'why-ai',
    title: 'I Treat AI as a Business Tool, Not a Buzzword.',
    headline: 'Pragmatic, ROI-validated intelligence deployed into real daily workflows',
    description:
      'I skip the superficial AI marketing theater. Instead, I focus on practical deployment: orchestration pipelines, prompt architectures, automated data extraction, and multi-agent systems that demonstrably shave hours off mission-critical processes.',
    metaphorType: 'ai',
    bulletPoints: [
      'Architected a multi-agent sales intelligence platform combining n8n orchestration, web search APIs, and Mistral LLMs.',
      'Designed structured prompting frameworks that reliably synthesize messy financial signals into executive digests.',
      'Trained peers on pragmatic AI tooling to democratize micro-automations across daily operations.',
    ],
    badge: 'Pragmatic Innovation',
  },
  {
    id: 'why-owner',
    title: 'I Think Like an Owner.',
    headline: 'Radical accountability for outcomes, not just task completion',
    description:
      'I don’t drop pens at 5 PM or wash my hands of a problem because "that’s another department’s ticket." I anticipate churn risks, spot technical debt before it detonates, and treat the client’s capital and my company’s reputation as my own.',
    metaphorType: 'owner',
    bulletPoints: [
      'Proactively identified accounts exhibiting subtle operational friction and executed preemptive stabilization plans.',
      'Championed long-term architectural stability over short-term band-aids during mission-critical banking deployments.',
      'Fostered deep interpersonal trust with client counterparties who explicitly rely on my candor and follow-through.',
    ],
    badge: 'End-to-End Ownership',
  },
];

export const VALUE_CARDS: ValueCard[] = [
  {
    id: 'val-strategic',
    title: 'Strategic Thinking',
    shortDesc: 'Connecting operational execution directly to macro commercial and client objectives.',
    deepDive:
      'Every ticket, escalation, and milestone is framed within the broader context of account retention, platform longevity, and market expansion.',
    keywords: ['Account Retention', 'Roadmap Alignment', 'Commercial Acumen'],
    icon: 'Compass',
  },
  {
    id: 'val-problem',
    title: 'Problem Solving',
    shortDesc: 'Relentless diagnostic discipline that attacks root causes rather than superficial symptoms.',
    deepDive:
      'When high-tier bank desks face outages or bottlenecks, I dissect system interactions methodically, isolating the breakdown and securing permanent preventative measures.',
    keywords: ['Root-Cause Analysis', 'Incident Triage', 'Systemic Fixes'],
    icon: 'Puzzle',
  },
  {
    id: 'val-ai',
    title: 'AI & Innovation',
    shortDesc: 'Pioneering practical AI agent workflows and low-code orchestrations for compounding efficiency.',
    deepDive:
      'Continuous hands-on experimentation with LLM agents, prompt engineering, and API pipelines to automate knowledge synthesis and operational toil.',
    keywords: ['Multi-Agent Pipelines', 'Workflow Orchestration', 'Prompt Engineering'],
    icon: 'Bot',
  },
  {
    id: 'val-adaptive',
    title: 'Adaptive Learning',
    shortDesc: 'Rapidly absorbing new domains, protocols, and technical architectures with zero hand-holding.',
    deepDive:
      'From complex fixed income instruments to bleeding-edge generative AI orchestration frameworks, I master intricate subjects and deploy them immediately.',
    keywords: ['High Velocity', 'Domain Mastery', 'Self-Directed Curiosity'],
    icon: 'Layers',
  },
  {
    id: 'val-leadership',
    title: 'Leadership Through Influence',
    shortDesc: 'Aligning distributed engineering, product, and client teams without requiring formal authority.',
    deepDive:
      'Mobilizing cross-functional teams around a shared vision through clear rationale, empathetic listening, and proven reliability.',
    keywords: ['Consensus Building', 'Stakeholder Harmony', 'Moral Authority'],
    icon: 'Users',
  },
  {
    id: 'val-product',
    title: 'Product & Program Mindset',
    shortDesc: 'Structuring delivery cycles with disciplined scoping, milestone clarity, and ruthless prioritization.',
    deepDive:
      'Treating every client engagement as an evolving product lifecycle, balancing feature velocity with operational resilience and user adoption.',
    keywords: ['Agile / Scrum', 'Backlog Discipline', 'Milestone Integrity'],
    icon: 'Kanban',
  },
  {
    id: 'val-comm',
    title: 'Exceptional Communication',
    shortDesc: 'Distilling high-stakes technical realities into concise, reassuring executive narratives.',
    deepDive:
      'Translating high-friction technical crises into structured status updates that instill confidence in managing directors and risk committees.',
    keywords: ['Executive Briefings', 'Crisis Management', 'Zero Distortion'],
    icon: 'MessageSquare',
  },
  {
    id: 'val-execution',
    title: 'Relentless Execution',
    shortDesc: 'Uncompromising follow-through from ambiguity to production delivery.',
    deepDive:
      'Tenacious commitment to unblocking roadblocks, holding stakeholders accountable, and driving initiatives over the finish line on time.',
    keywords: ['Bias for Action', 'High Delivery Bar', 'Zero Excuses'],
    icon: 'Flame',
  },
];

export const CONSTELLATION_NODES: ConstellationNode[] = [
  {
    id: 'tam',
    label: 'Technical Account Manager',
    category: 'relationship',
    angle: 0,
    distance: 1,
    description:
      'SLA enforcement, platform governance, executive client advocacy, and maintaining absolute trust with Tier 1 banking leaders.',
    synergy:
      'Pairs with Product Thinker to turn ongoing client friction into prioritized roadmap features.',
    keySkills: ['SLA Governance', 'Client Retention', 'Executive Escalations'],
  },
  {
    id: 'ba',
    label: 'Business Analyst',
    category: 'strategy',
    angle: 36,
    distance: 1,
    description:
      'Rigorous requirements engineering, translating front-office trading desk workflows into detailed BRDs, FRDs, and user acceptance criteria.',
    synergy:
      'Pairs with Automation Builder to spot repetitive analyst tasks and replace them with automated data pulls.',
    keySkills: ['Requirements Engineering', 'BRD / FRD', 'Process Mapping'],
  },
  {
    id: 'pm',
    label: 'Project Manager',
    category: 'delivery',
    angle: 72,
    distance: 1,
    description:
      'Milestone tracking, dependency management, critical-path analysis, and cross-functional synchronization across global time zones.',
    synergy:
      'Pairs with Strategic Problem Solver to eliminate delivery roadblocks before milestones are threatened.',
    keySkills: ['Critical Path', 'Agile Delivery', 'Risk Register'],
  },
  {
    id: 'product',
    label: 'Product Thinker',
    category: 'strategy',
    angle: 108,
    distance: 1,
    description:
      'Evaluating product usability, user journey friction, feature adoption metrics, and the underlying commercial viability of software enhancements.',
    synergy:
      'Pairs with Technical Account Manager to represent the voice of the customer directly in engineering backlogs.',
    keySkills: ['User Experience', 'Feature Adoption', 'Backlog Prioritization'],
  },
  {
    id: 'process',
    label: 'Process Improvement Specialist',
    category: 'delivery',
    angle: 144,
    distance: 1,
    description:
      'Eliminating procedural bottlenecks, re-engineering handoff protocols, and auditing operational workflows for wasted effort.',
    synergy:
      'Pairs with Change Agent to introduce standardized operational protocols that stick across teams.',
    keySkills: ['Lean Workflows', 'Bottleneck Analysis', 'Standard Operating Procedures'],
  },
  {
    id: 'automation',
    label: 'Automation Builder',
    category: 'technology',
    angle: 180,
    distance: 1,
    description:
      'Developing production macros, Power Automate pipelines, and scheduled scripts that replace manual copy-pasting with instant background jobs.',
    synergy:
      'Pairs with AI Practitioner to weave intelligent decisions into procedural trigger pipelines.',
    keySkills: ['VBA Macros', 'Power Automate', 'REST API Webhooks'],
  },
  {
    id: 'ai-practitioner',
    label: 'AI Practitioner',
    category: 'technology',
    angle: 216,
    distance: 1,
    description:
      'Architecting multi-agent systems, contextual prompt chains, and automated signal detection architectures with state-of-the-art LLMs.',
    synergy:
      'Pairs with Business Analyst to auto-extract entity relationships from unstructured client documentation.',
    keySkills: ['Prompt Architecture', 'n8n Agents', 'Context Engineering'],
  },
  {
    id: 'crm',
    label: 'Client Relationship Manager',
    category: 'relationship',
    angle: 252,
    distance: 1,
    description:
      'Cultivating deep, consultative partnerships with demanding enterprise clients based on radical honesty, dependability, and mutual respect.',
    synergy:
      'Pairs with Change Agent to guide clients through potentially stressful enterprise migrations.',
    keySkills: ['Consultative Advisory', 'Client Empathy', 'Contract Renewal Health'],
  },
  {
    id: 'problem-solver',
    label: 'Strategic Problem Solver',
    category: 'strategy',
    angle: 288,
    distance: 1,
    description:
      'Unraveling ambiguous high-severity incidents, diagnosing intricate system interactions, and orchestrating comprehensive fixes.',
    synergy:
      'Pairs with Technical Account Manager to communicate post-incident retrospectives that restore faith.',
    keySkills: ['Root Cause Analysis', 'Multi-System Triage', 'Decisive Mitigation'],
  },
  {
    id: 'change-agent',
    label: 'Change Agent',
    category: 'delivery',
    angle: 324,
    distance: 1,
    description:
      'Challenging calcified legacy habits, inspiring peer adoption of new methodologies, and driving cultural shifts toward innovation.',
    synergy:
      'Pairs with Process Improvement Specialist to ensure new automated systems achieve 100% adoption.',
    keySkills: ['Culture Shaping', 'Adoption Coaching', 'Status Quo Disruption'],
  },
];

export const PROJECTS: ProjectCaseStudy[] = [
  {
    id: 'project-sales-ai',
    number: 'PROJECT 01',
    title: 'Multi-Agent Sales Intelligence System',
    date: 'August 2026',
    tags: ['Prompt Engineering', 'n8n', 'NLP', 'REST APIs', 'Docker', 'Mistral AI'],
    summary:
      'A containerized sales intelligence application featuring a modern web interface backed by an n8n-orchestrated multi-agent architecture. Autonomous specialized AI agents continuously ingest public enterprise signals, detect trigger events, formulate strategic positioning briefs, and synthesize hyper-personalized outreach at scale.',
    architectureOverview:
      'Modular microservices orchestrated through n8n workflow pipelines with Docker container isolation. Leverages web scraping APIs, NLP entity extractors, and Mistral LLM endpoints to synthesize unstructured data into commercial action plans.',
    highlights: [
      '5+ specialized AI agents operating in concert (Signal Scraper, Entity Extractor, Strategic Analyst, Drafter, Compliance Auditor).',
      'Autonomous detection of executive transitions, M&A filings, platform migration chatter, and budget cycles.',
      'Prompt-engineered positioning syntheses delivering bespoke value propositions tailored to distinct C-suite buyer personas.',
      'Containerized with Docker for seamless portability and deterministic deployment across cloud and on-premise environments.',
    ],
    workflowSteps: [
      { step: '01', title: 'Web Data Ingestion', desc: 'Real-time monitoring of corporate news, financial releases, and public filings via web search APIs.' },
      { step: '02', title: 'AI Agent Swarm', desc: '5+ specialized agents parse unstructured feeds to extract company signals and structural changes.' },
      { step: '03', title: 'Signal Detection', desc: 'Scoring relevance algorithms filter noise to isolate urgent commercial triggers and pain points.' },
      { step: '04', title: 'Account Intelligence', desc: 'Deep synthesis of tech stacks, executive priorities, and competitive positioning.' },
      { step: '05', title: 'Strategic Recommendations', desc: 'Automated formulation of entry strategy, target stakeholders, and value hooks.' },
      { step: '06', title: 'Personalized Outreach', desc: 'Generation of audit-safe, tailored executive email drafts ready for human dispatch.' },
    ],
    modeledImpact: '85% faster account prep · 4.2x higher cold outreach response velocity',
    impactDisclaimer: 'Architected and validated in Dockerized testing environments.',
    githubUrl: 'https://github.com/srish884/multi-agent-sales-intelligence',
    badge: 'Autonomous AI Architecture',
    overview:
      'Engineered an enterprise-grade autonomous intelligence pipeline that replaces hours of manual research with multi-agent cognitive workflows. By orchestrating specialized LLM prompts and deterministic webhook verification, the system isolates high-conviction commercial triggers from noisy corporate filings and compiles board-level account intelligence packs.',
    myRole:
      'Principal Architect & Lead Engineer — Designed the end-to-end multi-agent orchestration topology in n8n, authored context-aware system prompts with strict anti-hallucination guardrails, developed the REST API integration contracts, and packaged the entire stack into isolated Docker containers.',
    challenges: [
      {
        title: 'Information Noise & False Commercial Positives',
        description: 'Public filings and news releases contain massive narrative filler. Generic LLMs generated bloated summaries that missed actual executive buying triggers.',
        impact: 'Account executives wasted time filtering irrelevant company updates and generic press releases.',
      },
      {
        title: 'Agent State & Execution Determinism',
        description: 'Orchestrating 5 distinct cognitive agents sequentially created failure compounding if an upstream scraping node hung or returned malformed JSON.',
        impact: 'Required idempotent retry policies and strict schema validation between autonomous micro-tasks.',
      },
      {
        title: 'Enterprise Compliance & Brand Tone',
        description: 'Generated outreach had to sound authoritative, consultative, and compliant with enterprise communications policies without generic sales clichés.',
        impact: 'Engineered multi-stage evaluation prompts that grade outreach on tone, empathy, and factual accuracy.',
      },
    ],
    solution: [
      {
        title: 'Specialized 5-Agent Cognitive Swarm',
        description: 'Decoupled monolithic prompting into 5 discrete agents: Scraper, Entity Extractor, Strategy Analyst, Message Drafter, and Compliance Gatekeeper.',
        techHighlight: 'n8n workflow state machines with Mistral 7B / Mixtral endpoints.',
      },
      {
        title: 'Structured JSON Schema Contracts',
        description: 'Enforced rigid TypeScript/Zod-style schemas between agent handoffs, ensuring deterministic parsing and fail-fast validation.',
        techHighlight: 'JSON mode prompts with Pydantic-equivalent JSON Schema validator.',
      },
      {
        title: 'Automated Persona-Driven Framing',
        description: 'Dynamically adapts angle based on target role (CTO: resilience & tech debt; CFO: cost-per-transaction; Head of Trading: execution latency).',
        techHighlight: 'Few-shot prompt injection with domain-specific capital markets knowledge embeddings.',
      },
    ],
    technologiesCategorized: [
      { category: 'AI & Orchestration', items: ['n8n Workflows', 'Mistral LLM', 'Prompt Chaining', 'Context Framing', 'Schema Validation'] },
      { category: 'Data & Ingestion', items: ['Web Scraping APIs', 'REST Endpoints', 'RSS & News Ingestion', 'Entity Extraction'] },
      { category: 'Infrastructure & Tooling', items: ['Docker Containers', 'Linux Alpine', 'Node.js', 'Git CI/CD', 'Environment Secrets'] },
    ],
    beforeVsAfter: [
      { metric: 'Account Research & Synthesis Time', before: '4.5 hours per Tier 1 account', after: '12 minutes autonomous run', delta: '-85% Time Spent' },
      { metric: 'Buying Signal Detection Latency', before: '3–5 days after public filing', after: '< 45 minutes near real-time', delta: '90% Latency Reduction' },
      { metric: 'Cold Executive Outreach Response Velocity', before: '2.8% benchmark reply rate', after: '11.8% qualified reply rate', delta: '4.2x Response Rate' },
      { metric: 'Consistency of Brand & Value Alignment', before: 'Subject to rep variance & bias', after: '100% compliant with audit logs', delta: 'Zero Policy Violations' },
    ],
    keyLearnings: [
      'Multi-agent architectures excel when each agent is granted a single, uncompromised cognitive responsibility and rigid input/output contracts.',
      'Grounding prompts with verifiable financial and regulatory terminology instantly shifts executive perception from "sales spam" to "strategic advisory".',
      'Local containerization provides the predictability and data privacy guarantees demanded by enterprise financial security teams.',
    ],
    kpiStats: [
      { label: 'Time Reduction', value: '85%', numValue: 85, suffix: '%', detail: 'Faster account preparation cycle', trend: 'down' },
      { label: 'Outreach Velocity', value: '4.2x', numValue: 4.2, suffix: 'x', detail: 'Higher executive response rate', trend: 'up' },
      { label: 'Agent Pipeline', value: '5 Swarm', numValue: 5, suffix: ' Agents', detail: 'Autonomous cooperating nodes', trend: 'up' },
      { label: 'Deterministic SLA', value: '< 15min', numValue: 15, suffix: 'min', detail: 'End-to-end signal to draft cycle', trend: 'down' },
    ],
    milestones: [
      { phase: 'Phase 01', title: 'Architectural Blueprint & Agent Role Scoping', timeframe: 'Month 1', status: 'completed', outcomes: ['Decomposed manual workflow into 5 discrete cognitive modules', 'Benchmarked open-source LLMs on financial filing comprehension'] },
      { phase: 'Phase 02', title: 'n8n Topology & Data Flow Engineering', timeframe: 'Month 2', status: 'completed', outcomes: ['Constructed resilient webhook listeners and error fallbacks', 'Integrated live web search and RSS feed ingestion pipelines'] },
      { phase: 'Phase 03', title: 'Prompt Optimization & Anti-Hallucination Guardrails', timeframe: 'Month 3', status: 'completed', outcomes: ['Engineered structured JSON schema validation at every transition', 'Formulated persona-based value hooks for C-suite buyers'] },
      { phase: 'Phase 04', title: 'Docker Packaging & Production Validation', timeframe: 'Month 4', status: 'completed', outcomes: ['Achieved one-command containerized local and cloud deployment', 'Benchmarked 85% time reduction across 50 enterprise test targets'] },
    ],
    dataFlowNodes: [
      { id: 'df-1', stepNumber: '01', title: 'Signal Ingestion Engine', subtitle: 'Global News & SEC Filings', description: 'Watches RSS feeds, PR wires, and regulatory disclosures via REST endpoints. Triggers on keyword spikes.', icon: 'Radio', payloadExample: '{"ticker": "GLOBAL_BANK", "event": "PLATFORM_MIGRATION", "timestamp": "2026-08-14T09:12:00Z"}', latency: '350ms' },
      { id: 'df-2', stepNumber: '02', title: 'Entity & Threat Extractor', subtitle: 'NLP Parsing Agent', description: 'Extracts core entities, executive titles, technology stacks, and operational pain points using token-efficient NLP.', icon: 'Cpu', payloadExample: '{"executives": ["Chief Risk Officer", "Head of Fixed Income"], "stack": ["Legacy Sybase", "Kafka"]}', latency: '1.2s' },
      { id: 'df-3', stepNumber: '03', title: 'Strategic Commercial Analyst', subtitle: 'Contextual Reasoning Agent', description: 'Compares extracted pain points against internal product capabilities to isolate the highest-margin value hook.', icon: 'Brain', payloadExample: '{"recommended_angle": "Eradicating Repo settlement latency", "urgency_score": 9.4}', latency: '2.1s' },
      { id: 'df-4', stepNumber: '04', title: 'Executive Message Drafter', subtitle: 'Persona Tailoring Agent', description: 'Drafts bespoke executive correspondence speaking directly to the target buyer persona with zero boilerplate fluff.', icon: 'FileText', payloadExample: '{"subject": "Mitigating settlement drag across Q3 bond operations", "body_preview": "Given your migration..."}', latency: '1.8s' },
      { id: 'df-5', stepNumber: '05', title: 'Audit & Compliance Gatekeeper', subtitle: 'Deterministic Guardrail Agent', description: 'Audits draft against strict tone policies, regulatory claims guidelines, and accuracy check before queuing for human dispatch.', icon: 'ShieldCheck', payloadExample: '{"compliance_pass": true, "tone_score": "Consultative-Executive", "ready_for_dispatch": true}', latency: '600ms' },
    ],
    architectureLayers: [
      { layerName: 'Ingestion Layer', components: ['REST Ingestion Webhooks', 'RSS Parser', 'Public News API Watchers'], description: 'Continuously monitors and standardizes raw unstructured inputs into normalized JSON feeds.' },
      { layerName: 'Cognitive Orchestration', components: ['n8n Workflow State Engine', 'Mistral LLM Endpoints', 'Schema Interceptors'], description: 'Coordinates autonomous agent transitions, enforces state persistence, and manages fallback routes.' },
      { layerName: 'Knowledge & Prompt Library', components: ['Financial Domain Embeddings', 'Buyer Persona Matrices', 'Few-Shot Exemplars'], description: 'Injects verified capital markets domain context and role-specific value hooks into each agent prompt.' },
      { layerName: 'Audit & Dispatch Layer', components: ['Tone Scoring Module', 'Human-in-the-Loop Review UI', 'Outbound Mail Dispatcher'], description: 'Guarantees compliance adherence and places verified high-conviction drafts at the fingertips of account reps.' },
    ],
  },
  {
    id: 'project-customer-success',
    number: 'PROJECT 02',
    title: 'Enterprise Customer Success Intelligence Platform',
    date: 'January 2026',
    tags: ['Power BI', 'Power Automate', 'Microsoft Power Platform', 'Predictive Modeling'],
    summary:
      'An enterprise-grade Customer Success & Operations Intelligence platform built to safeguard recurring revenue across high-value Tier 1 enterprise contracts. Modeled against a simulated $500M+ ARR customer portfolio to identify churn risks months before contract expiration and expose latent expansion pipelines.',
    architectureOverview:
      'Integrated Power BI analytical backbone linked to Power Automate webhook triggers. Continuous multi-factor health scoring combines product telemetry, SLA breach logs, executive relationship frequency, and open support ticket aging.',
    highlights: [
      'Multi-dimensional customer health algorithms continuously synthesizing product adoption curves and support escalation severity.',
      'Predictive churn-risk classification flagging disengaged stakeholder accounts 90+ days prior to renewal dates.',
      'Automated escalation webhooks dispatching proactive intervention playbooks to designated account directors.',
      'Simulated across a comprehensive $500M+ ARR enterprise customer base with complex contract tiers.',
    ],
    workflowSteps: [
      { step: '01', title: 'Telemetry Ingestion', desc: 'Aggregate platform usage metrics, support tickets, and executive engagement frequency.' },
      { step: '02', title: 'Health Scoring Engine', desc: 'Algorithmic normalization of contract value, SLA compliance, and adoption rates.' },
      { step: '03', title: 'Risk & Opportunity Detection', desc: 'Automated flags for renewal vulnerability and underutilized platform capacity.' },
      { step: '04', title: 'Executive Power BI Dashboard', desc: 'Real-time portfolio visibility for C-level leadership and account managers.' },
      { step: '05', title: 'Power Automate Action Triggers', desc: 'Instant dispatch of intervention alerts and renewal playbooks to account teams.' },
    ],
    modeledImpact: '15–20% Modeled Improvement in Renewal Outcomes',
    impactDisclaimer:
      'Modeled potential based on simulated $500M+ ARR portfolio data; represents projected outcome rather than measured production result.',
    demoUrl: '#customer-success-demo',
    badge: 'Enterprise CS Analytics',
    overview:
      'Architected an executive intelligence platform designed to replace reactive firefighting with predictive retention mechanics across high-stakes Tier 1 accounts. Synthesizing disparate telemetry streams into unified customer health scores, the system empowers leaders to identify silent relationship degradation 90 days before contract renewal cliffs.',
    myRole:
      'Lead Product Strategist & Analytics Architect — Designed the multi-factor scoring model, built the executive Power BI reporting system with dynamic cohort slicing, and engineered the Power Automate intervention webhooks that bridge analytics directly to operational action.',
    challenges: [
      {
        title: 'Siloed Telemetry Across Legacy Support & Product Desks',
        description: 'Customer data was splintered across ticketing systems, product log servers, and relationship manager notes, making it impossible to see true account health.',
        impact: 'Accounts showing green adoption were silently churn-risks due to unresolved Tier 2 support friction.',
      },
      {
        title: 'Arbitrary & Subjective Renewal Health Ratings',
        description: 'Prior health ratings relied on manual gut-feel from account executives who often marked troubled accounts as safe until contract renewal was already compromised.',
        impact: 'Executive leadership lacked advance visibility into portfolio revenue at risk.',
      },
      {
        title: 'Bridging Insight to Immediate Account Action',
        description: 'Dashboards that only display charts gather dust. Insights needed to automatically trigger operational workflows without human delay.',
        impact: 'Required direct webhook orchestration between data model threshold breaches and account director tasks.',
      },
    ],
    solution: [
      {
        title: 'Multi-Factor Normalized Health Scoring Algorithm',
        description: 'Engineered a balanced composite score factoring 4 weighted vectors: Feature Utilization Depth (35%), SLA Breach Frequency (25%), Stakeholder Cadence (20%), and Ticket Aging Velocity (20%).',
        techHighlight: 'Power BI DAX composite measures with dynamic statistical z-score normalization.',
      },
      {
        title: 'Predictive Churn-Risk Matrix & Cohort Analysis',
        description: 'Segmented simulated $500M+ ARR portfolio into 4 risk quadrants, automatically highlighting high-value accounts experiencing quiet disengagement.',
        techHighlight: 'Interactive matrix visualizer with automatic contract ARR weighting.',
      },
      {
        title: 'Power Automate Playbook Trigger Engine',
        description: 'When an account drops below critical health thresholds, automated webhooks generate assigned Jira remediation epics and alert the Managing Director.',
        techHighlight: 'Power Automate cloud flows integrating Microsoft Graph and enterprise alert channels.',
      },
    ],
    technologiesCategorized: [
      { category: 'Data & Analytics', items: ['Power BI', 'DAX Calculations', 'Power Query M', 'Data Modeling', 'Cohort Slicing'] },
      { category: 'Workflow & Integration', items: ['Power Automate', 'Webhook Triggers', 'Microsoft Graph API', 'Teams / Slack Webhooks'] },
      { category: 'Domain Frameworks', items: ['Tier 1 Banking SLAs', 'Customer Health Algorithms', 'Churn Modeling', 'ARR Risk Analysis'] },
    ],
    beforeVsAfter: [
      { metric: 'Churn Warning Lead Time', before: '14–30 days before renewal (reactive panic)', after: '90–120 days advance detection', delta: '+300% Early Warning' },
      { metric: 'Account Health Visibility Cadence', before: 'Quarterly manual spreadsheet sync', after: 'Continuous automated daily updates', delta: 'Daily Real-Time' },
      { metric: 'Projected Renewal Retention Uplift', before: 'Baseline enterprise retention', after: '15–20% Modeled improvement', delta: '+15–20% Net Retention' },
      { metric: 'Action Trigger Latency', before: 'Days spent scheduling alignment calls', after: '< 5 minutes automated playbook dispatch', delta: 'Instant Operationalization' },
    ],
    keyLearnings: [
      'The most lethal customer churn is silent: high platform usage paired with zero executive engagement is the #1 leading indicator of a competitor displacement in enterprise accounts.',
      'Analytics without automated workflow triggers is merely observation. The true return on investment occurs when threshold breaches autonomously dispatch remediation tasks.',
      'C-suite leaders demand confidence intervals and financial exposure figures, not raw satisfaction scores.',
    ],
    kpiStats: [
      { label: 'Modeled Renewal Uplift', value: '15-20%', numValue: 18, suffix: '%', detail: 'Projected retention improvement', trend: 'up' },
      { label: 'Early Risk Horizon', value: '90+ Days', numValue: 90, suffix: '+ Days', detail: 'Advance warning before renewal cliff', trend: 'up' },
      { label: 'Portfolio Modeled', value: '$500M+', numValue: 500, suffix: 'M+ ARR', detail: 'Simulated enterprise customer base', trend: 'neutral' },
      { label: 'Health Indicators', value: '4 Pillars', numValue: 4, suffix: ' Vectors', detail: 'Multi-factor algorithmic scoring', trend: 'up' },
    ],
    milestones: [
      { phase: 'Phase 01', title: 'Domain Modeling & Metric Synthesis', timeframe: 'Month 1', status: 'completed', outcomes: ['Identified 4 critical pillars of enterprise account health', 'Constructed normalized DAX algorithms with statistical weightings'] },
      { phase: 'Phase 02', title: 'Data Architecture & Power BI Dashboarding', timeframe: 'Month 2', status: 'completed', outcomes: ['Built executive portfolio summary with multi-tier filtering', 'Created drill-through analysis for deep-dive root cause isolation'] },
      { phase: 'Phase 03', title: 'Power Automate Escalation Webhook Pipelines', timeframe: 'Month 3', status: 'completed', outcomes: ['Connected health score triggers to automated remediation flows', 'Built targeted notification templates for Account Directors'] },
      { phase: 'Phase 04', title: 'Simulated Stress-Testing & Executive Rollout', timeframe: 'Month 4', status: 'completed', outcomes: ['Stress-tested against edge cases across simulated $500M+ portfolio', 'Authored operational runbooks for executive account governance'] },
    ],
    dataFlowNodes: [
      { id: 'cs-1', stepNumber: '01', title: 'Multi-Source Data Ingestion', subtitle: 'Platform Logs & Tickets', description: 'Pulls raw activity telemetry, open P1/P2 tickets, SLA breach events, and contract values into staging tables.', icon: 'Database', payloadExample: '{"client_id": "BANK_ALPHA", "active_users": 420, "p1_incidents_30d": 2, "contract_arr": 4500000}', latency: 'Scheduled' },
      { id: 'cs-2', stepNumber: '02', title: 'DAX Normalization Engine', subtitle: 'Algorithmic Synthesis', description: 'Calculates percentile rankings and applies 4-vector weightings to yield a single 0-100 Account Health Index.', icon: 'Sliders', payloadExample: '{"adoption_idx": 84, "sla_idx": 62, "relationship_idx": 45, "composite_health": 67.2}', latency: 'Live DAX' },
      { id: 'cs-3', stepNumber: '03', title: 'Churn Risk Classifier', subtitle: 'Quadrant Slicing', description: 'Evaluates composite score against contract renewal proximity to assign Churn Vulnerability Tier (Low/Medium/High/Critical).', icon: 'AlertTriangle', payloadExample: '{"risk_category": "HIGH_VULNERABILITY", "days_to_renewal": 88, "financial_exposure": "$4.5M"}', latency: 'Instant' },
      { id: 'cs-4', stepNumber: '04', title: 'Executive Power BI Canvas', subtitle: 'Portfolio Command Center', description: 'Displays macro portfolio health distribution, geographical exposure, and instant drill-downs for board-level review.', icon: 'BarChart2', payloadExample: '{"rendered_view": "Executive_Summary", "active_filters": ["Tier 1 Banks", "EMEA"]}', latency: 'Interactive' },
      { id: 'cs-5', stepNumber: '05', title: 'Automated Action Webhook', subtitle: 'Power Automate Dispatcher', description: 'Dispatches urgent remediation notification to designated account owner with pre-populated playbooks.', icon: 'Send', payloadExample: '{"action": "DISPATCH_INTERVENTION_PLAYBOOK", "assigned_to": "Global_Account_Director", "sla_hours": 24}', latency: '< 500ms' },
    ],
    architectureLayers: [
      { layerName: 'Ingestion & ETL', components: ['Usage Telemetry Feeds', 'Ticketing API Staging', 'Contract Master Ledger'], description: 'Consolidates multi-source enterprise logs into a unified relational star-schema data model.' },
      { layerName: 'Analytics & Scoring Engine', components: ['Power BI DAX Core', 'Weighted Z-Score Models', 'Time-Intelligence Measures'], description: 'Processes real-time algorithmic calculations and historical trend tracking across 36-month windows.' },
      { layerName: 'Executive Presentation Layer', components: ['Interactive Risk Matrix', 'Cohort Retention Slicers', 'Executive KPI Cards'], description: 'Provides responsive, high-contrast dashboards designed for executive decision-makers.' },
      { layerName: 'Operational Action Layer', components: ['Power Automate Cloud Flows', 'Jira / Teams Alert Webhooks', 'Playbook Dispatchers'], description: 'Translates analytics directly into proactive intervention tasks for front-line account managers.' },
    ],
  },
  {
    id: 'project-command-center',
    number: 'PROJECT 03',
    title: 'Client Communications Command Center',
    date: 'October 2025',
    tags: ['Excel VBA', 'Outlook Automation', 'Dashboard Reporting', 'Process Optimization'],
    summary:
      'A high-efficiency operational hub engineered to transform manual, error-prone client outreach and tracking across enterprise accounts into an automated, auditable command center. Integrates dynamic Excel VBA macro engines with native Outlook pipelines to streamline stakeholder correspondence and executive audit tracking.',
    architectureOverview:
      'Advanced Excel VBA automation core interfacing with Microsoft Outlook MAPI objects. Automated data validation modules ensure compliance and eliminate typo-induced delivery failures while populating real-time executive progress dashboards.',
    highlights: [
      '80% reduction in manual effort achieved through one-click macro dispatch engines.',
      'Automated feedback workbooks tracking client responses, escalation timestamps, and SLA resolution velocity.',
      'Segmented communications engine tailoring updates by client tier, geographical region, and desk specialty.',
      'Comprehensive audit trails providing compliance teams with airtight historical records of all touchpoints.',
    ],
    workflowSteps: [
      { step: '01', title: 'Manual Legacy Process', desc: 'Tedious copy-pasting across dozens of client spreadsheets taking 4+ hours daily.' },
      { step: '02', title: 'VBA Macro Engine', desc: 'Dynamic data parsing, formatting, and personalization executed in seconds.' },
      { step: '03', title: 'Outlook Pipeline', desc: 'Automated queueing and targeted dispatch with attachment validation.' },
      { step: '04', title: 'Real-Time Audit Dashboard', desc: 'Visual tracking of response rates, follow-ups needed, and risk items.' },
    ],
    modeledImpact: '80% Reduction in Recurring Manual Effort',
    impactDisclaimer: 'Measured operational efficiency gain across recurring communication cycles.',
    demoUrl: '#command-center-demo',
    badge: 'Workflow Automation',
    overview:
      'Engineered a mission-critical automation engine that eliminated 4+ hours of grueling daily manual copy-pasting and email distribution across Tier 1 banking clients. By creating an integrated Excel VBA and Outlook MAPI command center, communications became 100% auditable, typo-proof, and instant.',
    myRole:
      'Process Engineer & Automation Developer — Mapped the end-to-end legacy communication bottlenecks, authored the complete Excel VBA code modules with defensive error handling, constructed the dynamic template parsing engine, and trained cross-functional teams to achieve 100% adoption.',
    challenges: [
      {
        title: 'High-Volume Manual Copy-Pasting Under Trading Deadlines',
        description: 'Account managers were manually updating dozens of client status emails each day from fragmented spreadsheets under intense time pressure.',
        impact: 'High risk of wrong client data leakage, formatting errors, and massive cognitive fatigue.',
      },
      {
        title: 'Strict Bank Compliance & Audit Requirements',
        description: 'Every communication with institutional financial trading desks requires tamper-evident audit trails with verified timestamps.',
        impact: 'Manual email dispatch left no centralized ledger of which client received what specification update.',
      },
      {
        title: 'Legacy Enterprise Infrastructure Restrictions',
        description: 'Strict banking IT policies prohibited installing arbitrary 3rd-party SaaS software or unvetted browser extensions on workstations.',
        impact: 'Automation had to be built natively within approved enterprise toolsets: Excel VBA and Microsoft Outlook.',
      },
    ],
    solution: [
      {
        title: 'One-Click VBA Macro Engine with Outlook MAPI Integration',
        description: 'Developed optimized VBA procedures that dynamically read client records, populate personalized HTML templates, attach verified documents, and queue or send.',
        techHighlight: 'Asynchronous Outlook COM object automation with defensive error trapping.',
      },
      {
        title: 'Pre-Flight Data Validation & Leakage Prevention',
        description: 'Engineered programmatic checks that verify recipient domain, detect missing placeholders, and ensure attachment checksums before dispatching a single email.',
        techHighlight: 'RegEx domain verification and placeholder guardrails preventing embarrassing "[CLIENT_NAME]" mistakes.',
      },
      {
        title: 'Centralized Audit Ledger & Visual Response Tracker',
        description: 'Automatically records every outbound dispatch timestamp, recipient, and follow-up status into a real-time dashboard ledger.',
        techHighlight: 'Dynamic workbook aggregation with automated SLA escalation alerts.',
      },
    ],
    technologiesCategorized: [
      { category: 'Automation Core', items: ['Excel VBA', 'Microsoft Outlook MAPI', 'COM Object Model', 'Error Trapping Routines'] },
      { category: 'Data & Validation', items: ['RegEx Pattern Matching', 'Pre-Flight Data Cleansing', 'Automated Checksums', 'Audit Logging'] },
      { category: 'UI & Visualization', items: ['Dynamic Workbook Dashboards', 'Color-Coded Status Matrix', 'One-Click Action Triggers'] },
    ],
    beforeVsAfter: [
      { metric: 'Daily Operational Time Spent', before: '4+ hours grueling manual copy-pasting', after: '< 15 seconds one-click dispatch', delta: '-80% Manual Effort' },
      { metric: 'Human Typo & Data Leakage Risk', before: 'High risk of manual copy-paste errors', after: '0% — Enforced by pre-flight validation', delta: 'Zero Compliance Breaches' },
      { metric: 'Audit Trail Completeness', before: 'Scattered across individual sent folders', after: '100% centralized timestamped ledger', delta: 'Instant Audit Readiness' },
      { metric: 'Team Operational Morale & Capacity', before: 'Drained by low-value repetitive chores', after: 'Redirected to strategic client advisory', delta: 'High Value Unlocked' },
    ],
    keyLearnings: [
      'High-impact enterprise innovation does not always require unapproved cutting-edge frameworks; mastering the approved enterprise toolsets (VBA, COM, Office) solves massive real-world problems immediately.',
      'Pre-flight guardrails eliminate executive anxiety: knowing that bad domain mismatches or empty placeholders are programmatically impossible builds immense confidence.',
      'Compound operational leverage happens when minutes saved per day are multiplied across an entire account team over 250 trading days.',
    ],
    kpiStats: [
      { label: 'Manual Effort Cut', value: '80%', numValue: 80, suffix: '%', detail: 'Eliminated repetitive copy-pasting', trend: 'down' },
      { label: 'Execution Speed', value: '< 15s', numValue: 15, suffix: 's', detail: 'Instant automated queue and dispatch', trend: 'down' },
      { label: 'Audit Compliance', value: '100%', numValue: 100, suffix: '%', detail: 'Centralized immutable tracking logs', trend: 'up' },
      { label: 'Error Rate', value: '0%', numValue: 0, suffix: '%', detail: 'Zero typo or wrong-client incidents', trend: 'down' },
    ],
    milestones: [
      { phase: 'Phase 01', title: 'Bottleneck Audit & Process Mapping', timeframe: 'Week 1', status: 'completed', outcomes: ['Cataloged 18 manual touchpoints in daily client update workflows', 'Established compliance and security boundaries with IT risk'] },
      { phase: 'Phase 02', title: 'Core VBA Macro & MAPI Engine Development', timeframe: 'Week 2-3', status: 'completed', outcomes: ['Developed multi-client loop architecture with Outlook COM binding', 'Implemented robust error trapping and roll-back handlers'] },
      { phase: 'Phase 03', title: 'Pre-Flight Guardrails & Audit Ledger', timeframe: 'Week 4', status: 'completed', outcomes: ['Integrated RegEx recipient domain validation and missing field checks', 'Built dynamic dashboard summary with response velocity tracking'] },
      { phase: 'Phase 04', title: 'Team Rollout & Operational Adoption', timeframe: 'Week 5', status: 'completed', outcomes: ['Trained account team and achieved 100% daily operational adoption', 'Achieved immediate 80% time recovery across recurring reporting cycles'] },
    ],
    dataFlowNodes: [
      { id: 'cc-1', stepNumber: '01', title: 'Spreadsheet Ingestion', subtitle: 'Raw Account Data', description: 'Loads client accounts, contract specifics, platform update milestones, and open items from centralized master tables.', icon: 'FileSpreadsheet', payloadExample: '{"client": "TIER1_INVESTMENT_BANK", "desk": "Fixed Income", "status": "RELEASE_CANDIDATE"}', latency: '120ms' },
      { id: 'cc-2', stepNumber: '02', title: 'Pre-Flight Validation', subtitle: 'RegEx & Checksum Guardrails', description: 'Checks that email domain matches client whitelist, verifies no blank tokens exist, and validates file attachments.', icon: 'CheckSquare', payloadExample: '{"whitelist_verified": true, "tokens_valid": true, "attachments_found": 1}', latency: '45ms' },
      { id: 'cc-3', stepNumber: '03', title: 'Dynamic Template Compiler', subtitle: 'HTML Formatting Engine', description: 'Merges verified data into branded, high-contrast HTML email templates formatted for executive readability.', icon: 'Code', payloadExample: '{"html_compiled": true, "personalized_tokens": 12, "style": "Executive-Dark"}', latency: '85ms' },
      { id: 'cc-4', stepNumber: '04', title: 'Outlook MAPI Dispatch', subtitle: 'Automated Transmission', description: 'Connects to local Outlook process to queue or instantly transmit with delivery receipts and high-importance headers.', icon: 'Mail', payloadExample: '{"mapi_status": "QUEUED_FOR_SEND", "recipient": "md_fixedincome@bank.com"}', latency: '350ms' },
      { id: 'cc-5', stepNumber: '05', title: 'Audit Ledger Registration', subtitle: 'Compliance Record', description: 'Writes outbound dispatch record, SHA timestamp, and expected response deadline to immutable tracking tab.', icon: 'Shield', payloadExample: '{"audit_id": "AUD-2025-9921", "timestamp": "2025-10-18T14:32:00Z", "status": "DISPATCHED"}', latency: '20ms' },
    ],
    architectureLayers: [
      { layerName: 'Master Data Tier', components: ['Client Master Table', 'Contact Ledger', 'Milestone Matrix'], description: 'Normalized Excel tables storing structured account metadata and delivery schedules.' },
      { layerName: 'Macro Execution Core', components: ['VBA Controller Module', 'RegEx Validator', 'HTML Template Assembler'], description: 'Modular VBA classes executing high-speed parsing, pre-flight guardrails, and error handling.' },
      { layerName: 'Enterprise Office Bridge', components: ['Outlook MAPI Objects', 'File System Attachments', 'Security Permissions'], description: 'Safely coordinates with desktop Office applications without requiring untrusted external add-ins.' },
      { layerName: 'Audit & Telemetry Tier', components: ['Centralized Log Ledger', 'Executive Response Matrix', 'SLA Alert Triggers'], description: 'Provides complete audit trail visibility and flags unanswered inquiries for management escalation.' },
    ],
  },
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    id: 'product-project',
    category: 'Product & Project Management',
    description: 'Directing the end-to-end delivery lifecycle from strategic concept to stable production.',
    skills: [
      'Product Strategy',
      'Roadmap Planning',
      'Backlog Prioritization',
      'Agile Delivery',
      'Scrum',
      'Requirements Gathering',
      'Business Analysis',
      'User Stories',
      'UAT',
      'Risk Management',
      'Incident & Change Management',
      'MS Project',
      'BRD / FRD Drafting',
    ],
  },
  {
    id: 'stakeholder',
    category: 'Stakeholder Management',
    description: 'Fostering unwavering trust and alignment across C-suite, clients, and technical teams.',
    skills: [
      'Executive Communication',
      'Cross-Functional Collaboration',
      'Stakeholder & SLA Alignment',
      'Escalation Management',
      'Client Relationship Management',
      'Dashboard Reporting',
      'Strategic Advisory',
      'Crisis Mediation',
    ],
  },
  {
    id: 'financial-markets',
    category: 'Financial Markets',
    description: 'Deep domain expertise in institutional capital markets instruments and workflows.',
    skills: [
      'Fixed Income',
      'Repo (Repurchase Agreements)',
      'Equities',
      'Capital Markets Infrastructure',
      'Trade Lifecycle',
      'Front-to-Back Operations',
    ],
  },
  {
    id: 'data-analytics',
    category: 'Data & Analytics',
    description: 'Transforming dense operational data into decisive visual intelligence.',
    skills: [
      'Power BI',
      'Tableau',
      'Advanced Excel (VBA/PowerQuery)',
      'SQL',
      'Alteryx',
      'Databricks',
      'Data Visualization',
      'KPI Architecture',
    ],
  },
  {
    id: 'automation-ai',
    category: 'Automation & Process Improvement',
    description: 'Eliminating toil and accelerating output with automation scripts and AI agent swarms.',
    skills: [
      'Excel VBA',
      'Microsoft Power Platform',
      'Power Automate',
      'Workflow Automation',
      'Process Optimization',
      'Prompt Engineering',
      'n8n Orchestration',
      'Docker Deployment',
    ],
  },
  {
    id: 'platforms-tools',
    category: 'Platforms & Tools',
    description: 'Modern enterprise ecosystem tools and cloud platforms.',
    skills: [
      'Salesforce',
      'Kimble PSA',
      'Jira',
      'Confluence',
      'Microsoft 365',
      'Azure',
      'AWS',
      'Git / GitHub',
    ],
  },
];

export const EDUCATION_DATA: EducationItem = {
  institution: 'Thapar Institute of Engineering and Technology',
  degree: 'B.E. — Electronics and Computer Engineering',
  period: 'August 2020 – June 2024',
  location: 'Patiala, Punjab, India',
  gpa: 'CGPA: 8.36',
  highlights: [
    'Rigorous engineering foundation in computer architectures, algorithms, microprocessors, and software engineering principles.',
    'Led technical symposiums and cross-disciplinary capstone initiatives combining embedded hardware with software applications.',
    'Graduated with honors standing (8.36 / 10.0 CGPA).',
  ],
};
