export interface NavItem {
  id: string;
  label: string;
  href: string;
}

export interface PhilosophyCard {
  id: string;
  title: string;
  tagline: string;
  summary: string;
  expandedDetails: string[];
  metricHighlight?: string;
  iconName: string;
}

export interface ExperienceTheme {
  name: string;
  description: string;
  color: string;
}

export interface ExperienceItem {
  company: string;
  role: string;
  period: string;
  location: string;
  clientContext: string;
  summary: string;
  themes: string[];
  responsibilities: string[];
  impactHighlights: string[];
  technologiesUsed: string[];
}

export interface WhyMeCard {
  id: string;
  title: string;
  headline: string;
  description: string;
  metaphorType: 'multipliers' | 'bilingual' | 'clarity' | 'ai' | 'owner';
  bulletPoints: string[];
  badge: string;
}

export interface ValueCard {
  id: string;
  title: string;
  shortDesc: string;
  deepDive: string;
  keywords: string[];
  icon: string;
}

export interface ConstellationNode {
  id: string;
  label: string;
  category: 'strategy' | 'technology' | 'delivery' | 'relationship';
  angle: number; // in degrees for circular layout
  distance: number; // radius factor
  description: string;
  synergy: string;
  keySkills: string[];
}

export interface ProjectCaseStudy {
  id: string;
  number: string;
  title: string;
  date: string;
  tags: string[];
  summary: string;
  architectureOverview: string;
  highlights: string[];
  workflowSteps: { step: string; title: string; desc: string }[];
  modeledImpact: string;
  impactDisclaimer?: string;
  githubUrl?: string;
  demoUrl?: string;
  badge: string;
  // Executive Portfolio & Dynamic Journey additions
  overview: string;
  myRole: string;
  challenges: { title: string; description: string; impact: string }[];
  solution: { title: string; description: string; techHighlight: string }[];
  technologiesCategorized: { category: string; items: string[] }[];
  beforeVsAfter: { metric: string; before: string; after: string; delta: string; unit?: string }[];
  keyLearnings: string[];
  kpiStats: { label: string; value: string; numValue?: number; suffix?: string; detail: string; trend: 'up' | 'down' | 'neutral' }[];
  milestones: { phase: string; title: string; timeframe: string; status: 'completed' | 'in-progress' | 'planned'; outcomes: string[] }[];
  dataFlowNodes: { id: string; stepNumber: string; title: string; subtitle: string; description: string; icon: string; payloadExample?: string; latency?: string }[];
  architectureLayers: { layerName: string; components: string[]; description: string }[];
}

export interface SkillCategory {
  id: string;
  category: string;
  description: string;
  skills: string[];
}

export interface EducationItem {
  institution: string;
  degree: string;
  period: string;
  location: string;
  gpa: string;
  highlights: string[];
}
