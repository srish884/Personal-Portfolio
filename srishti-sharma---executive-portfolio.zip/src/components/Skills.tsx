import React, { useState } from 'react';
import {
  Search,
  Filter,
  Layers,
  Sparkles,
  Check,
  Cpu,
  TrendingUp,
  SlidersHorizontal,
} from 'lucide-react';
import { SKILL_CATEGORIES } from '../data/portfolioData';

export const Skills: React.FC = () => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredCategories = SKILL_CATEGORIES.map((cat) => {
    const isCategorySelected = selectedCategoryId === 'all' || selectedCategoryId === cat.id;
    if (!isCategorySelected) return null;

    const matchingSkills = cat.skills.filter((skill) =>
      skill.toLowerCase().includes(searchQuery.toLowerCase())
    );

    if (searchQuery && matchingSkills.length === 0) return null;

    return {
      ...cat,
      skills: searchQuery ? matchingSkills : cat.skills,
    };
  }).filter(Boolean);

  const totalSkillsCount = SKILL_CATEGORIES.reduce((acc, cat) => acc + cat.skills.length, 0);

  return (
    <section id="skills" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 07 · TECHNICAL & DOMAIN ECOSYSTEM</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>{totalSkillsCount} VERIFIED COMPETENCIES</span>
            </div>
            <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              SKILLS ECOSYSTEM
            </h2>
          </div>

          <div className="max-w-md text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              Curated for Executive & Technical Orchestration.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              An organized ecosystem combining deep financial market domain knowledge, enterprise delivery discipline, and hands-on modern automation.
            </p>
          </div>
        </div>

        {/* Search & Category Filter Controls */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-8">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setSelectedCategoryId('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-mono transition-all ${
                selectedCategoryId === 'all'
                  ? 'bg-[#ea580c] text-white font-bold shadow-lg shadow-[#ea580c]/20'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
              }`}
            >
              All Categories ({SKILL_CATEGORIES.length})
            </button>
            {SKILL_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategoryId(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-mono transition-all ${
                  selectedCategoryId === cat.id
                    ? 'bg-[#ea580c] text-white font-bold shadow-lg shadow-[#ea580c]/20'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                }`}
              >
                {cat.category}
              </button>
            ))}
          </div>

          {/* Quick Search Input */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search skill (e.g. Repo, SQL, Agile)..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-neutral-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-500 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Categorized Skills Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCategories.map((cat) => {
            if (!cat) return null;
            return (
              <div
                key={cat.id}
                className="rounded-2xl bg-gradient-to-b from-[#13151f] to-[#0e1017] border border-neutral-800 p-6 flex flex-col justify-between hover:border-neutral-700 transition-all duration-300 shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between border-b border-neutral-800/80 pb-3 mb-4">
                    <h3 className="text-base font-bold text-white font-['Syne',sans-serif]">
                      {cat.category}
                    </h3>
                    <span className="text-[10px] font-mono text-neutral-500 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800">
                      {cat.skills.length} skills
                    </span>
                  </div>

                  <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
                    {cat.description}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {cat.skills.map((skill, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded-md bg-neutral-900/90 border border-neutral-800 text-xs font-mono text-neutral-300 hover:border-neutral-600 hover:text-white transition-colors"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-neutral-800/60 flex items-center justify-between text-[10px] font-mono text-neutral-500">
                  <span>PRODUCTION READY</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> VERIFIED
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
