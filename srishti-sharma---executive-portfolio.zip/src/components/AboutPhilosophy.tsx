import React, { useState } from 'react';
import {
  ArrowUpRight,
  Zap,
  Binary,
  Sparkles,
  Cpu,
  ShieldCheck,
  ChevronDown,
  CheckCircle2,
} from 'lucide-react';
import { PHILOSOPHY_CARDS } from '../data/portfolioData';

export const AboutPhilosophy: React.FC = () => {
  const [expandedId, setExpandedId] = useState<string>('multipliers');

  const getIcon = (name: string) => {
    switch (name) {
      case 'Zap':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'Binary':
        return <Binary className="w-5 h-5 text-cyan-400" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-purple-400" />;
      case 'Cpu':
        return <Cpu className="w-5 h-5 text-emerald-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-blue-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-neutral-400" />;
    }
  };

  return (
    <section id="about" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Section Header matching the reference image's bold "ABOUT" style */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 01 · OPERATING PHILOSOPHY</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>BUSINESS × TECHNOLOGY INTERSECTION</span>
            </div>
            <div className="flex items-baseline gap-4">
              <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
                ABOUT
              </h2>
              <ArrowUpRight className="w-12 h-12 text-neutral-500 hover:text-white transition-colors self-center hidden sm:block stroke-[2]" />
            </div>
          </div>

          <div className="max-w-xl text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold text-base sm:text-lg mb-2">
              "Srishti Sharma operates at the critical intersection of business strategy, capital markets, enterprise product delivery, and practical AI automation."
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              I work with Tier 1 global banks, complex technology, and ambitious projects. True technical account management isn’t passive reporting—it’s actively de-risking high-stakes financial operations and building systems that compound enterprise leverage.
            </p>
          </div>
        </div>

        {/* 5 Distinct Interactive Philosophy Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Quick Selector List */}
          <div className="lg:col-span-5 flex flex-col gap-3">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider mb-1">
              Select Statement to Explore Impact:
            </span>
            {PHILOSOPHY_CARDS.map((card, idx) => {
              const isSelected = expandedId === card.id;
              return (
                <button
                  key={card.id}
                  onClick={() => setExpandedId(card.id)}
                  id={`philosophy-tab-${card.id}`}
                  className={`text-left p-4 sm:p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden group ${
                    isSelected
                      ? 'bg-[#11131a] border-neutral-600 shadow-2xl shadow-black'
                      : 'bg-[#0a0c10] border-neutral-800/80 hover:bg-[#0f1118] hover:border-neutral-700'
                  }`}
                >
                  {/* Subtle terracotta active indicator bar matching reference image accent */}
                  {isSelected && (
                    <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[#ea580c]" />
                  )}

                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
                          isSelected
                            ? 'bg-neutral-800 border border-neutral-600 text-white'
                            : 'bg-neutral-900 border border-neutral-800 group-hover:border-neutral-700 text-neutral-400'
                        }`}
                      >
                        {getIcon(card.iconName)}
                      </div>
                      <div>
                        <span className="text-[10px] font-mono text-neutral-500 tracking-wider">
                          0{idx + 1} //
                        </span>
                        <h3 className="text-sm font-bold text-white group-hover:text-white transition-colors">
                          {card.title}
                        </h3>
                      </div>
                    </div>
                    <ChevronDown
                      className={`w-4 h-4 text-neutral-500 transition-transform duration-300 mt-1 ${
                        isSelected ? 'rotate-[-90deg] text-white' : ''
                      }`}
                    />
                  </div>
                  <p className="text-xs text-neutral-400 mt-2 pl-12 line-clamp-1">
                    {card.tagline}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Right Column: Deep-Dive Interactive Presentation Panel */}
          <div className="lg:col-span-7">
            {PHILOSOPHY_CARDS.map((card) => {
              if (card.id !== expandedId) return null;
              return (
                <div
                  key={card.id}
                  id={`philosophy-card-expanded-${card.id}`}
                  className="h-full rounded-2xl bg-gradient-to-b from-[#11131a] to-[#0a0c10] border border-neutral-700/90 p-6 sm:p-8 flex flex-col justify-between shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-300"
                >
                  {/* Ambient subtle glow */}
                  <div className="absolute top-0 right-0 w-64 h-64 bg-neutral-800/20 rounded-full blur-3xl pointer-events-none" />

                  <div>
                    {/* Header with badge */}
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-neutral-800 pb-5 mb-6">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-xl bg-neutral-900 border border-neutral-700">
                          {getIcon(card.iconName)}
                        </div>
                        <span className="text-xs font-mono tracking-widest uppercase text-neutral-400">
                          CORE PILLAR
                        </span>
                      </div>
                      {card.metricHighlight && (
                        <div className="px-3 py-1 rounded-full bg-black border border-neutral-700 text-xs font-mono text-neutral-200 font-semibold">
                          {card.metricHighlight}
                        </div>
                      )}
                    </div>

                    <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Syne',sans-serif] mb-2">
                      "{card.title}"
                    </h3>
                    <p className="text-sm font-mono text-[#ea580c] mb-6 font-semibold">
                      // {card.tagline}
                    </p>

                    <p className="text-neutral-300 text-sm sm:text-base leading-relaxed mb-6">
                      {card.summary}
                    </p>

                    <div className="space-y-3 pt-2">
                      <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider block">
                        Demonstrated Execution:
                      </span>
                      {card.expandedDetails.map((detail, i) => (
                        <div
                          key={i}
                          className="flex items-start gap-3 p-3.5 rounded-xl bg-neutral-900/60 border border-neutral-800 text-xs sm:text-sm text-neutral-200"
                        >
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Footnote statement */}
                  <div className="mt-8 pt-4 border-t border-neutral-800 flex items-center justify-between text-xs font-mono text-neutral-500">
                    <span>PHILOSOPHY IN ACTION</span>
                    <span className="text-neutral-400">SYSTEMIC CLARITY OVER PATCHES</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
