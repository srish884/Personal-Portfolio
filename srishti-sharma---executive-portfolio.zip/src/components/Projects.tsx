import React, { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { ProjectCaseStudy } from '../types';
import { ProjectModal } from './ProjectModal';
import { ProjectJourneyView } from './projects/ProjectJourneyView';

export const Projects: React.FC = () => {
  const [activeProjectForModal, setActiveProjectForModal] = useState<ProjectCaseStudy | null>(null);

  return (
    <section id="projects" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 06 · SYSTEM ARCHITECTURE & CODE</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>SUBSTANTIAL CASE STUDIES</span>
            </div>
            <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              THINGS I'VE BUILT
            </h2>
          </div>

          <div className="max-w-lg text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              Production-Grade Systems & Automated Intelligence.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              Substantial end-to-end architectures designed to eradicate manual friction, extract high-value business signals, and unlock compounding commercial leverage.
            </p>
          </div>
        </div>

        {/* Dual Split Panels directly inspired by the reference picture's right-hand cards */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16 items-stretch">
          {/* Light Card: White background with dashed lines and bold typography matching "SELECTED WORKS" */}
          <div className="lg:col-span-7 rounded-2xl bg-white text-neutral-950 p-8 sm:p-10 shadow-2xl flex flex-col justify-between border border-neutral-200">
            <div>
              <p className="text-base sm:text-lg font-bold text-neutral-900 leading-snug mb-8 font-sans">
                Srishti brings immense enterprise value to every mission, consistently exceeding stakeholder expectations and setting new standards in technical account delivery, automated intelligence, and financial markets orchestration.
              </p>

              <div className="border-t border-dashed border-neutral-300 pt-3 mb-2">
                <span className="text-[11px] font-mono tracking-widest uppercase font-bold text-neutral-500">
                  SELECTED WORKS & ENTERPRISE CODE
                </span>
              </div>

              {/* Dashed line item list matching the picture */}
              <div className="divide-y divide-dashed divide-neutral-300">
                {PROJECTS.map((proj, idx) => (
                  <div
                    key={proj.id}
                    onClick={() => setActiveProjectForModal(proj)}
                    className="py-4 flex items-center justify-between group cursor-pointer hover:pl-2 transition-all"
                  >
                    <div>
                      <span className="text-[10px] font-mono text-neutral-500 block">
                        PROJECT 0{idx + 1} // {proj.date}
                      </span>
                      <h4 className="text-xl sm:text-2xl font-extrabold tracking-tight text-neutral-950 font-['Syne',sans-serif] group-hover:text-[#ea580c] transition-colors">
                        {proj.title}
                      </h4>
                    </div>
                    <div className="w-8 h-8 rounded-full border border-neutral-900 flex items-center justify-center group-hover:bg-black group-hover:text-white transition-all shrink-0">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-neutral-200 flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-neutral-900">PRODUCTION DEPLOYMENTS</span>
              <a
                href="https://github.com/srish884"
                target="_blank"
                rel="noreferrer"
                className="font-bold text-neutral-900 hover:text-[#ea580c] underline inline-flex items-center gap-1 transition-colors"
              >
                <span>View all code repositories</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Dark Card with stacked condensed typography & terracotta accent matching lower-right reference card */}
          <div className="lg:col-span-5 rounded-2xl bg-[#0a0c10] border border-neutral-800 p-8 sm:p-10 shadow-2xl flex flex-col justify-between relative overflow-hidden">
            {/* Terracotta/Orange Accent block matching the warm jacket in reference image */}
            <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-[#ea580c] opacity-20 blur-3xl pointer-events-none" />

            <div className="space-y-1">
              <span className="text-xs font-mono tracking-widest text-[#ea580c] uppercase font-semibold block mb-4">
                // SYSTEM CORE PARADIGM
              </span>
              <h3 className="text-5xl sm:text-6xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
                SYSTEM
              </h3>
              <h3 className="text-5xl sm:text-6xl font-extrabold uppercase tracking-tight text-neutral-600 font-['Bebas_Neue',sans-serif] leading-none">
                PROJECT
              </h3>
              <h3 className="text-5xl sm:text-6xl font-extrabold uppercase tracking-tight text-neutral-600 font-['Bebas_Neue',sans-serif] leading-none">
                EXECUTION
              </h3>
            </div>

            <div className="mt-8 pt-6 border-t border-neutral-800 space-y-4">
              <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                Srishti's engineering delivery process involves thorough architectural research and ideation, followed by the creation of production prototypes with a focus on systemic leverage. Continuous automation and rigorous testing lead to resilient solutions that withstand enterprise audit and scale across Tier 1 environments.
              </p>

              {/* Vibrant terracotta callout card */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-[#ea580c] to-[#c2410c] text-white flex items-center justify-between shadow-lg">
                <div>
                  <span className="text-[10px] font-mono tracking-wider uppercase opacity-90 block">
                    CORE OPERATIONAL MULTIPLIER
                  </span>
                  <span className="text-sm font-bold font-sans">
                    80% Manual Effort Reduction Via Automated Macros
                  </span>
                </div>
                <ArrowUpRight className="w-5 h-5 shrink-0 stroke-[2.5]" />
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Interactive Projects Journey Section */}
        <ProjectJourneyView
          projects={PROJECTS}
          onOpenModal={setActiveProjectForModal}
        />
      </div>

      {/* Case Study Deep Dive Modal */}
      <ProjectModal
        project={activeProjectForModal}
        onClose={() => setActiveProjectForModal(null)}
      />
    </section>
  );
};
