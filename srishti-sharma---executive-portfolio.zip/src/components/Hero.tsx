import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUpRight,
  ArrowRight,
  Linkedin,
  Github,
  Mail,
  Camera,
  Sparkles,
} from 'lucide-react';
import { motion } from 'motion/react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { Portrait3D } from './Portrait3D';
import { GlowingTagline } from './GlowingTagline';
import { RolesSolarSystem } from './RolesSolarSystem';
import { HeroHighlightCards } from './HeroHighlightCards';

interface HeroProps {
  onProjectsClick: () => void;
  onExperienceClick: () => void;
  onContactClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onProjectsClick,
  onExperienceClick,
  onContactClick,
}) => {
  const [customPhoto, setCustomPhoto] = useState<string | null>(() => {
    return localStorage.getItem('srishti_portfolio_photo') || null;
  });

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setCustomPhoto(result);
        localStorage.setItem('srishti_portfolio_photo', result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResetPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomPhoto(null);
    localStorage.removeItem('srishti_portfolio_photo');
  };

  const handleScrollDown = () => {
    const el = document.getElementById('about');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-screen pt-28 pb-12 flex flex-col justify-between overflow-hidden bg-[#d2d6de]"
    >
      {/* Editorial geometric line vectors inspired by the reference image */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
        <svg
          className="absolute -top-24 -left-24 w-[750px] h-[750px] stroke-neutral-700/50 fill-none"
          viewBox="0 0 700 700"
        >
          <circle cx="350" cy="350" r="320" strokeWidth="1.2" strokeDasharray="4 6" />
          <circle cx="350" cy="350" r="220" strokeWidth="1.2" />
          <path d="M 50,350 A 300,300 0 0,0 650,350" strokeWidth="1.2" strokeDasharray="3 5" />
        </svg>

        {/* Right side background arc */}
        <svg
          className="absolute top-1/4 -right-32 w-[600px] h-[600px] stroke-neutral-700/40 fill-none"
          viewBox="0 0 600 600"
        >
          <circle cx="300" cy="300" r="280" strokeWidth="1.2" />
          <circle cx="300" cy="300" r="160" strokeWidth="1.2" strokeDasharray="4 6" />
        </svg>

        {/* Subtle architectural grain */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #000000 1px, transparent 0)`,
            backgroundSize: '24px 24px',
          }}
        />
      </div>

      {/* Main container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full flex-1 flex flex-col justify-between">
        {/* Curated Smart Hero Highlight Cards (Just below the ribbon) */}
        <HeroHighlightCards />

        {/* Top Editorial Row: Clean Context & Coherent Target Roles Cluster */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-b border-neutral-400/60 pb-3">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono tracking-widest uppercase text-neutral-800 font-bold">
              PORTFOLIO // EXECUTIVE PROVEN IMPACT
            </span>
          </div>

          {/* Coherent Target Roles & Highlighted Availability Cluster */}
          <div className="flex flex-col sm:items-end gap-1.5">
            {/* Highlighted Availability Badge on top of Roles */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/95 border border-emerald-500/40 text-[10.5px] font-mono tracking-wider uppercase text-neutral-900 shadow-xs font-bold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-600" />
              </span>
              <span>Available for Strategic &amp; Leadership Roles</span>
            </div>

            {/* Interactive Target Roles Solar System Button */}
            <RolesSolarSystem />
          </div>
        </div>

        {/* Center Editorial Visual Hero: Giant Moving Marquee BEHIND + 3D Cutout Bust IN FRONT */}
        <div className="relative my-4 sm:my-6 flex flex-col items-center justify-center min-h-[480px] sm:min-h-[550px]">
          {/* Continuous Right-to-Left Moving Name Marquee BEHIND the 3D Portrait: Faster Motion & Exclusively "SRISHTI SHARMA" */}
          <div
            aria-hidden="true"
            className="absolute inset-x-0 top-1/2 -translate-y-1/2 overflow-hidden pointer-events-none select-none z-0 leading-none"
          >
            <motion.div
              className="flex whitespace-nowrap will-change-transform"
              animate={{ x: ['0%', '-50%'] }}
              transition={{
                repeat: Infinity,
                ease: 'linear',
                duration: 9,
              }}
            >
              {/* Track 1 */}
              <div className="flex items-center shrink-0 pr-8">
                <span className="text-[20vw] sm:text-[18vw] md:text-[15.5vw] font-black uppercase tracking-tight text-[#000000] font-['Bebas_Neue',sans-serif] pr-8 select-none">
                  SRISHTI SHARMA
                </span>
                <span className="text-[12vw] sm:text-[10vw] md:text-[8vw] font-bold text-neutral-400 font-mono pr-8 select-none">
                  •
                </span>
                <span className="text-[20vw] sm:text-[18vw] md:text-[15.5vw] font-black uppercase tracking-tight text-[#000000] font-['Bebas_Neue',sans-serif] pr-8 select-none">
                  SRISHTI SHARMA
                </span>
                <span className="text-[12vw] sm:text-[10vw] md:text-[8vw] font-bold text-neutral-400 font-mono pr-8 select-none">
                  •
                </span>
              </div>
              {/* Track 2 (Exact duplicate for 100% seamless, non-stopping loop) */}
              <div className="flex items-center shrink-0 pr-8">
                <span className="text-[20vw] sm:text-[18vw] md:text-[15.5vw] font-black uppercase tracking-tight text-[#000000] font-['Bebas_Neue',sans-serif] pr-8 select-none">
                  SRISHTI SHARMA
                </span>
                <span className="text-[12vw] sm:text-[10vw] md:text-[8vw] font-bold text-neutral-400 font-mono pr-8 select-none">
                  •
                </span>
                <span className="text-[20vw] sm:text-[18vw] md:text-[15.5vw] font-black uppercase tracking-tight text-[#000000] font-['Bebas_Neue',sans-serif] pr-8 select-none">
                  SRISHTI SHARMA
                </span>
                <span className="text-[12vw] sm:text-[10vw] md:text-[8vw] font-bold text-neutral-400 font-mono pr-8 select-none">
                  •
                </span>
              </div>
            </motion.div>
          </div>

          {/* Dedicated 3D Full-Color Silhouette Cutout Portrait Standing In Front of the Moving Text (Clean, Unobstructed) */}
          <div className="relative z-20 my-2">
            <Portrait3D
              customPhoto={customPhoto}
              onPhotoUpload={handlePhotoUpload}
              onResetPhoto={handleResetPhoto}
            />
          </div>

          {/* Right Floating Indicator matching the reference image's "Scroll down ↓" exactly */}
          <div className="hidden lg:flex absolute right-4 bottom-8 flex-col items-center gap-1.5 text-neutral-900 font-mono text-xs z-20">
            <span className="font-bold tracking-widest uppercase text-xs">
              Scroll down
            </span>
            <button
              onClick={handleScrollDown}
              className="w-10 h-10 rounded-full border border-neutral-900 flex items-center justify-center animate-bounce bg-white/80 hover:bg-white transition-colors cursor-pointer shadow-sm"
              aria-label="Scroll down to About section"
            >
              <ArrowDown className="w-4 h-4 text-neutral-950 stroke-[2.5]" />
            </button>
          </div>
        </div>

        {/* Bottom Hero Editorial Text & Prominent CTAs (Rearranged & Balanced Layout) */}
        <div className="border-t border-neutral-400/80 pt-6 pb-2 space-y-6">
          {/* Top Row: Glowing Philosophy Tagline (Left) & Unified Action Cluster (Right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Expanded Left: Interactive Glowing Primary Tagline */}
            <div className="lg:col-span-7 space-y-3">
              <GlowingTagline />
            </div>

            {/* Right: Consolidated Executive Action Hub & Direct Contact */}
            <div className="lg:col-span-5 space-y-3.5 bg-white/40 border border-neutral-400/60 rounded-2xl p-4 sm:p-5 backdrop-blur-sm shadow-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={onProjectsClick}
                  id="hero-cta-view-work"
                  className="w-full inline-flex items-center justify-between px-4 py-3 rounded-xl bg-black text-white font-bold text-xs tracking-wider uppercase transition-all duration-300 hover:bg-neutral-800 active:scale-[0.98] shadow-sm cursor-pointer"
                >
                  <span>View My Work</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onExperienceClick}
                  id="hero-cta-explore-experience"
                  className="w-full inline-flex items-center justify-between px-4 py-3 rounded-xl bg-white border border-neutral-900 text-neutral-950 font-bold text-xs tracking-wider uppercase transition-all duration-300 hover:bg-neutral-100 active:scale-[0.98] shadow-sm cursor-pointer"
                >
                  <span>Experience</span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>

              <button
                onClick={onContactClick}
                id="hero-cta-lets-connect"
                className="w-full inline-flex items-center justify-between px-4 py-2.5 rounded-xl border border-neutral-800/80 bg-neutral-950 text-white hover:bg-neutral-850 text-xs font-mono font-bold tracking-wider uppercase transition-colors shadow-sm cursor-pointer"
              >
                <span>Initiate Conversation / Let&apos;s Connect</span>
                <Sparkles className="w-3.5 h-3.5 text-orange-400" />
              </button>

              {/* Verified Profiles & Direct Channels */}
              <div className="flex items-center justify-between pt-1 border-t border-neutral-400/50">
                <div className="flex items-center gap-2">
                  <a
                    href={PERSONAL_INFO.linkedinUrl}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Srishti Sharma LinkedIn Profile"
                    className="w-8 h-8 rounded-full border border-neutral-800 bg-black flex items-center justify-center text-white hover:bg-neutral-800 transition-all shadow-sm"
                  >
                    <Linkedin className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href={PERSONAL_INFO.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    aria-label="Srishti Sharma GitHub Profile"
                    className="w-8 h-8 rounded-full border border-neutral-800 bg-black flex items-center justify-center text-white hover:bg-neutral-800 transition-all shadow-sm"
                  >
                    <Github className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href={`mailto:${PERSONAL_INFO.email}`}
                    aria-label="Send Email to Srishti Sharma"
                    className="w-8 h-8 rounded-full border border-neutral-800 bg-black flex items-center justify-center text-white hover:bg-neutral-800 transition-all shadow-sm"
                  >
                    <Mail className="w-3.5 h-3.5" />
                  </a>
                </div>

                <span className="text-[11px] font-mono text-neutral-800 font-semibold">
                  Global Ready · Strategic Engagements
                </span>
              </div>
            </div>
          </div>

          {/* Smart Horizontal Flowchart: Core Narrative & Operating Progression */}
          <div className="border-t border-neutral-400/60 pt-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
              {/* Step 01 */}
              <div className="relative bg-white/50 border border-neutral-400/70 rounded-xl p-4 sm:p-5 flex flex-col justify-between shadow-xs hover:border-neutral-500 hover:bg-white/70 transition-colors">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-neutral-950 text-white text-[10px] font-mono font-bold tracking-wider">
                      01
                    </span>
                    <h3 className="text-xs font-mono font-bold tracking-wider text-neutral-900 uppercase">
                      TIER-1 BANKING CONTEXT
                    </h3>
                  </div>
                  <p className="text-neutral-800 text-xs sm:text-[13px] leading-relaxed font-normal">
                    {PERSONAL_INFO.intro[0]}
                  </p>
                </div>

                {/* Flowchart Directional Step Connector */}
                <div className="hidden md:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10 w-6 h-6 rounded-full bg-neutral-950 text-white items-center justify-center shadow-sm">
                  <ArrowRight className="w-3 h-3" />
                </div>
              </div>

              {/* Step 02 */}
              <div className="relative bg-white/50 border border-neutral-400/70 rounded-xl p-4 sm:p-5 flex flex-col justify-between shadow-xs hover:border-neutral-500 hover:bg-white/70 transition-colors">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-neutral-950 text-white text-[10px] font-mono font-bold tracking-wider">
                      02
                    </span>
                    <h3 className="text-xs font-mono font-bold tracking-wider text-neutral-900 uppercase">
                      OPERATING MINDSET
                    </h3>
                  </div>
                  <p className="text-neutral-800 text-xs sm:text-[13px] leading-relaxed font-normal">
                    {PERSONAL_INFO.intro[1]}
                  </p>
                </div>

                {/* Flowchart Directional Step Connector */}
                <div className="hidden md:flex absolute -right-3 top-1/2 -translate-y-1/2 z-10 w-6 h-6 rounded-full bg-neutral-950 text-white items-center justify-center shadow-sm">
                  <ArrowRight className="w-3 h-3" />
                </div>
              </div>

              {/* Step 03 */}
              <div className="relative bg-white/50 border border-neutral-400/70 rounded-xl p-4 sm:p-5 flex flex-col justify-between shadow-xs hover:border-neutral-500 hover:bg-white/70 transition-colors">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-neutral-950 text-white text-[10px] font-mono font-bold tracking-wider">
                      03
                    </span>
                    <h3 className="text-xs font-mono font-bold tracking-wider text-neutral-900 uppercase">
                      AI & WORKFLOW VELOCITY
                    </h3>
                  </div>
                  <p className="text-neutral-800 text-xs sm:text-[13px] leading-relaxed font-normal">
                    {PERSONAL_INFO.intro[2]}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
