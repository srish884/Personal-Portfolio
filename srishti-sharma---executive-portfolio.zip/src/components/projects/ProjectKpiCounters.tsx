import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, Minus, Target } from 'lucide-react';
import { ProjectCaseStudy } from '../../types';

interface ProjectKpiCountersProps {
  project: ProjectCaseStudy;
}

export const ProjectKpiCounters: React.FC<ProjectKpiCountersProps> = ({ project }) => {
  const stats = project.kpiStats || [];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, idx) => {
        return (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: idx * 0.1, duration: 0.4 }}
            className="p-5 rounded-2xl bg-[#090b10] border border-neutral-800 hover:border-neutral-700 transition-all shadow-xl relative overflow-hidden group"
          >
            {/* Subtle glow highlight */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#ea580c] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

            <div className="flex items-center justify-between text-neutral-400 mb-2">
              <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-400 font-semibold">
                {stat.label}
              </span>
              {stat.trend === 'up' && (
                <span className="p-1 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400">
                  <TrendingUp className="w-3.5 h-3.5" />
                </span>
              )}
              {stat.trend === 'down' && (
                <span className="p-1 rounded bg-orange-950/80 border border-orange-800 text-orange-400">
                  <TrendingDown className="w-3.5 h-3.5" />
                </span>
              )}
              {stat.trend === 'neutral' && (
                <span className="p-1 rounded bg-neutral-900 border border-neutral-800 text-neutral-400">
                  <Target className="w-3.5 h-3.5" />
                </span>
              )}
            </div>

            <div className="text-3xl sm:text-4xl font-extrabold text-white font-['Syne',sans-serif] tracking-tight my-1">
              {stat.value}
            </div>

            <p className="text-xs text-neutral-400 font-mono leading-relaxed mt-1">
              {stat.detail}
            </p>
          </motion.div>
        );
      })}
    </div>
  );
};
