import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, Clock, Calendar, ArrowRight, Flag, ShieldCheck } from 'lucide-react';
import { ProjectCaseStudy } from '../../types';

interface ProjectTimelineProps {
  project: ProjectCaseStudy;
}

export const ProjectTimeline: React.FC<ProjectTimelineProps> = ({ project }) => {
  const milestones = project.milestones || [];
  const [selectedMilestone, setSelectedMilestone] = useState(0);

  return (
    <div className="rounded-2xl bg-[#090b10] border border-neutral-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-[#ea580c] font-semibold mb-1">
            <Calendar className="w-3.5 h-3.5" />
            <span>EXECUTIVE DELIVERY ROADMAP // MILESTONES & STAKEHOLDER WINS</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif]">
            Interactive Implementation Journey
          </h3>
          <p className="text-xs text-neutral-400 font-mono mt-0.5">
            Phase-by-phase delivery sequence from architectural validation to production enterprise sign-off.
          </p>
        </div>

        <span className="px-3 py-1 rounded-full bg-neutral-900 border border-neutral-700 text-neutral-300 text-xs font-mono self-start sm:self-auto">
          {milestones.length} PHASES COMPLETED
        </span>
      </div>

      {/* Horizontal / Grid Timeline Track */}
      <div className="my-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
          {milestones.map((ms, idx) => {
            const isSelected = selectedMilestone === idx;
            return (
              <div
                key={idx}
                onClick={() => setSelectedMilestone(idx)}
                className={`p-4 rounded-xl cursor-pointer border transition-all duration-300 flex flex-col justify-between ${
                  isSelected
                    ? 'bg-neutral-900/90 border-[#ea580c] shadow-lg shadow-[#ea580c]/15 -translate-y-1'
                    : 'bg-[#0e1017]/70 border-neutral-800/80 hover:border-neutral-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-2">
                    <span className="text-[#ea580c] font-bold">{ms.phase}</span>
                    <span className="text-neutral-400 text-[10px]">{ms.timeframe}</span>
                  </div>
                  <h4 className="text-sm font-bold text-white font-sans mb-1 leading-snug">
                    {ms.title}
                  </h4>
                  <p className="text-xs text-neutral-400 font-mono line-clamp-2">
                    {ms.outcomes[0] || 'Phase execution underway'}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800/60 flex items-center justify-between text-[11px] font-mono">
                  <span className="inline-flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span className="capitalize">{ms.status}</span>
                  </span>
                  <span className="text-neutral-500 font-bold">
                    {isSelected ? 'ACTIVE VIEW' : 'EXPAND'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Phase Detail Card */}
      {milestones[selectedMilestone] && (
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedMilestone}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="p-5 rounded-xl bg-[#0c0e14] border border-neutral-800 space-y-3"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800/60 pb-3">
              <div>
                <span className="text-xs font-mono text-[#ea580c] font-semibold">
                  {milestones[selectedMilestone].phase} DEEP INSPECTION
                </span>
                <h4 className="text-base font-bold text-white font-sans">
                  {milestones[selectedMilestone].title}
                </h4>
              </div>
              <span className="text-xs font-mono text-neutral-400">
                TIMEFRAME: {milestones[selectedMilestone].timeframe}
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <span className="text-neutral-400 uppercase block mb-1">
                Phase Deliverables & Documented Outcomes:
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {milestones[selectedMilestone].outcomes.map((outcome, oIdx) => (
                  <div
                    key={oIdx}
                    className="p-3 rounded-lg bg-black/50 border border-neutral-800/80 flex items-start gap-2 text-neutral-200"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#ea580c] shrink-0 mt-0.5" />
                    <span className="font-sans text-xs leading-relaxed">{outcome}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
};
