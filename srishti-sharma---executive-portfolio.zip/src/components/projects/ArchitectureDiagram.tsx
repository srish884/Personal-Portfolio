import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Layers, Server, Shield, Database, Cpu, Lock, CheckCircle2, ChevronRight, Zap } from 'lucide-react';
import { ProjectCaseStudy } from '../../types';

interface ArchitectureDiagramProps {
  project: ProjectCaseStudy;
}

export const ArchitectureDiagram: React.FC<ArchitectureDiagramProps> = ({ project }) => {
  const layers = project.architectureLayers || [];
  const [activeLayerIndex, setActiveLayerIndex] = useState(0);

  if (layers.length === 0) return null;

  const activeLayer = layers[activeLayerIndex];

  return (
    <div className="rounded-2xl bg-[#090b10] border border-neutral-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-[#ea580c] font-semibold mb-1">
            <Layers className="w-3.5 h-3.5" />
            <span>SYSTEM ARCHITECTURE BLUEPRINT // ENTERPRISE STACK</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif]">
            Tiered Production Architecture
          </h3>
          <p className="text-xs text-neutral-400 font-mono mt-0.5">
            Decoupled microservices, data isolation layers, and security governance protocols.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800 px-3 py-1 rounded-full self-start sm:self-auto">
          <Lock className="w-3.5 h-3.5" />
          <span>SOC2 & Enterprise Compliant</span>
        </div>
      </div>

      {/* Layer selector tabs */}
      <div className="my-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {layers.map((layer, idx) => {
          const isSelected = activeLayerIndex === idx;
          return (
            <button
              key={idx}
              onClick={() => setActiveLayerIndex(idx)}
              className={`p-4 rounded-xl text-left border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-neutral-900 border-[#ea580c] shadow-lg shadow-[#ea580c]/15'
                  : 'bg-[#0d0f15]/80 border-neutral-800/80 hover:border-neutral-700'
              }`}
            >
              <div>
                <span className="text-[10px] font-mono text-[#ea580c] font-bold block mb-1">
                  LAYER 0{idx + 1}
                </span>
                <h4 className="text-sm font-bold text-white font-sans leading-snug">
                  {layer.layerName}
                </h4>
              </div>

              <div className="mt-4 flex items-center justify-between text-[11px] font-mono text-neutral-400">
                <span>{layer.components.length} components</span>
                <ChevronRight className={`w-3.5 h-3.5 ${isSelected ? 'text-[#ea580c]' : 'text-neutral-600'}`} />
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Layer Deep Dive */}
      {activeLayer && (
        <AnimatePresence mode="wait">
          <motion.div
            key={activeLayerIndex}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.2 }}
            className="p-6 rounded-xl bg-[#0c0e14] border border-neutral-800 space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800/80 pb-4">
              <div>
                <span className="text-xs font-mono text-[#ea580c] font-semibold uppercase">
                  ACTIVE LAYER DEEP-DIVE
                </span>
                <h4 className="text-lg font-bold text-white font-sans">
                  {activeLayer.layerName}
                </h4>
              </div>
              <p className="text-xs font-mono text-neutral-300 max-w-md">
                {activeLayer.description}
              </p>
            </div>

            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-neutral-400 block mb-3">
                Architectural Components & Micro-modules:
              </span>

              <div className="flex flex-wrap gap-2">
                {activeLayer.components.map((comp, cIdx) => (
                  <div
                    key={cIdx}
                    className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-neutral-900/90 border border-neutral-700 text-xs font-mono text-neutral-200 shadow-sm hover:border-neutral-500 transition-colors"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#ea580c]" />
                    <span className="font-semibold text-white">{comp}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
};
