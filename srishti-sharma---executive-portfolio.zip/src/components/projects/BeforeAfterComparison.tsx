import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, ArrowRight, AlertOctagon, CheckCircle2, ShieldAlert, Sparkles } from 'lucide-react';
import { ProjectCaseStudy } from '../../types';

interface BeforeAfterComparisonProps {
  project: ProjectCaseStudy;
}

export const BeforeAfterComparison: React.FC<BeforeAfterComparisonProps> = ({ project }) => {
  const [activeMode, setActiveMode] = useState<'after' | 'before' | 'split'>('split');
  const items = project.beforeVsAfter || [];

  return (
    <div className="rounded-2xl bg-[#090b10] border border-neutral-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-[#ea580c] font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>MEASURABLE BUSINESS OUTCOMES // OPERATIONAL DELTA</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif]">
            Before vs. After Impact Engine
          </h3>
          <p className="text-xs text-neutral-400 font-mono mt-0.5">
            Rigorous contrast of legacy friction against the automated, compounding leverage delivered.
          </p>
        </div>

        {/* View Mode Switcher Pills */}
        <div className="flex items-center p-1 rounded-xl bg-neutral-900 border border-neutral-800 self-start sm:self-auto">
          <button
            onClick={() => setActiveMode('split')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeMode === 'split'
                ? 'bg-white text-neutral-950 shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Comparative Grid
          </button>
          <button
            onClick={() => setActiveMode('before')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeMode === 'before'
                ? 'bg-rose-950/80 text-rose-300 border border-rose-800/80'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Legacy Drag
          </button>
          <button
            onClick={() => setActiveMode('after')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeMode === 'after'
                ? 'bg-[#ea580c] text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Engineered Impact
          </button>
        </div>
      </div>

      {/* Comparative Cards Matrix */}
      <div className="my-6 space-y-4">
        {items.map((item, idx) => (
          <div
            key={idx}
            className="rounded-xl bg-neutral-900/40 border border-neutral-800/80 p-5 hover:border-neutral-700 transition-all"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-neutral-800/60">
              <span className="text-xs font-mono font-bold uppercase text-neutral-300">
                METRIC 0{idx + 1} // {item.metric}
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-xs font-mono font-bold self-start sm:self-auto shadow-sm">
                <TrendingUp className="w-3.5 h-3.5" />
                {item.delta}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* BEFORE Column */}
              {(activeMode === 'split' || activeMode === 'before') && (
                <div className="p-4 rounded-lg bg-rose-950/20 border border-rose-900/40 space-y-1.5">
                  <div className="flex items-center gap-2 text-[11px] font-mono text-rose-400 font-semibold uppercase">
                    <AlertOctagon className="w-3.5 h-3.5" />
                    <span>Before Srishti's Intervention</span>
                  </div>
                  <p className="text-sm font-medium text-rose-200/90 font-sans">
                    {item.before}
                  </p>
                  <span className="text-[10px] font-mono text-rose-400/80 block">
                    High friction · Latent error risk · Repetitive manual tax
                  </span>
                </div>
              )}

              {/* AFTER Column */}
              {(activeMode === 'split' || activeMode === 'after') && (
                <div className="p-4 rounded-lg bg-emerald-950/20 border border-emerald-900/50 space-y-1.5">
                  <div className="flex items-center gap-2 text-[11px] font-mono text-emerald-400 font-semibold uppercase">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Engineered Solution & Multiplier</span>
                  </div>
                  <p className="text-sm font-bold text-white font-sans">
                    {item.after}
                  </p>
                  <span className="text-[10px] font-mono text-emerald-400/80 block">
                    Deterministic speed · Full audit trail · Permanent operational velocity
                  </span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modeled summary callout */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-neutral-900 via-[#10131d] to-[#0c0e14] border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-0.5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-neutral-400">
            AGGREGATE EFFICIENCY MULTIPLIER
          </span>
          <p className="text-sm font-bold text-white font-sans">
            {project.modeledImpact}
          </p>
        </div>

        {project.impactDisclaimer && (
          <span className="text-[10px] font-mono text-neutral-500 max-w-xs leading-normal">
            * {project.impactDisclaimer}
          </span>
        )}
      </div>
    </div>
  );
};
