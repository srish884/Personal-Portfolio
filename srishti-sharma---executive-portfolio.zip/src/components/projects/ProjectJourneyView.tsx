import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowUpRight,
  Github,
  Zap,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Shield,
  Layers,
  Calendar,
  Sparkles,
  TrendingUp,
  BarChart3,
  Bot,
  Cpu,
  Code2,
  BookOpen,
  ArrowRight,
} from 'lucide-react';
import { ProjectCaseStudy } from '../../types';
import { InteractiveFlowchart } from './InteractiveFlowchart';
import { BeforeAfterComparison } from './BeforeAfterComparison';
import { ProjectKpiCounters } from './ProjectKpiCounters';
import { ProjectTimeline } from './ProjectTimeline';
import { ArchitectureDiagram } from './ArchitectureDiagram';

interface ProjectJourneyViewProps {
  projects: ProjectCaseStudy[];
  onOpenModal: (project: ProjectCaseStudy) => void;
}

export const ProjectJourneyView: React.FC<ProjectJourneyViewProps> = ({
  projects,
  onOpenModal,
}) => {
  const [activeProjectId, setActiveProjectId] = useState<string>(projects[0]?.id || '');
  const [journeySectionTab, setJourneySectionTab] = useState<
    'all' | 'flow' | 'impact' | 'architecture' | 'timeline'
  >('all');

  const currentProject =
    projects.find((p) => p.id === activeProjectId) || projects[0];

  if (!currentProject) return null;

  return (
    <div className="space-y-12">
      {/* Dynamic Project Carousel / Selector Header */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 p-2 rounded-2xl bg-[#090b10] border border-neutral-800 shadow-xl">
        <div className="flex flex-wrap items-center gap-2 p-1">
          {projects.map((proj, idx) => {
            const isSelected = proj.id === currentProject.id;
            return (
              <button
                key={proj.id}
                onClick={() => setActiveProjectId(proj.id)}
                className={`relative px-4 py-2.5 rounded-xl text-xs font-mono font-bold tracking-wider transition-all duration-300 flex items-center gap-2.5 ${
                  isSelected
                    ? 'bg-white text-neutral-950 shadow-md'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900/80'
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    isSelected ? 'bg-[#ea580c]' : 'bg-neutral-600'
                  }`}
                />
                <span>
                  PROJECT 0{idx + 1} : {proj.title.split(' ')[0]} {proj.title.split(' ')[1]}
                </span>
                {isSelected && (
                  <span className="hidden sm:inline text-[10px] uppercase text-[#ea580c] font-black">
                    ● ACTIVE
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Action button */}
        <div className="flex items-center gap-3 px-3 py-1">
          <button
            onClick={() => onOpenModal(currentProject)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#ea580c] hover:bg-[#c2410c] text-white text-xs font-mono font-bold tracking-wider uppercase transition-colors shadow-md shadow-[#ea580c]/20"
          >
            <span>Executive Dossier</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Dynamic Journey Body */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentProject.id}
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -15 }}
          transition={{ duration: 0.3 }}
          className="space-y-12"
        >
          {/* Executive Project Hero Banner */}
          <div className="rounded-3xl bg-gradient-to-br from-[#121520] via-[#0d0f17] to-[#07080d] border border-neutral-800 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
            {/* Ambient Warm Corner Glow */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#ea580c]/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col lg:flex-row lg:items-start justify-between gap-8 pb-8 border-b border-neutral-800">
              <div className="space-y-4 max-w-3xl">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="px-3 py-1 rounded-full bg-[#ea580c]/10 border border-[#ea580c]/40 text-[#ea580c] text-xs font-mono font-bold">
                    PRODUCTION CASE STUDY
                  </span>
                  <span className="text-xs font-mono text-neutral-400">
                    {currentProject.date}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-xs font-mono">
                    Tier 1 Deployment
                  </span>
                </div>

                <h3 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight font-['Syne',sans-serif] leading-tight">
                  {currentProject.title}
                </h3>

                <p className="text-sm sm:text-base text-neutral-300 font-sans leading-relaxed">
                  {currentProject.overview}
                </p>

                {/* Srishti's Executive Role Callout */}
                <div className="p-4 rounded-xl bg-black/40 border border-neutral-800/80 space-y-1">
                  <div className="flex items-center gap-2 text-xs font-mono text-[#ea580c] font-bold uppercase">
                    <Shield className="w-3.5 h-3.5" />
                    <span>My Strategic Role & Contribution:</span>
                  </div>
                  <p className="text-xs sm:text-sm text-neutral-200 font-sans leading-relaxed">
                    {currentProject.myRole}
                  </p>
                </div>
              </div>

              {/* Action Buttons & Quick Stats */}
              <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0">
                {currentProject.githubUrl && (
                  <a
                    href={currentProject.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-neutral-900 border border-neutral-700 hover:border-neutral-500 text-white text-xs font-mono font-bold tracking-wider transition-colors shadow-sm"
                  >
                    <Github className="w-4 h-4" />
                    <span>Source Repository</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>
                )}

                <button
                  onClick={() => onOpenModal(currentProject)}
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-white text-neutral-950 hover:bg-neutral-200 text-xs font-mono font-extrabold tracking-wider uppercase transition-colors shadow-md"
                >
                  <span>Full Deep Dive Modal</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Live KPI Counters */}
            <div className="pt-8">
              <ProjectKpiCounters project={currentProject} />
            </div>
          </div>

          {/* Interactive Flowchart Process Engine */}
          <div id="project-flowchart-section">
            <InteractiveFlowchart project={currentProject} />
          </div>

          {/* Before vs. After Impact Engine */}
          <div id="project-before-after-section">
            <BeforeAfterComparison project={currentProject} />
          </div>

          {/* Challenges vs. Architectural Solutions Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            {/* Challenges */}
            <div className="lg:col-span-6 rounded-2xl bg-[#090b10] border border-neutral-800 p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-amber-400 font-semibold mb-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>TECHNICAL & STAKEHOLDER FRICTION</span>
                </div>
                <h4 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif] mb-6">
                  Core Challenges Faced
                </h4>

                <div className="space-y-4">
                  {currentProject.challenges.map((ch, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl bg-neutral-900/40 border border-neutral-800/80 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-amber-400 font-bold uppercase block">
                          CHALLENGE 0{idx + 1} // {ch.title}
                        </span>
                        <span className="text-[10px] font-mono text-neutral-400 px-2 py-0.5 rounded bg-black/40 border border-neutral-800">
                          {ch.impact}
                        </span>
                      </div>
                      <p className="text-sm font-medium text-neutral-300 font-sans leading-relaxed">
                        {ch.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-neutral-800/80 text-xs font-mono text-neutral-400">
                Required navigating legacy compliance, fragile dependencies, and executive alignment.
              </div>
            </div>

            {/* Solution */}
            <div className="lg:col-span-6 rounded-2xl bg-[#090b10] border border-neutral-800 p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-emerald-400 font-semibold mb-1">
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>ARCHITECTURAL RESOLUTION</span>
                </div>
                <h4 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif] mb-6">
                  Engineered Solution
                </h4>

                <div className="space-y-3 mb-4">
                  {currentProject.solution.map((sol, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl bg-neutral-900/40 border border-neutral-800/80 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white font-sans">{sol.title}</span>
                        <span className="text-[10px] font-mono text-emerald-400">{sol.techHighlight}</span>
                      </div>
                      <p className="text-sm text-neutral-200 font-sans leading-relaxed">
                        {sol.description}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Categorized Tech Stack */}
                {currentProject.technologiesCategorized && (
                  <div className="space-y-3 pt-2">
                    <span className="text-xs font-mono uppercase tracking-wider text-neutral-400 block">
                      Production Technology Stack:
                    </span>
                    <div className="space-y-2">
                      {currentProject.technologiesCategorized.map((techGroup, sIdx) => (
                        <div
                          key={sIdx}
                          className="flex flex-col sm:flex-row sm:items-center gap-2 text-xs font-mono"
                        >
                          <span className="w-28 text-neutral-400 shrink-0 capitalize">
                            {techGroup.category}:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {techGroup.items.map((tech, tIdx) => (
                              <span
                                key={tIdx}
                                className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-700/80 text-neutral-200"
                              >
                                {tech}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-neutral-800/80 flex items-center justify-between text-xs font-mono">
                <span className="text-emerald-400 font-bold">100% OPERATIONAL READY</span>
                <span className="text-neutral-400">Zero Unhandled Exceptions</span>
              </div>
            </div>
          </div>

          {/* Interactive Implementation Timeline */}
          {currentProject.milestones && (
            <div id="project-timeline-section">
              <ProjectTimeline project={currentProject} />
            </div>
          )}

          {/* Tiered Production Architecture */}
          {currentProject.architectureLayers && (
            <div id="project-architecture-section">
              <ArchitectureDiagram project={currentProject} />
            </div>
          )}

          {/* Key Learnings & Strategic Takeaways */}
          {currentProject.keyLearnings && currentProject.keyLearnings.length > 0 && (
            <div className="rounded-2xl bg-gradient-to-r from-[#090b10] via-[#10131d] to-[#090b10] border border-neutral-800 p-6 sm:p-8 shadow-2xl">
              <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-[#ea580c] font-semibold mb-1">
                <BookOpen className="w-3.5 h-3.5" />
                <span>STRATEGIC EXECUTIVE TAKEAWAYS // CONSULTING WISDOM</span>
              </div>
              <h4 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif] mb-6">
                Key Engineering & Leadership Learnings
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {currentProject.keyLearnings.map((learning, lIdx) => (
                  <div
                    key={lIdx}
                    className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800/80 space-y-2 flex flex-col justify-between hover:border-neutral-700 transition-all"
                  >
                    <div>
                      <span className="text-[10px] font-mono text-[#ea580c] font-bold block mb-1">
                        PRINCIPLE 0{lIdx + 1}
                      </span>
                      <p className="text-xs sm:text-sm text-neutral-300 font-sans leading-relaxed">
                        "{learning}"
                      </p>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-500 pt-3 border-t border-neutral-800/60">
                      Applied across Tier 1 deployments
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
