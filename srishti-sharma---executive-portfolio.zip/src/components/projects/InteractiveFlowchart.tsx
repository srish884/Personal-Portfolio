import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Play,
  Pause,
  RotateCcw,
  Radio,
  Cpu,
  Brain,
  FileText,
  ShieldCheck,
  Database,
  Sliders,
  AlertTriangle,
  BarChart2,
  Send,
  FileSpreadsheet,
  CheckSquare,
  Code,
  Mail,
  Shield,
  Activity,
  ArrowRight,
  Terminal,
  Zap,
} from 'lucide-react';
import { ProjectCaseStudy } from '../../types';

interface InteractiveFlowchartProps {
  project: ProjectCaseStudy;
}

// Icon mapper for dynamic nodes
const renderNodeIcon = (iconName: string) => {
  switch (iconName) {
    case 'Radio':
      return <Radio className="w-5 h-5 text-amber-400" />;
    case 'Cpu':
      return <Cpu className="w-5 h-5 text-cyan-400" />;
    case 'Brain':
      return <Brain className="w-5 h-5 text-purple-400" />;
    case 'FileText':
      return <FileText className="w-5 h-5 text-emerald-400" />;
    case 'ShieldCheck':
    case 'Shield':
      return <ShieldCheck className="w-5 h-5 text-emerald-400" />;
    case 'Database':
      return <Database className="w-5 h-5 text-blue-400" />;
    case 'Sliders':
      return <Sliders className="w-5 h-5 text-indigo-400" />;
    case 'AlertTriangle':
      return <AlertTriangle className="w-5 h-5 text-amber-400" />;
    case 'BarChart2':
      return <BarChart2 className="w-5 h-5 text-teal-400" />;
    case 'Send':
    case 'Mail':
      return <Mail className="w-5 h-5 text-[#ea580c]" />;
    case 'FileSpreadsheet':
      return <FileSpreadsheet className="w-5 h-5 text-emerald-400" />;
    case 'CheckSquare':
      return <CheckSquare className="w-5 h-5 text-cyan-400" />;
    case 'Code':
      return <Code className="w-5 h-5 text-purple-400" />;
    default:
      return <Activity className="w-5 h-5 text-neutral-400" />;
  }
};

export const InteractiveFlowchart: React.FC<InteractiveFlowchartProps> = ({ project }) => {
  const nodes = project.dataFlowNodes || [];
  const [selectedNodeIndex, setSelectedNodeIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  // Auto-play pulse through the pipeline
  useEffect(() => {
    if (!isPlaying || nodes.length === 0) return;
    const interval = setInterval(() => {
      setSelectedNodeIndex((prev) => (prev + 1) % nodes.length);
    }, 3200);
    return () => clearInterval(interval);
  }, [isPlaying, nodes.length]);

  const activeNode = nodes[selectedNodeIndex] || nodes[0];

  return (
    <div className="rounded-2xl bg-[#090b10] border border-neutral-800 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
      {/* Background subtle telemetry grid */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]" />

      {/* Header bar */}
      <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800/80">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono tracking-widest uppercase text-[#ea580c] font-semibold mb-1">
            <Zap className="w-3.5 h-3.5" />
            <span>INTERACTIVE WORKFLOW ENGINE // END-TO-END PIPELINE</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif]">
            Live Data Flow & Process Orchestration
          </h3>
          <p className="text-xs text-neutral-400 font-mono mt-0.5">
            Click any node to inspect data contracts, telemetry latency, and step transformations.
          </p>
        </div>

        {/* Playback Controls */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-700 text-xs font-mono text-neutral-200 hover:text-white hover:border-neutral-500 transition-colors shadow-sm"
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 text-amber-400" />
                <span>Pause Flow</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 text-emerald-400" />
                <span>Resume Simulation</span>
              </>
            )}
          </button>

          <button
            onClick={() => setSelectedNodeIndex(0)}
            className="p-2 rounded-lg bg-neutral-900 border border-neutral-700 text-neutral-400 hover:text-white transition-colors"
            title="Restart flow from Step 01"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Animated Pipeline Stage Nodes */}
      <div className="relative z-10 my-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 relative">
          {nodes.map((node, idx) => {
            const isSelected = selectedNodeIndex === idx;
            const isPassed = idx < selectedNodeIndex;

            return (
              <div
                key={node.id}
                onClick={() => {
                  setSelectedNodeIndex(idx);
                  setIsPlaying(false);
                }}
                className={`relative p-4 rounded-xl cursor-pointer transition-all duration-300 flex flex-col justify-between border backdrop-blur-md ${
                  isSelected
                    ? 'bg-neutral-900/90 border-[#ea580c] shadow-lg shadow-[#ea580c]/15 -translate-y-1'
                    : isPassed
                    ? 'bg-[#10131b]/80 border-neutral-700/80 hover:border-neutral-600'
                    : 'bg-[#0d0f15]/60 border-neutral-800/80 hover:border-neutral-700'
                }`}
              >
                {/* Active Indicator Pulse Glow */}
                {isSelected && (
                  <motion.div
                    layoutId="activeFlowGlow"
                    className="absolute inset-0 rounded-xl bg-gradient-to-tr from-[#ea580c]/10 to-transparent pointer-events-none"
                    transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                  />
                )}

                {/* Step number & Latency tag */}
                <div className="flex items-center justify-between mb-3">
                  <span
                    className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                      isSelected
                        ? 'bg-[#ea580c] text-white'
                        : isPassed
                        ? 'bg-neutral-800 text-emerald-400'
                        : 'bg-neutral-900 text-neutral-500'
                    }`}
                  >
                    STEP {node.stepNumber}
                  </span>

                  {node.latency && (
                    <span className="text-[10px] font-mono text-neutral-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      {node.latency}
                    </span>
                  )}
                </div>

                {/* Icon & Title */}
                <div className="space-y-1 my-1">
                  <div className="p-2 w-fit rounded-lg bg-black/40 border border-neutral-800 mb-2">
                    {renderNodeIcon(node.icon)}
                  </div>
                  <h4 className="text-sm font-bold text-white font-sans leading-tight">
                    {node.title}
                  </h4>
                  <p className="text-[11px] font-mono text-neutral-400 leading-snug">
                    {node.subtitle}
                  </p>
                </div>

                {/* Status footer pill */}
                <div className="mt-3 pt-2.5 border-t border-neutral-800/60 flex items-center justify-between text-[10px] font-mono">
                  <span className={isSelected ? 'text-[#ea580c] font-bold' : 'text-neutral-500'}>
                    {isSelected ? '● ACTIVE TELEMETRY' : isPassed ? '✓ COMPLETED' : '○ QUEUED'}
                  </span>
                  <span className="text-neutral-500">→</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Deep-Dive Payload & Role Inspector for Selected Node */}
      {activeNode && (
        <AnimatePresence mode="wait">
          <motion.div
            key={activeNode.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="relative z-10 rounded-xl bg-[#0c0e14] border border-neutral-800 p-5 sm:p-6"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Architectural Description */}
              <div className="lg:col-span-6 space-y-3">
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
                  <span className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-700 text-neutral-300 font-bold">
                    STAGE {activeNode.stepNumber} DEEP-DIVE
                  </span>
                  <span>//</span>
                  <span className="text-white font-semibold">{activeNode.title}</span>
                </div>

                <p className="text-sm text-neutral-300 leading-relaxed font-sans">
                  {activeNode.description}
                </p>

                <div className="pt-2 flex flex-wrap items-center gap-3 text-xs font-mono text-neutral-400">
                  <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800">
                    <Activity className="w-3.5 h-3.5 text-emerald-400" />
                    Latency: {activeNode.latency || 'Real-Time'}
                  </span>
                  <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#ea580c]" />
                    Audit: Immutable Trace
                  </span>
                </div>
              </div>

              {/* Right Column: Code/JSON Schema Contract */}
              <div className="lg:col-span-6 space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400 px-1">
                  <span className="flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-neutral-500" />
                    PAYLOAD SCHEMA / STATE CONTRACT
                  </span>
                  <span className="text-emerald-400 font-bold">VALIDATED JSON</span>
                </div>

                <div className="rounded-lg bg-black/90 border border-neutral-800 p-3.5 font-mono text-xs text-neutral-300 overflow-x-auto shadow-inner leading-relaxed">
                  <pre className="text-emerald-300/90 whitespace-pre-wrap break-all">
                    {activeNode.payloadExample ||
                      JSON.stringify(
                        {
                          step: activeNode.stepNumber,
                          stage: activeNode.title,
                          status: 'PROCESSED_DETERMINISTICALLY',
                          governance: 'TIER_1_COMPLIANT',
                        },
                        null,
                        2
                      )}
                  </pre>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
};
