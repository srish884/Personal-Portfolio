import React from 'react';
import {
  X,
  ArrowUpRight,
  Github,
  CheckCircle2,
  Cpu,
  Layers,
  Sparkles,
  TrendingUp,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import { ProjectCaseStudy } from '../types';

interface ProjectModalProps {
  project: ProjectCaseStudy | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-10 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0f1118] border border-neutral-700/80 shadow-2xl p-6 sm:p-10 text-neutral-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close project details"
          className="absolute top-5 right-5 w-9 h-9 rounded-full bg-neutral-900 border border-neutral-700 flex items-center justify-center text-neutral-400 hover:text-white hover:border-neutral-500 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-3 border-b border-neutral-800 pb-6 mb-8 pr-10">
          <div className="flex flex-wrap items-center gap-3">
            <span className="px-3 py-1 rounded bg-neutral-900 border border-neutral-700 text-xs font-mono text-neutral-300">
              {project.number}
            </span>
            <span className="text-xs font-mono text-neutral-500">
              {project.date}
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-xs font-mono">
              {project.badge}
            </span>
          </div>

          <h2
            id="project-modal-title"
            className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight font-['Syne',sans-serif]"
          >
            {project.title}
          </h2>

          <div className="flex flex-wrap gap-2 pt-1">
            {project.tags.map((tag, i) => (
              <span
                key={i}
                className="px-2.5 py-1 rounded bg-neutral-900/90 border border-neutral-800 text-xs font-mono text-neutral-400"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Summary & Architecture Overview */}
        <div className="space-y-6 mb-8">
          <div>
            <h3 className="text-xs font-mono uppercase tracking-widest text-neutral-500 mb-2">
              // EXECUTIVE SUMMARY
            </h3>
            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
              {project.summary}
            </p>
          </div>

          <div className="p-5 rounded-xl bg-neutral-900/70 border border-neutral-800">
            <h4 className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-2 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-emerald-400" />
              Technical Architecture & System Design
            </h4>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed font-mono">
              {project.architectureOverview}
            </p>
          </div>
        </div>

        {/* Step-by-Step Interactive Workflow Pipeline */}
        <div className="space-y-4 mb-8">
          <h3 className="text-xs font-mono uppercase tracking-widest text-neutral-500">
            // END-TO-END PIPELINE ARCHITECTURE
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {project.workflowSteps.map((step, i) => (
              <div
                key={i}
                className="p-4 rounded-xl bg-neutral-900/50 border border-neutral-800 flex flex-col justify-between"
              >
                <div>
                  <span className="text-[10px] font-mono text-neutral-500 block mb-1">
                    STEP {step.step}
                  </span>
                  <h4 className="text-sm font-semibold text-neutral-100 mb-1">
                    {step.title}
                  </h4>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Core Technical Highlights */}
        <div className="space-y-3 mb-8">
          <h3 className="text-xs font-mono uppercase tracking-widest text-neutral-500">
            // KEY CAPABILITIES & SPECIFICATIONS
          </h3>
          <div className="space-y-2">
            {project.highlights.map((h, i) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3.5 rounded-xl bg-neutral-900/30 border border-neutral-800/80 text-xs sm:text-sm text-neutral-300"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{h}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Modeled Impact & Disclaimer */}
        <div className="p-5 rounded-xl bg-gradient-to-r from-neutral-900 to-[#141620] border border-neutral-700/80 mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider block flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" />
              Verified / Modeled Outcome:
            </span>
            <div className="text-lg sm:text-xl font-bold text-white font-mono">
              {project.modeledImpact}
            </div>
            {project.impactDisclaimer && (
              <p className="text-xs text-neutral-400 flex items-center gap-1.5 pt-1">
                <AlertCircle className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                <span>{project.impactDisclaimer}</span>
              </p>
            )}
          </div>

          {project.githubUrl && (
            <a
              href={project.githubUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-neutral-950 font-semibold text-xs font-mono tracking-wider uppercase hover:bg-neutral-200 transition-colors shrink-0"
            >
              <Github className="w-4 h-4" />
              <span>Inspect Code Repository</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          )}
        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-mono uppercase tracking-wider text-neutral-200 transition-colors"
          >
            Close Case Study
          </button>
        </div>
      </div>
    </div>
  );
};
