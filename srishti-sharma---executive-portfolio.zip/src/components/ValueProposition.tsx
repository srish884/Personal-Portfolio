import React, { useState } from 'react';
import {
  Compass,
  Puzzle,
  Bot,
  Layers,
  Users,
  Kanban,
  MessageSquare,
  Flame,
  ArrowUpRight,
  Sparkles,
} from 'lucide-react';
import { VALUE_CARDS } from '../data/portfolioData';

export const ValueProposition: React.FC = () => {
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);

  const getIcon = (icon: string) => {
    switch (icon) {
      case 'Compass':
        return <Compass className="w-5 h-5 text-amber-400" />;
      case 'Puzzle':
        return <Puzzle className="w-5 h-5 text-cyan-400" />;
      case 'Bot':
        return <Bot className="w-5 h-5 text-emerald-400" />;
      case 'Layers':
        return <Layers className="w-5 h-5 text-purple-400" />;
      case 'Users':
        return <Users className="w-5 h-5 text-blue-400" />;
      case 'Kanban':
        return <Kanban className="w-5 h-5 text-rose-400" />;
      case 'MessageSquare':
        return <MessageSquare className="w-5 h-5 text-teal-400" />;
      case 'Flame':
        return <Flame className="w-5 h-5 text-orange-400" />;
      default:
        return <Sparkles className="w-5 h-5 text-neutral-400" />;
    }
  };

  return (
    <section id="value" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 04 · VALUE PROPOSITION</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>COMPETENCE · CURIOSITY · EXECUTION</span>
            </div>
            <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              THE VALUE I BRING
            </h2>
          </div>

          <div className="max-w-lg text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              Engineered for High-Consequence Environments.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              Click or hover over any capability to see how strategic thinking, relentless execution, and technical curiosity translate into tangible business dividends.
            </p>
          </div>
        </div>

        {/* 8 Distinct Interactive Animated Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {VALUE_CARDS.map((val, idx) => {
            const isExpanded = selectedCardId === val.id;
            return (
              <div
                key={val.id}
                id={`value-card-${val.id}`}
                onClick={() => setSelectedCardId(isExpanded ? null : val.id)}
                className={`group cursor-pointer rounded-2xl p-6 border transition-all duration-300 flex flex-col justify-between relative overflow-hidden ${
                  isExpanded
                    ? 'bg-[#151722] border-neutral-500 shadow-2xl shadow-neutral-950 scale-[1.02]'
                    : 'bg-[#10121a]/70 border-neutral-800/90 hover:bg-[#141620] hover:border-neutral-700 hover:-translate-y-1'
                }`}
              >
                <div>
                  {/* Top Bar with Icon and Index */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-10 h-10 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center group-hover:scale-105 transition-transform">
                      {getIcon(val.icon)}
                    </div>
                    <span className="text-xs font-mono text-neutral-600 group-hover:text-neutral-400 transition-colors">
                      0{idx + 1}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg font-bold text-white font-['Syne',sans-serif] mb-2 group-hover:text-neutral-100 transition-colors">
                    {val.title}
                  </h3>

                  {/* Short Description */}
                  <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                    {val.shortDesc}
                  </p>

                  {/* Expandable Deep Dive */}
                  {isExpanded && (
                    <div className="pt-3 border-t border-neutral-800/80 animate-in fade-in slide-in-from-top-2 duration-200">
                      <p className="text-xs text-neutral-300 leading-relaxed font-sans mb-3">
                        {val.deepDive}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {val.keywords.map((kw, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-[10px] font-mono text-neutral-400"
                          >
                            {kw}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Footer prompt */}
                <div className="mt-4 pt-3 border-t border-neutral-800/60 flex items-center justify-between text-[11px] font-mono text-neutral-500 group-hover:text-neutral-300 transition-colors">
                  <span>{isExpanded ? 'Click to minimize' : 'Explore detail'}</span>
                  <ArrowUpRight className={`w-3.5 h-3.5 transition-transform duration-300 ${isExpanded ? 'rotate-90' : 'group-hover:translate-x-0.5 group-hover:-translate-y-0.5'}`} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
