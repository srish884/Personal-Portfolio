import React, { useState } from 'react';
import {
  Sparkles,
  Layers,
  Network,
  CheckCircle2,
  ArrowRight,
  Filter,
} from 'lucide-react';
import { CONSTELLATION_NODES } from '../data/portfolioData';
import { ConstellationNode } from '../types';

export const Constellation: React.FC = () => {
  const [selectedNode, setSelectedNode] = useState<ConstellationNode>(CONSTELLATION_NODES[0]);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All 10 Facets' },
    { id: 'strategy', label: 'Strategy & Analysis' },
    { id: 'technology', label: 'AI & Automation' },
    { id: 'delivery', label: 'Execution & Delivery' },
    { id: 'relationship', label: 'Client & Stakeholder' },
  ];

  const filteredNodes =
    activeCategory === 'all'
      ? CONSTELLATION_NODES
      : CONSTELLATION_NODES.filter((n) => n.category === activeCategory);

  // SVG Coordinates for radial network (center at 300, 300; radius 210)
  const centerX = 300;
  const centerY = 300;
  const radius = 210;

  const getNodeCoordinates = (index: number, total: number) => {
    const angle = (index * (360 / total) - 90) * (Math.PI / 180);
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle),
    };
  };

  return (
    <section id="constellation" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 05 · SYSTEMIC VERSATILITY</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>THE T-SHAPED PROFESSIONAL</span>
            </div>
            <h2 className="text-5xl sm:text-6xl md:text-8xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              IF YOU HIRE ME, YOU'RE NOT GETTING ONE PERSON.
            </h2>
          </div>

          <div className="max-w-md text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              You're getting a unique blend of business, technology, strategy, and execution.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              Not ten fragmented personas, but an interconnected system where each capability magnifies the other.
            </p>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap items-center gap-2 mb-8">
          <span className="text-xs font-mono text-neutral-500 mr-2 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5" />
            FILTER CAPABILITY LENS:
          </span>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1 rounded-full text-xs font-mono transition-all ${
                activeCategory === cat.id
                  ? 'bg-neutral-100 text-neutral-950 font-semibold'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Constellation Canvas & Interactive Focus Inspector */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left / Center: Interactive Constellation Visualizer */}
          <div className="lg:col-span-7 flex justify-center items-center relative py-6">
            <div className="relative w-full max-w-[580px] aspect-square flex items-center justify-center">
              {/* Background ambient orbits */}
              <div className="absolute inset-0 rounded-full border border-neutral-800/60 pointer-events-none" />
              <div className="absolute inset-16 rounded-full border border-neutral-800/40 border-dashed pointer-events-none" />
              <div className="absolute inset-32 rounded-full border border-neutral-800/20 pointer-events-none" />

              {/* SVG Network Lines */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 600 600">
                {/* Connecting lines from center to each node */}
                {CONSTELLATION_NODES.map((node, i) => {
                  const coords = getNodeCoordinates(i, CONSTELLATION_NODES.length);
                  const isSelected = selectedNode.id === node.id;
                  const isHovered = hoveredNodeId === node.id;
                  const isFiltered = activeCategory !== 'all' && node.category !== activeCategory;

                  return (
                    <g key={node.id}>
                      <line
                        x1={centerX}
                        y1={centerY}
                        x2={coords.x}
                        y2={coords.y}
                        stroke={
                          isSelected
                            ? '#ffffff'
                            : isHovered
                            ? '#9ca3af'
                            : isFiltered
                            ? '#1f2937'
                            : '#374151'
                        }
                        strokeWidth={isSelected ? 2 : 1}
                        strokeDasharray={isSelected ? 'none' : '4 4'}
                        opacity={isFiltered ? 0.2 : 0.8}
                        className="transition-all duration-300"
                      />
                    </g>
                  );
                })}

                {/* Outer circumference ring */}
                <circle
                  cx={centerX}
                  cy={centerY}
                  r={radius}
                  stroke="#262626"
                  strokeWidth="1"
                  strokeDasharray="2 4"
                  fill="none"
                />
              </svg>

              {/* Central Srishti Sharma Core Node */}
              <div
                className="relative z-20 w-28 sm:w-32 h-28 sm:h-32 rounded-full bg-gradient-to-b from-neutral-800 to-neutral-950 border-2 border-neutral-400 flex flex-col items-center justify-center p-3 text-center shadow-2xl shadow-black group cursor-pointer"
                title="Srishti Sharma - The Synthesis Core"
              >
                <div className="w-2 h-2 rounded-full bg-emerald-400 mb-1 animate-ping" />
                <span className="text-[10px] font-mono tracking-widest text-neutral-400 uppercase">
                  CORE SYNTHESIS
                </span>
                <span className="text-xs sm:text-sm font-bold text-white font-['Syne',sans-serif] leading-tight">
                  SRISHTI SHARMA
                </span>
                <span className="text-[9px] font-mono text-neutral-500 mt-0.5">
                  10-FACET INTERLOCK
                </span>
              </div>

              {/* 10 Surrounding Role Nodes */}
              {CONSTELLATION_NODES.map((node, i) => {
                const coords = getNodeCoordinates(i, CONSTELLATION_NODES.length);
                const isSelected = selectedNode.id === node.id;
                const isHovered = hoveredNodeId === node.id;
                const isFiltered = activeCategory !== 'all' && node.category !== activeCategory;

                // Position as percentage inside the 600x600 viewBox
                const leftPct = (coords.x / 600) * 100;
                const topPct = (coords.y / 600) * 100;

                return (
                  <button
                    key={node.id}
                    id={`constellation-node-${node.id}`}
                    onClick={() => setSelectedNode(node)}
                    onMouseEnter={() => setHoveredNodeId(node.id)}
                    onMouseLeave={() => setHoveredNodeId(null)}
                    style={{
                      left: `${leftPct}%`,
                      top: `${topPct}%`,
                      transform: 'translate(-50%, -50%)',
                    }}
                    className={`absolute z-30 transition-all duration-300 rounded-full flex items-center justify-center p-1.5 focus:outline-none ${
                      isFiltered ? 'opacity-20 pointer-events-none' : 'opacity-100'
                    }`}
                  >
                    <div
                      className={`px-3 py-1.5 rounded-full border text-[11px] font-mono tracking-wide whitespace-nowrap transition-all duration-300 shadow-xl ${
                        isSelected
                          ? 'bg-white text-neutral-950 border-white font-bold scale-110 shadow-white/20'
                          : isHovered
                          ? 'bg-neutral-800 text-white border-neutral-400 scale-105'
                          : 'bg-[#12141c] text-neutral-300 border-neutral-700/80 hover:border-neutral-500'
                      }`}
                    >
                      {node.label}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Selected Node Deep-Dive Inspector Panel */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-gradient-to-b from-[#141620] to-[#0e1017] border border-neutral-700/80 p-6 sm:p-8 shadow-2xl relative overflow-hidden animate-in fade-in duration-300">
              <div className="flex items-center justify-between gap-3 border-b border-neutral-800 pb-4 mb-5">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-neutral-200" />
                  <span className="text-xs font-mono tracking-widest uppercase text-neutral-400">
                    FACET FOCUS // {selectedNode.category.toUpperCase()}
                  </span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-neutral-900 border border-neutral-800 text-[10px] font-mono text-neutral-400">
                  CLICK ANY NODE TO EXPLORE
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Syne',sans-serif] mb-3">
                {selectedNode.label}
              </h3>

              <p className="text-sm text-neutral-300 leading-relaxed mb-6">
                {selectedNode.description}
              </p>

              {/* The Srishti Multiplier / Cross-Role Synergy */}
              <div className="p-4 rounded-xl bg-neutral-900/80 border border-neutral-800 mb-6">
                <span className="text-[11px] font-mono text-emerald-400 uppercase tracking-wider block mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Cross-Domain Multiplier Effect:
                </span>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  {selectedNode.synergy}
                </p>
              </div>

              {/* Key Skills */}
              <div>
                <span className="text-xs font-mono text-neutral-500 uppercase tracking-wider block mb-2">
                  Operational Core Skills:
                </span>
                <div className="flex flex-wrap gap-2">
                  {selectedNode.keySkills.map((sk, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 rounded-md bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-300"
                    >
                      {sk}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
