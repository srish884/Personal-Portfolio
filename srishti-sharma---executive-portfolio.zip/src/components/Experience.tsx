import React, { useState } from 'react';
import {
  Calendar,
  Building2,
  TrendingUp,
  CheckCircle2,
  Filter,
  ShieldAlert,
  Bot,
  Briefcase,
  Layers,
  ArrowUpRight,
} from 'lucide-react';
import { EXPERIENCE_DATA } from '../data/portfolioData';

export const Experience: React.FC = () => {
  const [activeTheme, setActiveTheme] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'responsibilities' | 'impact' | 'tech'>('responsibilities');

  const allThemes = ['All', ...EXPERIENCE_DATA.themes];

  return (
    <section id="experience" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 02 · TRACK RECORD</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>ENTERPRISE SCALE & HIGH-STAKES DELIVERY</span>
            </div>
            <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              EXPERIENCE
            </h2>
          </div>

          <div className="max-w-lg text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              Mission-Critical Trading Systems & Tier 1 Banking Desks.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              Operating at the center of institutional financial markets technology, turning high-pressure client demands into seamless product delivery and automated operational resilience.
            </p>
          </div>
        </div>

        {/* Experience Timeline Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#11131a] to-[#0a0c10] border border-neutral-800 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          {/* Top Company Header Bar */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-8 border-b border-neutral-800">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-3">
                <span className="px-3 py-1 rounded-md bg-neutral-100 text-neutral-950 font-bold text-xs font-mono tracking-wider">
                  ION GROUP
                </span>
                <span className="text-xs font-mono text-neutral-400 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-neutral-500" />
                  {EXPERIENCE_DATA.period}
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/60 text-emerald-400">
                  CURRENT ROLE
                </span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif]">
                {EXPERIENCE_DATA.role}
              </h3>
              <p className="text-xs sm:text-sm font-mono text-neutral-400 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-neutral-500 shrink-0" />
                <span>Client Base: <strong className="text-neutral-200">{EXPERIENCE_DATA.clientContext}</strong></span>
              </p>
            </div>

            {/* Metrics Quick Highlights */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800">
                <div className="text-xs font-mono text-neutral-500">Tier 1 Reach</div>
                <div className="text-base sm:text-lg font-bold text-white font-mono">Global Banks</div>
              </div>
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800">
                <div className="text-xs font-mono text-neutral-500">Workflow Velocity</div>
                <div className="text-base sm:text-lg font-bold text-emerald-400 font-mono">80% Faster</div>
              </div>
              <div className="p-3 rounded-xl bg-neutral-900/80 border border-neutral-800 col-span-2 sm:col-span-1">
                <div className="text-xs font-mono text-neutral-500">Platform Domain</div>
                <div className="text-base sm:text-lg font-bold text-neutral-200 font-mono">Repo / FI</div>
              </div>
            </div>
          </div>

          {/* Interactive Themes Explorer Filter */}
          <div className="py-6 border-b border-neutral-800">
            <div className="flex items-center gap-2 text-xs font-mono text-neutral-400 mb-3">
              <Filter className="w-3.5 h-3.5 text-neutral-500" />
              <span>EXPLORE BY CORE THEME:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {allThemes.map((theme) => {
                const isSelected = activeTheme === theme;
                return (
                  <button
                    key={theme}
                    onClick={() => setActiveTheme(theme)}
                    className={`px-3 py-1.5 rounded-full text-xs font-mono transition-all duration-200 ${
                      isSelected
                        ? 'bg-[#ea580c] text-white font-semibold shadow-lg shadow-[#ea580c]/20'
                        : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-white hover:border-neutral-700'
                    }`}
                  >
                    {theme}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Experience Narrative Summary */}
          <div className="py-6 border-b border-neutral-800">
            <p className="text-neutral-300 text-sm sm:text-base leading-relaxed">
              {EXPERIENCE_DATA.summary}
            </p>
          </div>

          {/* View Mode Tabs */}
          <div className="pt-6">
            <div className="flex items-center gap-4 border-b border-neutral-800/80 pb-3 mb-6">
              <button
                onClick={() => setActiveTab('responsibilities')}
                className={`text-xs font-mono uppercase tracking-wider pb-1 transition-colors relative ${
                  activeTab === 'responsibilities'
                    ? 'text-white font-semibold'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                Scope & Responsibilities
                {activeTab === 'responsibilities' && (
                  <div className="absolute bottom-[-13px] left-0 right-0 h-0.5 bg-neutral-200" />
                )}
              </button>
              <button
                onClick={() => setActiveTab('impact')}
                className={`text-xs font-mono uppercase tracking-wider pb-1 transition-colors relative ${
                  activeTab === 'impact'
                    ? 'text-white font-semibold'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                Quantified Impact & Multipliers
                {activeTab === 'impact' && (
                  <div className="absolute bottom-[-13px] left-0 right-0 h-0.5 bg-neutral-200" />
                )}
              </button>
              <button
                onClick={() => setActiveTab('tech')}
                className={`text-xs font-mono uppercase tracking-wider pb-1 transition-colors relative ${
                  activeTab === 'tech'
                    ? 'text-white font-semibold'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                Systems & Tooling Stack
                {activeTab === 'tech' && (
                  <div className="absolute bottom-[-13px] left-0 right-0 h-0.5 bg-neutral-200" />
                )}
              </button>
            </div>

            {/* Tab 1: Scope & Responsibilities */}
            {activeTab === 'responsibilities' && (
              <div className="space-y-4 animate-in fade-in duration-300">
                {EXPERIENCE_DATA.responsibilities.map((resp, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-3.5 p-4 rounded-xl bg-neutral-900/40 border border-neutral-800/80 hover:border-neutral-700 transition-colors"
                  >
                    <span className="w-6 h-6 rounded-full bg-neutral-800 text-neutral-300 font-mono text-xs flex items-center justify-center shrink-0 mt-0.5">
                      0{idx + 1}
                    </span>
                    <p className="text-sm text-neutral-200 leading-relaxed">
                      {resp}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 2: Quantified Impact */}
            {activeTab === 'impact' && (
              <div className="space-y-4 animate-in fade-in duration-300">
                {EXPERIENCE_DATA.impactHighlights.map((imp, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-3.5 p-4 rounded-xl bg-emerald-950/20 border border-emerald-900/40 hover:border-emerald-700/60 transition-colors"
                  >
                    <TrendingUp className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-neutral-200 leading-relaxed font-medium">
                        {imp}
                      </p>
                      <span className="text-[11px] font-mono text-emerald-400/80 mt-1 block">
                        Verified Outcome // Direct Account Leadership
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Tab 3: Systems & Tooling Stack */}
            {activeTab === 'tech' && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 animate-in fade-in duration-300">
                {EXPERIENCE_DATA.technologiesUsed.map((tech, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center gap-2 text-xs font-mono text-neutral-300"
                  >
                    <div className="w-2 h-2 rounded-full bg-neutral-500" />
                    <span>{tech}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
