import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize2,
  RotateCcw,
  Upload,
  Link as LinkIcon,
  X,
  Sparkles,
  CheckCircle2,
  FileVideo,
} from 'lucide-react';
import {
  saveVideoFileToDB,
  loadSavedVideoFromDB,
  clearSavedVideoFromDB,
  saveExternalVideoUrl,
} from '../utils/videoStorage';

interface ExecutiveVideoCardProps {
  onClose: () => void;
  placeholderImage: string;
}

export const ExecutiveVideoCard: React.FC<ExecutiveVideoCardProps> = ({
  onClose,
  placeholderImage,
}) => {
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [inputUrl, setInputUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load existing video from IndexedDB on mount
  useEffect(() => {
    let isMounted = true;
    loadSavedVideoFromDB().then((src) => {
      if (isMounted && src) {
        setVideoSrc(src);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const blobUrl = await saveVideoFileToDB(file);
      setVideoSrc(blobUrl);
      setUploadSuccess(true);
      setTimeout(() => setUploadSuccess(false), 3000);
      setIsPlaying(true);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play().catch(() => {});
      }
    } catch (err) {
      console.error('Failed to save video', err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleSetUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;
    saveExternalVideoUrl(inputUrl.trim());
    setVideoSrc(inputUrl.trim());
    setShowUrlInput(false);
    setInputUrl('');
    setIsPlaying(true);
  };

  const handleResetVideo = async () => {
    await clearSavedVideoFromDB();
    setVideoSrc(null);
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const current = videoRef.current.currentTime;
    const total = videoRef.current.duration || 1;
    setProgress((current / total) * 100);
    setDuration(total);
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    videoRef.current.currentTime = pos * (videoRef.current.duration || 0);
  };

  const handleLoadSampleVideo = () => {
    const sampleUrl = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4';
    saveExternalVideoUrl(sampleUrl);
    setVideoSrc(sampleUrl);
    setIsPlaying(true);
  };

  return (
    <div className="relative w-[340px] sm:w-[420px] md:w-[480px] lg:w-[520px] aspect-[3/4] max-h-[580px] rounded-3xl overflow-hidden bg-neutral-950 text-white shadow-2xl border border-neutral-700/80 flex flex-col justify-between z-30 animate-in fade-in zoom-in-95 duration-300">
      {/* Hidden file input for uploading MP4 / WebM video */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/ogg,video/quicktime"
        className="hidden"
        onChange={handleFileUpload}
      />

      {/* Top Header Bar */}
      <div className="relative z-20 flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/90 via-black/50 to-transparent">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
          <span className="text-[11px] font-mono font-bold tracking-wider uppercase text-neutral-200">
            Executive Intro // Srishti Sharma
          </span>
        </div>
        <button
          onClick={onClose}
          className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-neutral-300 hover:text-white transition-colors"
          title="Return to 3D Portrait"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Main Video Viewport */}
      <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-black">
        {videoSrc ? (
          /* Render Active Video */
          <div className="relative w-full h-full flex items-center justify-center group">
            <video
              ref={videoRef}
              src={videoSrc}
              className="w-full h-full object-cover"
              onTimeUpdate={handleTimeUpdate}
              onEnded={() => setIsPlaying(false)}
              playsInline
              autoPlay
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />

            {/* Click on video to toggle play */}
            <div
              className="absolute inset-0 cursor-pointer flex items-center justify-center"
              onClick={togglePlay}
            >
              {!isPlaying && (
                <div className="w-16 h-16 rounded-full bg-black/70 border border-white/30 backdrop-blur-md flex items-center justify-center text-white shadow-2xl transition-transform hover:scale-110">
                  <Play className="w-7 h-7 translate-x-0.5 fill-white" />
                </div>
              )}
            </div>

            {/* Bottom Floating Video Controls */}
            <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/90 via-black/60 to-transparent opacity-95 transition-opacity">
              {/* Progress Scrub Bar */}
              <div
                className="w-full h-1.5 bg-neutral-700/80 rounded-full mb-2.5 cursor-pointer relative overflow-hidden"
                onClick={handleSeek}
              >
                <div
                  className="h-full bg-orange-500 rounded-full transition-all duration-100"
                  style={{ width: `${progress}%` }}
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-3">
                  <button
                    onClick={togglePlay}
                    className="p-1 rounded hover:bg-white/10 text-white transition-colors"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                  </button>
                  <button
                    onClick={toggleMute}
                    className="p-1 rounded hover:bg-white/10 text-white transition-colors"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4 text-neutral-400" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <span className="text-[10px] text-neutral-400">
                    {Math.floor((duration * (progress / 100)) / 60)}:
                    {Math.floor((duration * (progress / 100)) % 60).toString().padStart(2, '0')} /{' '}
                    {Math.floor(duration / 60)}:{Math.floor(duration % 60).toString().padStart(2, '0')}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[10px] text-neutral-200 transition-colors flex items-center gap-1"
                    title="Upload another video"
                  >
                    <Upload className="w-3 h-3" />
                    <span>Replace</span>
                  </button>
                  <button
                    onClick={handleResetVideo}
                    className="p-1 rounded hover:bg-rose-950/60 text-neutral-400 hover:text-rose-400 transition-colors"
                    title="Remove Video"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Placeholder State: Ready to receive video upload */
          <div className="relative w-full h-full flex flex-col items-center justify-between p-6 text-center">
            {/* Subtle background poster */}
            <div className="absolute inset-0 opacity-20 pointer-events-none overflow-hidden">
              <img
                src={placeholderImage}
                alt="Portrait backdrop"
                className="w-full h-full object-cover object-top blur-sm"
              />
              <div className="absolute inset-0 bg-neutral-950/70" />
            </div>

            {/* Top Badge */}
            <div className="relative z-10 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-[11px] font-mono text-neutral-300">
              <Sparkles className="w-3.5 h-3.5 text-orange-400" />
              <span>Video Slot Configured</span>
            </div>

            {/* Center Callout: Upload or Demo */}
            <div className="relative z-10 max-w-xs space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-600 to-amber-500 mx-auto flex items-center justify-center text-white shadow-xl shadow-orange-600/30">
                <FileVideo className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white tracking-tight">
                Upload Your Video Intro
              </h3>
              <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                Attach your personal video introduction here. It will automatically play directly in this card whenever recruiters or hiring managers click play.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col gap-2 pt-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="w-full py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs font-mono uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-orange-600/30 cursor-pointer active:scale-95"
                >
                  <Upload className="w-4 h-4" />
                  <span>{isUploading ? 'Saving Video...' : 'Upload Video (.mp4 / .webm)'}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowUrlInput(!showUrlInput)}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-neutral-900 border border-neutral-700 hover:border-neutral-500 text-neutral-300 text-[11px] font-mono transition-colors flex items-center justify-center gap-1.5"
                  >
                    <LinkIcon className="w-3 h-3" />
                    <span>Paste Video URL</span>
                  </button>
                  <button
                    onClick={handleLoadSampleVideo}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-neutral-900 border border-neutral-700 hover:border-neutral-500 text-neutral-300 text-[11px] font-mono transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Play className="w-3 h-3 text-orange-400" />
                    <span>Test Sample Clip</span>
                  </button>
                </div>
              </div>

              {/* URL Input Dropdown */}
              {showUrlInput && (
                <form onSubmit={handleSetUrl} className="pt-2 flex items-center gap-1.5">
                  <input
                    type="url"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    placeholder="https://... video URL"
                    className="flex-1 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-700 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-orange-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-orange-600 text-xs font-bold text-white hover:bg-orange-500"
                  >
                    Set
                  </button>
                </form>
              )}
            </div>

            {/* Bottom Suggested Discussion Points */}
            <div className="relative z-10 w-full pt-3 border-t border-neutral-800 text-[10px] font-mono text-neutral-400 flex items-center justify-around">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" /> 60s Briefing
              </span>
              <span>•</span>
              <span>Banking & SME Delivery</span>
              <span>•</span>
              <span>AI Multi-Agent Vision</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Footer Bar */}
      <div className="relative z-20 px-4 py-2.5 bg-neutral-900/90 border-t border-neutral-800 flex items-center justify-between text-[11px] font-mono text-neutral-400">
        <span>Click below to switch back anytime</span>
        <button
          onClick={onClose}
          className="text-neutral-200 hover:text-white underline font-semibold transition-colors"
        >
          Return to 3D Cutout
        </button>
      </div>
    </div>
  );
};
