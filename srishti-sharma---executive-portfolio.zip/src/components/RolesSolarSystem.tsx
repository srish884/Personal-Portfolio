import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Orbit,
  Briefcase,
  Layers,
  Users,
  Compass,
  CheckCircle2,
  X,
  ExternalLink,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface TargetRole {
  id: string;
  title: string;
  category: string;
  orbitRadius: number; // in pixels
  speed: number; // rotation duration in seconds
  startAngle: number; // starting angle in degrees
  color: string;
  glowColor: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}

export const RolesSolarSystem: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [selectedRole, setSelectedRole] = useState<TargetRole | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const roles: TargetRole[] = [
    {
      id: 'product',
      title: 'Product Manager / Owner',
      category: 'Product Strategy & Execution',
      orbitRadius: 95,
      speed: 24,
      startAngle: 0,
      color: 'bg-amber-500',
      glowColor: 'shadow-amber-500/50',
      icon: Compass,
      description: 'Product discovery, PRD definition, user telemetry, feature prioritization, and AI-accelerated roadmaps.',
    },
    {
      id: 'tam',
      title: 'Technical Account Management',
      category: 'Strategic Client Advisory',
      orbitRadius: 95,
      speed: 24,
      startAngle: 180,
      color: 'bg-orange-500',
      glowColor: 'shadow-orange-500/50',
      icon: Briefcase,
      description: 'Trusted executive technical partner for Tier-1 banks, architectural governance, and long-term account health.',
    },
    {
      id: 'project',
      title: 'Project Management',
      category: 'Delivery Governance',
      orbitRadius: 165,
      speed: 38,
      startAngle: 45,
      color: 'bg-rose-500',
      glowColor: 'shadow-rose-500/50',
      icon: CheckCircle2,
      description: 'Milestone tracking, sprint orchestration, resource allocation, and predictable time-to-market.',
    },
    {
      id: 'program',
      title: 'Program Management',
      category: 'Enterprise Transformation',
      orbitRadius: 165,
      speed: 38,
      startAngle: 165,
      color: 'bg-violet-500',
      glowColor: 'shadow-violet-500/50',
      icon: Layers,
      description: 'Cross-functional alignment across engineering, product, sales, and compliance for high-stakes initiatives.',
    },
    {
      id: 'delivery',
      title: 'Client Delivery / Stakeholder Management',
      category: 'Relationship & Value Realization',
      orbitRadius: 165,
      speed: 38,
      startAngle: 285,
      color: 'bg-emerald-500',
      glowColor: 'shadow-emerald-500/50',
      icon: Users,
      description: 'Executive sponsorship, SLA steering, client advocacy, and steering steering committees for global financial institutions.',
    },
  ];

  const activeOrHovered = isOpen || isHovered;

  return (
    <div
      ref={containerRef}
      className="relative select-none z-40"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
      }}
    >
      {/* TRIGGER BUTTON: "Roles I'm Interested In" */}
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="group relative inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-neutral-950 text-white border border-neutral-700/80 hover:border-orange-500/80 shadow-md hover:shadow-orange-500/15 transition-all duration-300 cursor-pointer"
        aria-expanded={activeOrHovered}
        aria-haspopup="dialog"
      >
        {/* Pulsing Cosmic Icon */}
        <div className="relative flex items-center justify-center w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 group-hover:bg-orange-500 group-hover:text-neutral-950 transition-colors">
          <Orbit className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '8s' }} />
        </div>

        {/* Button Typography */}
        <span className="text-xs font-mono font-bold tracking-tight text-neutral-100 group-hover:text-white">
          Roles I&apos;m Interested In
        </span>

        {/* Orbital Counter Pill */}
        <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded-full bg-neutral-800 text-[10px] font-mono text-orange-400 border border-neutral-700 group-hover:border-orange-500/50">
          5 Targets
        </span>

        {/* Glow indicator beacon */}
        <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
      </button>

      {/* SOLAR SYSTEM ORBITAL OVERLAY */}
      <AnimatePresence>
        {activeOrHovered && (
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 10 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="absolute right-0 top-full mt-3 w-[330px] sm:w-[470px] md:w-[500px] rounded-2xl bg-neutral-950/95 border border-neutral-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] backdrop-blur-2xl p-4 sm:p-5 z-50 text-white overflow-hidden"
          >
            {/* Ambient Celestial Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Header / Controls */}
            <div className="flex items-center justify-between border-b border-neutral-800/80 pb-3 mb-2 relative z-10">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-orange-400 animate-ping" />
                <span className="text-[11px] font-mono uppercase tracking-widest text-neutral-300 font-bold">
                  Target Opportunities · Solar System
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsPaused((prev) => !prev)}
                  className="text-[10px] font-mono px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white transition-colors"
                >
                  {isPaused ? '▶ Resume' : '⏸ Pause'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsOpen(false);
                    setIsHovered(false);
                  }}
                  className="w-5 h-5 rounded-full flex items-center justify-center text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                  aria-label="Close"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* SOLAR SYSTEM ORBIT CANVAS */}
            <div
              className="relative w-full h-[320px] sm:h-[350px] flex items-center justify-center overflow-hidden my-1"
              onMouseEnter={() => setIsPaused(true)}
              onMouseLeave={() => setIsPaused(false)}
            >
              {/* Central Star: Srishti Sharma Core */}
              <div className="relative z-30 flex flex-col items-center justify-center">
                <motion.div
                  className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-600 flex items-center justify-center text-white shadow-[0_0_35px_rgba(249,115,22,0.6)] border-2 border-white/40 cursor-default"
                  animate={{
                    scale: [1, 1.05, 1],
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 3,
                    ease: 'easeInOut',
                  }}
                >
                  <span className="text-xs font-black tracking-tight font-['Syne',sans-serif]">
                    SRISHTI
                  </span>
                </motion.div>
                <span className="mt-1 text-[9px] font-mono tracking-widest text-neutral-400 uppercase font-semibold">
                  Gravitational Hub
                </span>
              </div>

              {/* Inner Orbit Track Ring (Radius: 95px) */}
              <div className="absolute w-[190px] h-[190px] rounded-full border border-dashed border-neutral-700/60 pointer-events-none" />

              {/* Outer Orbit Track Ring (Radius: 165px, scaled down on mobile) */}
              <div className="absolute w-[280px] sm:w-[330px] h-[280px] sm:h-[330px] rounded-full border border-dashed border-neutral-800/80 pointer-events-none" />

              {/* Inner Orbiting System (2 Roles) */}
              <motion.div
                className="absolute w-[190px] h-[190px] rounded-full pointer-events-none"
                animate={isPaused ? {} : { rotate: 360 }}
                transition={{
                  repeat: Infinity,
                  duration: 24,
                  ease: 'linear',
                }}
              >
                {roles
                  .filter((r) => r.orbitRadius === 95)
                  .map((role) => {
                    const isSelected = selectedRole?.id === role.id;
                    const Icon = role.icon;
                    // Position at startAngle on a 190px circle (radius 95px)
                    // Angle in radians
                    const rad = (role.startAngle * Math.PI) / 180;
                    const x = 95 + 95 * Math.cos(rad);
                    const y = 95 + 95 * Math.sin(rad);

                    return (
                      <div
                        key={role.id}
                        className="absolute pointer-events-auto"
                        style={{
                          left: `${x}px`,
                          top: `${y}px`,
                          transform: 'translate(-50%, -50%)',
                        }}
                      >
                        {/* Counter-rotate so text remains upright & readable */}
                        <motion.div
                          animate={isPaused ? {} : { rotate: -360 }}
                          transition={{
                            repeat: Infinity,
                            duration: 24,
                            ease: 'linear',
                          }}
                        >
                          <button
                            type="button"
                            onClick={() => setSelectedRole(role)}
                            onMouseEnter={() => setSelectedRole(role)}
                            className={`group/role flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-sans font-bold transition-all duration-200 border cursor-pointer ${
                              isSelected
                                ? 'bg-orange-500 text-neutral-950 border-orange-400 shadow-lg shadow-orange-500/40 scale-105'
                                : 'bg-neutral-900/90 text-neutral-200 border-neutral-700/80 hover:border-orange-400/80 hover:bg-neutral-800'
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${role.color} ${role.glowColor}`} />
                            <Icon className="w-3 h-3" />
                            <span className="whitespace-nowrap">{role.title}</span>
                          </button>
                        </motion.div>
                      </div>
                    );
                  })}
              </motion.div>

              {/* Outer Orbiting System (3 Roles) */}
              <motion.div
                className="absolute w-[280px] sm:w-[330px] h-[280px] sm:h-[330px] rounded-full pointer-events-none"
                animate={isPaused ? {} : { rotate: 360 }}
                transition={{
                  repeat: Infinity,
                  duration: 38,
                  ease: 'linear',
                }}
              >
                {roles
                  .filter((r) => r.orbitRadius === 165)
                  .map((role) => {
                    const isSelected = selectedRole?.id === role.id;
                    const Icon = role.icon;
                    // On mobile, radius is 140px; on desktop, radius is 165px
                    // Let's use percentage coordinate (50% + 50% * cos(angle))
                    const rad = (role.startAngle * Math.PI) / 180;
                    const leftPct = 50 + 50 * Math.cos(rad);
                    const topPct = 50 + 50 * Math.sin(rad);

                    return (
                      <div
                        key={role.id}
                        className="absolute pointer-events-auto"
                        style={{
                          left: `${leftPct}%`,
                          top: `${topPct}%`,
                          transform: 'translate(-50%, -50%)',
                        }}
                      >
                        {/* Counter-rotate so text remains upright & readable */}
                        <motion.div
                          animate={isPaused ? {} : { rotate: -360 }}
                          transition={{
                            repeat: Infinity,
                            duration: 38,
                            ease: 'linear',
                          }}
                        >
                          <button
                            type="button"
                            onClick={() => setSelectedRole(role)}
                            onMouseEnter={() => setSelectedRole(role)}
                            className={`group/role flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] sm:text-[11px] font-sans font-bold transition-all duration-200 border cursor-pointer ${
                              isSelected
                                ? 'bg-orange-500 text-neutral-950 border-orange-400 shadow-lg shadow-orange-500/40 scale-105'
                                : 'bg-neutral-900/90 text-neutral-200 border-neutral-700/80 hover:border-orange-400/80 hover:bg-neutral-800'
                            }`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${role.color} ${role.glowColor}`} />
                            <Icon className="w-3 h-3" />
                            <span className="whitespace-nowrap">{role.title}</span>
                          </button>
                        </motion.div>
                      </div>
                    );
                  })}
              </motion.div>
            </div>

            {/* Micro Context Card for Selected / Hovered Role */}
            <div className="mt-1 pt-2.5 border-t border-neutral-800/80 relative z-10 min-h-[56px] flex items-center justify-between">
              {selectedRole ? (
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white font-sans">
                      {selectedRole.title}
                    </span>
                    <span className="text-[10px] font-mono text-orange-400">
                      // {selectedRole.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 leading-snug font-sans">
                    {selectedRole.description}
                  </p>
                </div>
              ) : (
                <div className="flex items-center justify-between w-full text-[11px] font-mono text-neutral-500">
                  <span>Hover or tap any orbiting role to preview executive alignment</span>
                  <span className="text-orange-400 hidden sm:inline">5 Core Trajectories</span>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
