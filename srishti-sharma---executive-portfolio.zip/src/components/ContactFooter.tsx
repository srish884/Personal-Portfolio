import React, { useState } from 'react';
import {
  Mail,
  Phone,
  Linkedin,
  Github,
  ArrowUpRight,
  Copy,
  Check,
  Send,
  Sparkles,
  MapPin,
  Clock,
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const ContactFooter: React.FC = () => {
  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    roleOrCompany: '',
    inquiryType: 'Role Opportunity',
    message: '',
  });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedItem(type);
    setTimeout(() => {
      setCopiedItem(null);
    }, 2000);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate swift submission & create mailto fallback
    setTimeout(() => {
      setIsSubmitting(false);
      setFormSubmitted(true);
    }, 600);
  };

  return (
    <footer id="contact" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-neutral-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Personal Brand Closing Manifesto Section */}
        <div className="rounded-3xl bg-gradient-to-b from-[#11131a] via-[#0a0c10] to-[#000000] border border-neutral-800 p-8 sm:p-14 mb-20 text-center relative overflow-hidden shadow-2xl">
          {/* Subtle warm glow matching reference image */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-32 bg-[#ea580c]/10 rounded-full blur-3xl pointer-events-none" />

          <span className="text-xs font-mono tracking-widest uppercase text-[#ea580c] font-bold block mb-3">
            // THE CORE COMMITMENT
          </span>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight font-['Syne',sans-serif] max-w-3xl mx-auto leading-tight mb-6">
            "My goal is simple: Leave every process, project, team, and client relationship better than I found it."
          </h2>

          <p className="text-neutral-400 text-sm sm:text-base max-w-xl mx-auto mb-8 font-sans">
            Ready to bring strategic clarity, engineering discipline, and compounding AI automation to your enterprise technology initiatives.
          </p>

          <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-neutral-900 border border-neutral-700 text-xs font-mono text-neutral-200">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Currently exploring Technical Account Management & Product Leadership opportunities</span>
          </div>
        </div>

        {/* Contact Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 09 · DIRECT CHANNELS</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>INTERESTED IN WORKING TOGETHER?</span>
            </div>
            <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              LET'S TALK.
            </h2>
          </div>

          <div className="max-w-md text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              Direct & Prompt Communication.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              Whether it’s a high-stakes client engagement, mission-critical platform rollout, or enterprise AI workflow, let’s start a conversation.
            </p>
          </div>
        </div>

        {/* Contact Grid: Direct Info + Interactive Message Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left: Direct Contact Information Badges */}
          <div className="lg:col-span-5 space-y-4">
            <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider block mb-2">
              DIRECT REACHOUT:
            </span>

            {/* Email Card */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all flex items-center justify-between group">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center text-neutral-300">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-neutral-500 uppercase block">EMAIL</span>
                  <a
                    href={`mailto:${PERSONAL_INFO.email}`}
                    className="text-sm font-semibold text-white hover:text-neutral-300 font-mono transition-colors"
                  >
                    {PERSONAL_INFO.email}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => copyToClipboard(PERSONAL_INFO.email, 'email')}
                  title="Copy email to clipboard"
                  className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
                >
                  {copiedItem === 'email' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
                <a
                  href={`mailto:${PERSONAL_INFO.email}`}
                  title="Open mail client"
                  className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Phone Card */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all flex items-center justify-between group">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center text-neutral-300">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-neutral-500 uppercase block">PHONE / WHATSAPP</span>
                  <a
                    href={`tel:${PERSONAL_INFO.phone}`}
                    className="text-sm font-semibold text-white hover:text-neutral-300 font-mono transition-colors"
                  >
                    {PERSONAL_INFO.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => copyToClipboard(PERSONAL_INFO.phone, 'phone')}
                  title="Copy phone to clipboard"
                  className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
                >
                  {copiedItem === 'phone' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
                <a
                  href={`tel:${PERSONAL_INFO.phone}`}
                  title="Call number"
                  className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
                >
                  <ArrowUpRight className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* LinkedIn Card */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all flex items-center justify-between group">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center text-neutral-300">
                  <Linkedin className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-neutral-500 uppercase block">LINKEDIN PROFILE</span>
                  <a
                    href={PERSONAL_INFO.linkedinUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm font-semibold text-white hover:text-blue-300 font-mono transition-colors"
                  >
                    Srishti Sharma
                  </a>
                </div>
              </div>

              <a
                href={PERSONAL_INFO.linkedinUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
              >
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

            {/* GitHub Card */}
            <div className="p-5 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition-all flex items-center justify-between group">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center text-neutral-300">
                  <Github className="w-5 h-5 text-neutral-300" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-neutral-500 uppercase block">GITHUB REPOSITORIES</span>
                  <a
                    href={PERSONAL_INFO.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm font-semibold text-white hover:text-neutral-300 font-mono transition-colors"
                  >
                    srish884
                  </a>
                </div>
              </div>

              <a
                href={PERSONAL_INFO.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white transition-colors"
              >
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

            {/* Location & Timezone availability */}
            <div className="p-4 rounded-xl bg-neutral-950/60 border border-neutral-800/80 flex items-center justify-between text-xs font-mono text-neutral-400">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                {PERSONAL_INFO.location}
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <Clock className="w-3.5 h-3.5" />
                Fast Response Rate
              </span>
            </div>
          </div>

          {/* Right: Interactive Message Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-gradient-to-b from-[#131520] to-[#0e1017] border border-neutral-800 p-6 sm:p-8 shadow-2xl">
              <div className="flex items-center justify-between pb-4 border-b border-neutral-800 mb-6">
                <h3 className="text-lg font-bold text-white font-['Syne',sans-serif]">
                  Send a Direct Message
                </h3>
                <span className="text-xs font-mono text-neutral-400">
                  DIRECT TO INBOX
                </span>
              </div>

              {formSubmitted ? (
                <div className="py-12 text-center space-y-4 animate-in fade-in duration-300">
                  <div className="w-14 h-14 rounded-full bg-emerald-950/60 border border-emerald-800 flex items-center justify-center mx-auto text-emerald-400">
                    <Check className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-bold text-white font-['Syne',sans-serif]">
                    Message Transmitted
                  </h4>
                  <p className="text-sm text-neutral-300 max-w-md mx-auto">
                    Thank you, {formData.name || 'there'}. I have received your note and will respond promptly to {formData.email || 'your email'}.
                  </p>
                  <button
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        roleOrCompany: '',
                        inquiryType: 'Role Opportunity',
                        message: '',
                      });
                    }}
                    className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-mono uppercase text-neutral-300 transition-colors"
                  >
                    Send Another Note
                  </button>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Alex Henderson"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-sm text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-neutral-500 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="alex@enterprise.com"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-sm text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-neutral-500 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                        Company / Organization
                      </label>
                      <input
                        type="text"
                        value={formData.roleOrCompany}
                        onChange={(e) => setFormData({ ...formData, roleOrCompany: e.target.value })}
                        placeholder="e.g. Tier 1 Bank / Fintech"
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-sm text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-neutral-500 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                        Inquiry Focus
                      </label>
                      <select
                        value={formData.inquiryType}
                        onChange={(e) => setFormData({ ...formData, inquiryType: e.target.value })}
                        className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-sm text-neutral-200 focus:outline-none focus:border-neutral-500 transition-colors"
                      >
                        <option value="Role Opportunity">Executive / TAM / Product Role</option>
                        <option value="Financial Markets Project">Financial Markets Technology</option>
                        <option value="AI & Automation Workflow">AI & Multi-Agent Automation</option>
                        <option value="General Collaboration">General Collaboration</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-neutral-400 uppercase tracking-wider mb-1.5">
                      Message / Project Context *
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Outline the opportunity, project scope, or conversation agenda..."
                      className="w-full px-4 py-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-sm text-neutral-200 placeholder-neutral-600 focus:outline-none focus:border-neutral-500 transition-colors resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-[#ea580c] text-white font-bold text-xs font-mono tracking-wider uppercase hover:bg-[#c2410c] shadow-lg shadow-[#ea580c]/20 active:scale-[0.99] transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>TRANSMITTING...</span>
                    ) : (
                      <>
                        <span>SEND MESSAGE TO SRISHTI</span>
                        <Send className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Fine Print */}
        <div className="mt-20 pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-600">
          <div>
            © {new Date().getFullYear()} Srishti Sharma. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Built with React & Modern Web Tech</span>
            <span>·</span>
            <a
              href="#home"
              className="text-neutral-400 hover:text-white transition-colors"
            >
              Back to Top ↑
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
