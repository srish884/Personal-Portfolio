import React from 'react';
import { motion } from 'motion/react';

interface HeroCardItem {
  id: string;
  emoji: string;
  title: string;
  highlight: string;
  description: string;
  badge?: string;
}

const HERO_CARDS: HeroCardItem[] = [
  {
    id: 'global-impact',
    emoji: '🌍',
    title: 'Global Impact',
    highlight: '20+ Tier-1 Global Banks',
    description: 'Managing strategic relationships across EMEA & North America.',
  },
  {
    id: 'execution-engine',
    emoji: '⚡',
    title: 'Execution Engine',
    highlight: '150+ Initiatives Delivered',
    description: 'From migrations and infrastructure modernization to large-scale transformation programs.',
  },
  {
    id: 'trusted-under-pressure',
    emoji: '🎯',
    title: 'Trusted Under Pressure',
    highlight: '30+ Critical Escalations Led',
    description: 'Turning high-pressure situations into measurable outcomes.',
  },
  {
    id: 'automation-obsessed',
    emoji: '🤖',
    title: 'Automation Obsessed',
    highlight: '80%+ Manual Effort Eliminated',
    description: 'Building systems so teams can focus on what matters.',
  },
  {
    id: 'financial-markets',
    emoji: '🏦',
    title: 'Financial Markets Specialist',
    highlight: 'Fixed Income • Repo • Equities',
    description: 'Bridging technology and capital markets.',
  },
  {
    id: 'international-exposure',
    emoji: '🌐',
    title: 'International Exposure',
    highlight: 'Represented ION in London',
    description: 'Leading executive workshops and client engagements.',
  },
];

export const HeroHighlightCards: React.FC = () => {
  return (
    <div className="w-full relative z-20 mb-4 sm:mb-6">
      {/* 6 Lean Curated Smart Hero Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-2.5">
        {HERO_CARDS.map((card, idx) => (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: idx * 0.05 }}
            className="group relative bg-white/80 hover:bg-white/95 backdrop-blur-md border border-neutral-300/80 hover:border-neutral-900 rounded-xl p-2.5 sm:p-3 flex flex-col justify-between transition-all duration-200 shadow-xs hover:shadow-md cursor-default"
          >
            {/* Subtle Top Glowing Highlight Indicator on Hover */}
            <div className="absolute top-0 left-3 right-3 h-[2px] rounded-full bg-transparent group-hover:bg-gradient-to-r group-hover:from-orange-500 group-hover:to-amber-500 transition-all duration-300" />

            <div>
              {/* Header: Emoji & Lean Title */}
              <div className="flex items-center gap-1.5 mb-1">
                <span className="text-sm select-none" role="img" aria-label={card.title}>
                  {card.emoji}
                </span>
                <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-neutral-600 truncate group-hover:text-neutral-950 transition-colors">
                  {card.title}
                </span>
              </div>

              {/* Bold Main Highlight */}
              <p className="text-[12px] sm:text-[13px] font-black tracking-tight leading-snug text-neutral-950 font-['Syne',sans-serif]">
                {card.highlight}
              </p>
            </div>

            {/* Micro Context / Subtitle */}
            <p className="text-[10.5px] text-neutral-700 leading-tight mt-1.5 line-clamp-2">
              {card.description}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
