import React, { useState, useRef, useEffect } from 'react';
import { Camera, RotateCcw, Sparkles, Image as ImageIcon, Play } from 'lucide-react';
import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import srishtiCutoutPng from '../assets/images/srishti_cutout.png';
import { ExecutiveVideoCard } from './ExecutiveVideoCard';

interface Portrait3DProps {
  customPhoto: string | null;
  onPhotoUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetPhoto: (e: React.MouseEvent) => void;
}

export const Portrait3D: React.FC<Portrait3DProps> = ({
  customPhoto,
  onPhotoUpload,
  onResetPhoto,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [renderMode, setRenderMode] = useState<'photo' | 'vector'>('photo');
  const [processedCustomCutout, setProcessedCustomCutout] = useState<string | null>(null);
  const [isVideoActive, setIsVideoActive] = useState(false);

  // If user uploads custom photo, process background removal on client
  useEffect(() => {
    if (!customPhoto) {
      setProcessedCustomCutout(null);
      return;
    }

    let isMounted = true;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          if (isMounted) setProcessedCustomCutout(customPhoto);
          return;
        }

        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        const w = canvas.width;
        const h = canvas.height;

        // Sample background from top corners
        let bgR = 0, bgG = 0, bgB = 0;
        let samples = 0;
        const sampleCoords = [
          [2, 2], [w - 3, 2], [Math.floor(w / 2), 2],
          [2, 10], [w - 3, 10]
        ];
        for (const [x, y] of sampleCoords) {
          if (x >= 0 && x < w && y >= 0 && y < h) {
            const idx = (y * w + x) * 4;
            bgR += data[idx];
            bgG += data[idx + 1];
            bgB += data[idx + 2];
            samples++;
          }
        }
        if (samples > 0) {
          bgR /= samples; bgG /= samples; bgB /= samples;
        }

        // BFS flood-fill from border
        const visited = new Uint8Array(w * h);
        const queue = new Int32Array(w * h);
        let head = 0;
        let tail = 0;

        for (let x = 0; x < w; x++) {
          queue[tail++] = x;
          visited[x] = 1;
        }
        for (let y = 1; y < Math.floor(h * 0.85); y++) {
          const leftIdx = y * w;
          const rightIdx = y * w + (w - 1);
          if (!visited[leftIdx]) { queue[tail++] = leftIdx; visited[leftIdx] = 1; }
          if (!visited[rightIdx]) { queue[tail++] = rightIdx; visited[rightIdx] = 1; }
        }

        const threshold = 40;
        const feather = 18;

        while (head < tail) {
          const curr = queue[head++];
          const cx = curr % w;
          const cy = Math.floor(curr / w);
          const idx = curr * 4;

          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];

          const dist = Math.sqrt(
            (r - bgR) * (r - bgR) +
            (g - bgG) * (g - bgG) +
            (b - bgB) * (b - bgB)
          );

          if (dist < threshold) {
            data[idx + 3] = 0;
            if (cx > 0) { const left = curr - 1; if (!visited[left]) { visited[left] = 1; queue[tail++] = left; } }
            if (cx < w - 1) { const right = curr + 1; if (!visited[right]) { visited[right] = 1; queue[tail++] = right; } }
            if (cy > 0) { const up = curr - w; if (!visited[up]) { visited[up] = 1; queue[tail++] = up; } }
            if (cy < h - 1) { const down = curr + w; if (!visited[down]) { visited[down] = 1; queue[tail++] = down; } }
          } else if (dist < threshold + feather) {
            const alphaRatio = (dist - threshold) / feather;
            data[idx + 3] = Math.floor(data[idx + 3] * alphaRatio);
          }
        }

        ctx.putImageData(imageData, 0, 0);
        if (isMounted) {
          setProcessedCustomCutout(canvas.toDataURL('image/png'));
        }
      } catch (e) {
        if (isMounted) setProcessedCustomCutout(customPhoto);
      }
    };
    img.src = customPhoto;

    return () => {
      isMounted = false;
    };
  }, [customPhoto]);

  // Motion values for realistic 3D perspective tilt
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  // Smooth spring physics for fluid movement
  const springConfig = { damping: 25, stiffness: 180, mass: 0.5 };
  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [10, -10]), springConfig);
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-14, 14]), springConfig);
  const translateX = useSpring(useTransform(mouseX, [-0.5, 0.5], [-16, 16]), springConfig);
  const translateY = useSpring(useTransform(mouseY, [-0.5, 0.5], [-8, 8]), springConfig);

  // Dynamic shadow displacement based on cursor position
  const shadowX = useSpring(useTransform(mouseX, [-0.5, 0.5], [20, -20]), springConfig);
  const shadowY = useSpring(useTransform(mouseY, [-0.5, 0.5], [25, 10]), springConfig);

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  };

  const handlePointerLeave = () => {
    setIsHovered(false);
    mouseX.set(0);
    mouseY.set(0);
  };

  // Subtle natural idle sway when not hovered
  useEffect(() => {
    if (isHovered || isVideoActive) return;
    const interval = setInterval(() => {
      const t = Date.now() / 2200;
      mouseX.set(Math.sin(t) * 0.04);
      mouseY.set(Math.cos(t * 0.8) * 0.03);
    }, 40);
    return () => clearInterval(interval);
  }, [isHovered, isVideoActive, mouseX, mouseY]);

  // Active photo source (custom cutout or verified transparent PNG cutout)
  const activeCutoutPhoto = customPhoto ? (processedCustomCutout || customPhoto) : srishtiCutoutPng;

  return (
    <div
      ref={containerRef}
      onPointerEnter={() => setIsHovered(true)}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      className="relative flex flex-col items-center justify-end [perspective:1400px] select-none"
    >
      {/* Hidden File Input for Custom Headshot Upload */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={onPhotoUpload}
        title="Upload your professional photo"
      />

      {/* CONDITIONAL RENDER: Active Video Player Card vs 3D Cutout Placeholder */}
      {isVideoActive ? (
        <div className="relative z-30">
          <ExecutiveVideoCard
            onClose={() => setIsVideoActive(false)}
            placeholderImage={activeCutoutPhoto}
          />
        </div>
      ) : (
        /* 3D FOREGROUND BODY CUTOUT: Pure body cutout, zero background, seamlessly blending into grey website background */
        <motion.div
          style={{
            rotateX,
            rotateY,
            x: translateX,
            y: translateY,
            transformStyle: 'preserve-3d',
          }}
          className="relative z-20 flex flex-col items-center will-change-transform cursor-pointer"
          onClick={() => setIsVideoActive(true)}
        >
          {/* Dynamic Soft Spatial Drop Shadow casting onto the moving text behind */}
          <motion.div
            className="absolute inset-x-8 bottom-0 h-24 pointer-events-none rounded-full blur-2xl opacity-40 bg-black"
            style={{
              x: shadowX,
              y: shadowY,
              scale: 0.9,
              zIndex: -1,
            }}
          />

          {/* PLAY ME / WATCH EXECUTIVE INTRO FLOATING TRIGGER (Positioned at Top-Right of the Photo) */}
          <motion.div
            style={{ transform: 'translateZ(65px)' }}
            className="absolute top-2 sm:top-4 right-1 sm:right-3 md:-right-2 z-30 pointer-events-auto"
          >
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsVideoActive(true);
              }}
              className="group relative flex items-center gap-2.5 sm:gap-3 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-full bg-black/90 hover:bg-black text-white border border-white/30 shadow-2xl backdrop-blur-md transition-all hover:scale-105 active:scale-95 cursor-pointer"
              title="Play Executive Video Introduction"
            >
              {/* Pulsing Orange Glow Radar */}
              <span className="absolute -inset-1 rounded-full bg-orange-500/30 animate-ping pointer-events-none" />

              {/* Play Button Icon */}
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-orange-600 group-hover:bg-orange-500 flex items-center justify-center text-white transition-colors shadow-md shrink-0">
                <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 translate-x-0.5 fill-white" />
              </div>

              {/* Professional Label */}
              <div className="flex flex-col text-left">
                <span className="text-[11px] sm:text-xs font-mono font-bold tracking-wider uppercase text-white flex items-center gap-1.5 whitespace-nowrap">
                  <span>WATCH INTRO</span>
                  <span className="text-[9px] sm:text-[10px] px-1.5 py-0.2 rounded bg-orange-600 text-white font-semibold">60S</span>
                </span>
                <span className="text-[9px] sm:text-[10px] text-neutral-300 font-mono whitespace-nowrap">
                  Executive Briefing • Play
                </span>
              </div>
            </button>
          </motion.div>

          {/* PRIMARY DISPLAY: 100% Transparent Body Cutout (Zero Background, Pure Grey Page Integration) */}
          {renderMode === 'photo' ? (
            <div className="relative w-[310px] sm:w-[390px] md:w-[460px] lg:w-[510px] aspect-[3/4] flex items-end justify-center pointer-events-none">
              <img
                src={activeCutoutPhoto}
                alt="Srishti Sharma Body Cutout"
                className="w-full h-full object-contain object-bottom drop-shadow-[0_16px_30px_rgba(0,0,0,0.45)] transition-transform duration-300"
                style={{
                  transform: 'translateZ(30px)',
                }}
                referrerPolicy="no-referrer"
              />
            </div>
          ) : (
            /* ALTERNATIVE DISPLAY: 3D High-Detail Vector Cutout (100% Transparent Silhouette) */
            <div className="relative w-[310px] sm:w-[390px] md:w-[460px] lg:w-[510px] aspect-[3/4] flex items-end justify-center pointer-events-none">
              <svg
                viewBox="0 0 400 480"
                className="w-full h-full drop-shadow-[0_16px_30px_rgba(0,0,0,0.45)]"
                style={{ transform: 'translateZ(30px)' }}
              >
                <defs>
                  <linearGradient id="vSkinGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#d99b7b" />
                    <stop offset="50%" stopColor="#c58364" />
                    <stop offset="100%" stopColor="#9a5b3e" />
                  </linearGradient>

                  <linearGradient id="vTerracottaBlazer" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#f97316" />
                    <stop offset="35%" stopColor="#ea580c" />
                    <stop offset="80%" stopColor="#c2410c" />
                    <stop offset="100%" stopColor="#7c2d12" />
                  </linearGradient>

                  <linearGradient id="vDarkShirt" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#1e293b" />
                    <stop offset="100%" stopColor="#0f172a" />
                  </linearGradient>

                  <linearGradient id="vHairGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#301c17" />
                    <stop offset="45%" stopColor="#1c120e" />
                    <stop offset="85%" stopColor="#0e0a08" />
                    <stop offset="100%" stopColor="#45271c" />
                  </linearGradient>

                  <linearGradient id="vGlassesRim" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#f59e0b" />
                    <stop offset="50%" stopColor="#fbbf24" />
                    <stop offset="100%" stopColor="#b45309" />
                  </linearGradient>
                </defs>

                {/* Back Hair Volume */}
                <path
                  d="M 120 150 C 90 220 90 310 130 360 C 170 375 230 375 270 360 C 310 310 310 220 280 150 C 270 80 130 80 120 150 Z"
                  fill="url(#vHairGrad)"
                />

                {/* Neck */}
                <path
                  d="M 170 240 L 230 240 L 238 310 L 162 310 Z"
                  fill="url(#vSkinGrad)"
                />
                <path
                  d="M 170 240 C 190 260 210 260 230 240 L 235 265 C 210 278 190 278 165 265 Z"
                  fill="#78422b"
                  opacity="0.45"
                />

                {/* Inner Dark Shirt */}
                <path
                  d="M 155 305 Q 200 335 245 305 L 265 470 L 135 470 Z"
                  fill="url(#vDarkShirt)"
                />

                {/* Terracotta Orange Blazer */}
                <path
                  d="M 155 305 L 55 365 L 30 480 L 175 480 L 190 360 Z"
                  fill="url(#vTerracottaBlazer)"
                />
                <path
                  d="M 245 305 L 345 365 L 370 480 L 225 480 L 210 360 Z"
                  fill="url(#vTerracottaBlazer)"
                />

                {/* Lapel Stitches */}
                <path d="M 155 305 L 195 380 L 175 480" stroke="#9a3412" strokeWidth="3" fill="none" />
                <path d="M 245 305 L 205 380 L 225 480" stroke="#9a3412" strokeWidth="3" fill="none" />

                {/* Head / Face Shape */}
                <path
                  d="M 145 170 C 145 110 255 110 255 170 C 255 235 230 270 200 270 C 170 270 145 235 145 170 Z"
                  fill="url(#vSkinGrad)"
                />

                {/* Front Styled Hair Waves */}
                <path
                  d="M 140 160 C 145 105 180 85 200 85 C 235 85 265 105 265 160 C 250 125 225 110 200 110 C 165 110 150 125 140 160 Z"
                  fill="#1c120e"
                />
                <path d="M 135 155 C 128 190 132 250 146 290 C 154 245 150 195 148 168 Z" fill="#2a1711" />
                <path d="M 265 155 C 272 190 268 250 254 290 C 246 245 250 195 252 168 Z" fill="#2a1711" />

                <path
                  d="M 155 95 Q 200 80 245 95"
                  stroke="#f59e0b"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  fill="none"
                  opacity="0.85"
                />

                {/* Eyebrows */}
                <path d="M 162 162 Q 178 156 190 162" stroke="#231713" strokeWidth="3" strokeLinecap="round" fill="none" />
                <path d="M 210 162 Q 222 156 238 162" stroke="#231713" strokeWidth="3" strokeLinecap="round" fill="none" />

                {/* Eyes */}
                <ellipse cx="176" cy="174" rx="7" ry="5" fill="#ffffff" />
                <circle cx="176" cy="174" r="3.5" fill="#261812" />
                <circle cx="178" cy="172" r="1.2" fill="#ffffff" />

                <ellipse cx="224" cy="174" rx="7" ry="5" fill="#ffffff" />
                <circle cx="224" cy="174" r="3.5" fill="#261812" />
                <circle cx="226" cy="172" r="1.2" fill="#ffffff" />

                {/* Glasses */}
                <circle cx="176" cy="174" r="17" stroke="url(#vGlassesRim)" strokeWidth="3" fill="none" />
                <circle cx="224" cy="174" r="17" stroke="url(#vGlassesRim)" strokeWidth="3" fill="none" />
                <path d="M 193 171 Q 200 166 207 171" stroke="url(#vGlassesRim)" strokeWidth="3" fill="none" />
                <path d="M 159 171 L 145 168" stroke="url(#vGlassesRim)" strokeWidth="2.5" fill="none" />
                <path d="M 241 171 L 255 168" stroke="url(#vGlassesRim)" strokeWidth="2.5" fill="none" />

                {/* Glare Sheen */}
                <path d="M 168 162 L 184 178" stroke="#ffffff" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
                <path d="M 216 162 L 232 178" stroke="#ffffff" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />

                {/* Nose Contour */}
                <path d="M 200 178 L 198 205 Q 203 209 205 205" stroke="#9a5b3e" strokeWidth="2" strokeLinecap="round" fill="none" />

                {/* Smile */}
                <path d="M 182 225 Q 200 238 218 225" stroke="#b91c1c" strokeWidth="3" strokeLinecap="round" fill="none" />
                <path d="M 186 225 Q 200 233 214 225" fill="#ffffff" opacity="0.85" />
              </svg>
            </div>
          )}

          {/* Minimal Floating Control Pill */}
          <div
            style={{ transform: 'translateZ(50px)' }}
            className="mt-1 flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/95 border border-neutral-300/80 text-neutral-900 shadow-lg backdrop-blur-md text-[11px] font-mono pointer-events-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setRenderMode(renderMode === 'photo' ? 'vector' : 'photo')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-100 hover:bg-neutral-200 text-neutral-900 font-bold transition-colors"
              title="Toggle Cutout Style"
            >
              {renderMode === 'photo' ? (
                <>
                  <Sparkles className="w-3 h-3 text-[#ea580c]" />
                  <span>Switch to 3D Vector</span>
                </>
              ) : (
                <>
                  <ImageIcon className="w-3 h-3 text-[#ea580c]" />
                  <span>Switch to Photo Cutout</span>
                </>
              )}
            </button>

            <span className="text-neutral-300">|</span>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full hover:bg-neutral-100 text-neutral-700 hover:text-black transition-colors"
              title="Upload your personal headshot"
            >
              <Camera className="w-3 h-3 text-neutral-600" />
              <span>Change Photo</span>
            </button>

            {customPhoto && (
              <>
                <span className="text-neutral-300">|</span>
                <button
                  type="button"
                  onClick={onResetPhoto}
                  className="flex items-center gap-1 px-2 py-1 rounded-full text-rose-600 hover:bg-rose-50 transition-colors"
                  title="Reset to default cutout"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              </>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
};
