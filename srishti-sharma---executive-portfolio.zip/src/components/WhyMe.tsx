import React, { useState } from 'react';
import {
  Layers,
  ArrowRight,
  Sparkles,
  Zap,
  Cpu,
  ShieldCheck,
  CheckCircle2,
  Workflow,
  Network,
  Code2,
  GitBranch,
} from 'lucide-react';
import { WHY_ME_CARDS } from '../data/portfolioData';

export const WhyMe: React.FC = () => {
  const [activeCardId, setActiveCardId] = useState<string>('why-multipliers');

  // Interactive visual metaphor components
  const renderVisualMetaphor = (type: string) => {
    switch (type) {
      case 'multipliers':
        return (
          <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between text-neutral-500 text-[10px]">
              <span>VELOCITY MULTIPLIER ENGINE</span>
              <span className="text-emerald-400">STATUS: ACTIVE</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800">
                <span className="text-neutral-500 block text-[10px]">Input</span>
                <span className="text-neutral-200 font-bold">1x Effort</span>
              </div>
              <div className="p-2.5 rounded bg-neutral-900 border border-neutral-800 flex items-center justify-center text-amber-400 font-bold">
                ➔ [Automation] ➔
              </div>
              <div className="p-2.5 rounded bg-emerald-950/50 border border-emerald-800 text-emerald-300 font-bold">
                <span className="text-emerald-500 block text-[10px]">Output</span>
                <span>5x Scale</span>
              </div>
            </div>
            <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden">
              <div className="bg-gradient-to-r from-amber-400 to-emerald-400 h-full w-[80%] animate-pulse" />
            </div>
          </div>
        );

      case 'bilingual':
        return (
          <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between text-neutral-500 text-[10px]">
              <span>DUAL TRANSLATION BRIDGE</span>
              <span className="text-cyan-400">BIDIRECTIONAL</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-2.5 rounded bg-neutral-900/90 border border-neutral-800">
                <span className="text-cyan-400 font-bold block mb-1 text-[11px]">BUSINESS DIALECT</span>
                <p className="text-[11px] text-neutral-400">P&L, Desk SLA, Capital Efficiency, Repo Liquidity, Client Retention</p>
              </div>
              <div className="p-2.5 rounded bg-neutral-900/90 border border-neutral-800">
                <span className="text-purple-400 font-bold block mb-1 text-[11px]">TECH ARCHITECTURE</span>
                <p className="text-[11px] text-neutral-400">APIs, DB Latency, Resilient Microservices, User Stories, UAT</p>
              </div>
            </div>
            <div className="text-center text-[10px] text-neutral-500 flex items-center justify-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>Zero Meaning Lost in Translation</span>
              <span className="w-2 h-2 rounded-full bg-purple-400" />
            </div>
          </div>
        );

      case 'clarity':
        return (
          <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between text-neutral-500 text-[10px]">
              <span>COMPLEXITY COLLAPSE PIPELINE</span>
              <span className="text-purple-400">ENTROPY ➔ STRUCTURE</span>
            </div>
            <div className="flex items-center justify-between gap-2 text-center text-[11px]">
              <div className="flex-1 p-2 rounded bg-red-950/30 border border-red-900/40 text-neutral-400">
                Fragmented Legacy Inputs
              </div>
              <ArrowRight className="w-4 h-4 text-purple-400 shrink-0" />
              <div className="flex-1 p-2 rounded bg-purple-950/40 border border-purple-800/60 text-purple-200">
                Systemic Synthesis
              </div>
              <ArrowRight className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="flex-1 p-2 rounded bg-emerald-950/40 border border-emerald-800 text-emerald-300">
                Deterministic Milestones
              </div>
            </div>
          </div>
        );

      case 'ai':
        return (
          <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between text-neutral-500 text-[10px]">
              <span>PRACTICAL AI WORKFLOW ORCHESTRATION</span>
              <span className="text-emerald-400">ROI-DRIVEN</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-1 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 text-[10px]">
                Web Scraping API
              </span>
              <span className="text-neutral-600">➔</span>
              <span className="px-2 py-1 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 text-[10px]">
                n8n Agent Swarm
              </span>
              <span className="text-neutral-600">➔</span>
              <span className="px-2 py-1 rounded bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-[10px]">
                Validated Commercial Signal
              </span>
            </div>
            <p className="text-[10px] text-neutral-500">
              Deterministic Guardrails + Structured Extraction = Zero Hallucination Risk
            </p>
          </div>
        );

      case 'owner':
        return (
          <div className="p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 flex flex-col gap-3 font-mono text-xs">
            <div className="flex items-center justify-between text-neutral-500 text-[10px]">
              <span>ACCOUNT EQUITY & RISK RADAR</span>
              <span className="text-blue-400">UPSTREAM SENSING</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 rounded bg-neutral-900 border border-neutral-800 text-neutral-400">
                Task Mindset: "Ticket is resolved."
              </div>
              <div className="p-2 rounded bg-blue-950/40 border border-blue-800 text-blue-200 font-semibold">
                Owner Mindset: "Root issue resolved, renewal safeguarded."
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <section id="why-me" className="relative py-24 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16 border-b border-neutral-800 pb-8">
          <div>
            <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
              <span>// 03 · THE SIGNATURE DIFFERENTIATOR</span>
              <span className="w-8 h-px bg-neutral-800" />
              <span>INDISPENSABLE VALUE CREATION</span>
            </div>
            <h2 className="text-7xl sm:text-8xl md:text-9xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none">
              WHY COMPANIES KEEP ME AROUND
            </h2>
          </div>

          <div className="max-w-lg text-neutral-300 text-sm sm:text-base leading-relaxed">
            <p className="text-white font-semibold mb-1">
              Not Just Strengths. Fundamental Operating Multipliers.
            </p>
            <p className="text-neutral-400 text-xs sm:text-sm">
              Anyone can handle everyday tasks. The professionals organizations fight to keep are those who systematically eliminate chaos, build enduring operational leverage, and think like founders.
            </p>
          </div>
        </div>

        {/* 5 Signature Large Interactive Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {WHY_ME_CARDS.map((card, idx) => {
            const isFeatured = idx === 0 || idx === 3;
            return (
              <div
                key={card.id}
                id={`whyme-card-${card.id}`}
                className={`group rounded-2xl bg-gradient-to-b from-[#11131a] to-[#0a0c10] border border-neutral-800 p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 hover:border-neutral-600 hover:shadow-2xl hover:shadow-black relative overflow-hidden ${
                  isFeatured ? 'md:col-span-2 lg:col-span-1' : ''
                }`}
              >
                {/* Subtle hover accent light */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-neutral-700/10 rounded-full blur-2xl group-hover:bg-neutral-600/20 transition-all pointer-events-none" />

                <div className="space-y-4">
                  {/* Top Badge */}
                  <div className="flex items-center justify-between gap-2 border-b border-neutral-800/80 pb-3">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-neutral-500">
                      // PILLAR 0{idx + 1}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-neutral-900 border border-neutral-700 text-[10px] font-mono text-neutral-300">
                      {card.badge}
                    </span>
                  </div>

                  {/* Title & Tagline */}
                  <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne',sans-serif] group-hover:text-neutral-100 transition-colors">
                    {card.title}
                  </h3>

                  <p className="text-xs font-mono text-neutral-400">
                    {card.headline}
                  </p>

                  <p className="text-neutral-300 text-xs sm:text-sm leading-relaxed">
                    {card.description}
                  </p>

                  {/* Visual Metaphor Illustration */}
                  <div className="pt-2">
                    {renderVisualMetaphor(card.metaphorType)}
                  </div>
                </div>

                {/* Bullet Points */}
                <div className="mt-6 pt-4 border-t border-neutral-800/80 space-y-2">
                  <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-wider block">
                    Proof in Practice:
                  </span>
                  {card.bulletPoints.map((point, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-neutral-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
