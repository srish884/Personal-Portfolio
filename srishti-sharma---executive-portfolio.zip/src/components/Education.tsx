import React from 'react';
import {
  GraduationCap,
  Award,
  Calendar,
  MapPin,
  Cpu,
  Binary,
  CheckCircle2,
} from 'lucide-react';
import { EDUCATION_DATA } from '../data/portfolioData';

export const Education: React.FC = () => {
  return (
    <section id="education" className="relative py-20 bg-[#000000] border-t border-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-center gap-3 text-xs font-mono tracking-widest uppercase text-neutral-500 mb-2">
          <span>// 08 · ACADEMIC FOUNDATION</span>
          <span className="w-8 h-px bg-neutral-800" />
          <span>ENGINEERING DISCIPLINE</span>
        </div>
        <h2 className="text-6xl sm:text-7xl md:text-8xl font-extrabold uppercase tracking-tight text-white font-['Bebas_Neue',sans-serif] leading-none mb-10">
          EDUCATION & ACADEMICS
        </h2>

        {/* Technical Blueprint Education Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#131520] to-[#0e1017] border border-neutral-800 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          {/* Subtle circuit background lines */}
          <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
            <Cpu className="w-48 h-48 text-neutral-200" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
            {/* Left: Institution and Degree */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex flex-wrap items-center gap-3">
                <span className="px-3 py-1 rounded bg-neutral-900 border border-neutral-700 text-xs font-mono text-neutral-300 flex items-center gap-1.5">
                  <GraduationCap className="w-4 h-4 text-neutral-400" />
                  BACHELOR OF ENGINEERING
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs font-mono font-bold flex items-center gap-1">
                  <Award className="w-3.5 h-3.5" />
                  {EDUCATION_DATA.gpa}
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Syne',sans-serif]">
                {EDUCATION_DATA.institution}
              </h3>

              <div className="text-sm font-mono text-neutral-300">
                {EDUCATION_DATA.degree}
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-neutral-500 pt-1">
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-neutral-500" />
                  {EDUCATION_DATA.period}
                </span>
                <span className="text-neutral-700">/</span>
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-neutral-500" />
                  {EDUCATION_DATA.location}
                </span>
              </div>

              <p className="text-neutral-300 text-sm leading-relaxed pt-2">
                A rigorous double-discipline foundation spanning computer architecture, algorithms, digital signal systems, and electronics engineering. This formal technical grounding enables direct, peer-level collaboration with software architects, quants, and systems engineers.
              </p>
            </div>

            {/* Right: Technical Focus Points */}
            <div className="lg:col-span-5 p-6 rounded-xl bg-neutral-950/70 border border-neutral-800/80 space-y-3">
              <span className="text-xs font-mono text-neutral-400 uppercase tracking-wider block flex items-center gap-1.5">
                <Binary className="w-4 h-4 text-neutral-400" />
                Key Academic Highlights:
              </span>
              <div className="space-y-2.5">
                {EDUCATION_DATA.highlights.map((highlight, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-neutral-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{highlight}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
