import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Sparkles } from 'lucide-react';

interface NavbarProps {
  onContactClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onContactClick }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      const sections = ['home', 'about', 'experience', 'why-me', 'value', 'constellation', 'projects', 'skills', 'education', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 200 && rect.bottom >= 200) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'HOME', href: '#home', id: 'home' },
    { label: 'ABOUT', href: '#about', id: 'about' },
    { label: 'EXPERIENCE', href: '#experience', id: 'experience' },
    { label: 'WHY ME', href: '#why-me', id: 'why-me' },
    { label: 'PROJECTS', href: '#projects', id: 'projects' },
    { label: 'SKILLS', href: '#skills', id: 'skills' },
    { label: 'CONTACT', href: '#contact', id: 'contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-4 sm:px-6 lg:px-8 py-4 ${
        scrolled ? 'py-3' : 'py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <nav
          className={`flex items-center justify-between rounded-full px-4 sm:px-6 py-2 transition-all duration-300 border ${
            scrolled
              ? 'bg-white/95 backdrop-blur-md border-neutral-300 shadow-xl shadow-black/8'
              : 'bg-white/90 backdrop-blur-md border-neutral-300/80 shadow-xs'
          }`}
        >
          {/* Brand Logo & Full Executive Title */}
          <a
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="flex items-center gap-2.5 sm:gap-3 group shrink-0 min-w-0"
            id="brand-logo"
          >
            <div className="w-8 h-8 rounded-lg bg-black text-white flex items-center justify-center font-extrabold text-xs font-mono tracking-wider transition-transform duration-300 group-hover:scale-105 shadow-xs shrink-0">
              SS
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs tracking-wider uppercase font-black text-neutral-950 font-mono leading-tight">
                SRISHTI SHARMA
              </span>
              <span className="text-[9.5px] sm:text-[10px] text-neutral-700 font-mono font-semibold tracking-tight truncate max-w-[200px] sm:max-w-[340px] md:max-w-[420px] lg:max-w-none">
                Technical Account Manager &amp; Financial Markets SME | AI &amp; Product Delivery
              </span>
            </div>
          </a>

          {/* Desktop Links with editorial slashes */}
          <div className="hidden xl:flex items-center gap-1 text-[11px] font-mono tracking-wider text-neutral-700 font-medium shrink-0">
            {navLinks.map((link, index) => {
              const isActive = activeSection === link.id;
              return (
                <React.Fragment key={link.href}>
                  {index > 0 && <span className="text-neutral-400 select-none px-1.5">/</span>}
                  <a
                    href={link.href}
                    onClick={(e) => handleNavClick(e, link.href)}
                    className={`px-2 py-1 rounded-full transition-colors duration-200 ${
                      isActive
                        ? 'text-black font-bold bg-neutral-100'
                        : 'hover:text-black hover:bg-neutral-100/60'
                    }`}
                  >
                    {link.label}
                  </a>
                </React.Fragment>
              );
            })}
          </div>

          {/* CTA Button matching reference image's capsule 'HIRE ME' with crisp thin border */}
          <div className="flex items-center gap-3">
            <button
              onClick={onContactClick}
              id="nav-hire-me-btn"
              className="group relative inline-flex items-center gap-1.5 px-5 py-1.5 rounded-full border border-neutral-900 bg-white text-neutral-950 text-xs font-bold tracking-wider uppercase transition-all duration-300 hover:bg-neutral-950 hover:text-white active:scale-95"
            >
              <span>HIRE ME</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              id="mobile-menu-toggle"
              aria-label="Toggle Navigation Menu"
              className="lg:hidden p-1.5 rounded-full text-neutral-700 hover:text-black hover:bg-neutral-100 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </nav>

        {/* Mobile dropdown */}
        {mobileMenuOpen && (
          <div
            id="mobile-nav-panel"
            className="lg:hidden mt-2 p-4 rounded-2xl bg-white/95 backdrop-blur-xl border border-neutral-200 shadow-2xl flex flex-col gap-2 animate-in fade-in slide-in-from-top-2 duration-200"
          >
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-4 py-2.5 rounded-lg text-xs font-mono tracking-wider text-neutral-800 hover:text-black hover:bg-neutral-100 transition-colors flex items-center justify-between font-medium"
              >
                <span>{link.label}</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-neutral-500" />
              </a>
            ))}
          </div>
        )}
      </div>
    </header>
  );
};
