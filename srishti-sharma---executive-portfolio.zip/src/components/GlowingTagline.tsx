import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface Pillar {
  id: string;
  number: string;
  lead: string;
  rest: string;
  sub: string;
  gradient: string;
  glowFilter: string;
  badgeBg: string;
}

export const GlowingTagline: React.FC = () => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [activeIdx, setActiveIdx] = useState<number>(0);

  const pillars: Pillar[] = [
    {
      id: 'curious',
      number: '01',
      lead: 'Curious',
      rest: 'enough to question.',
      sub: 'Challenging legacy assumptions & deep domain discovery',
      gradient: 'from-amber-400 via-orange-400 to-amber-500',
      glowFilter: 'drop-shadow-[0_0_24px_rgba(251,191,36,0.65)] drop-shadow-[0_0_40px_rgba(249,115,22,0.35)]',
      badgeBg: 'bg-amber-500/15 text-amber-900 border-amber-500/30',
    },
    {
      id: 'strategic',
      number: '02',
      lead: 'Strategic',
      rest: 'enough to simplify.',
      sub: 'Translating complex multi-asset workflows into clear roadmaps',
      gradient: 'from-orange-500 via-amber-500 to-rose-500',
      glowFilter: 'drop-shadow-[0_0_24px_rgba(249,115,22,0.7)] drop-shadow-[0_0_42px_rgba(244,63,94,0.35)]',
      badgeBg: 'bg-orange-500/15 text-orange-950 border-orange-500/30',
    },
    {
      id: 'determined',
      number: '03',
      lead: 'Determined',
      rest: 'enough to deliver.',
      sub: 'Relentless production ownership from discovery to deployment',
      gradient: 'from-rose-500 via-red-500 to-orange-500',
      glowFilter: 'drop-shadow-[0_0_24px_rgba(244,63,94,0.65)] drop-shadow-[0_0_40px_rgba(239,68,68,0.35)]',
      badgeBg: 'bg-rose-500/15 text-rose-950 border-rose-500/30',
    },
  ];

  // Ambient gentle rhythm cycling through the glow if not user-hovered
  useEffect(() => {
    if (hoveredIdx !== null) return;
    const interval = setInterval(() => {
      setActiveIdx((prev) => (prev + 1) % pillars.length);
    }, 3500);
    return () => clearInterval(interval);
  }, [hoveredIdx, pillars.length]);

  return (
    <div className="space-y-3 relative group/container select-none">
      {/* Editorial Category Eyebrow with Live Pulsing Energy Beacon */}
      <div className="flex items-center gap-2">
        <span className="relative flex h-2 w-2">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500" />
        </span>
        <span className="text-[11px] font-mono tracking-widest uppercase text-neutral-800 font-bold">
          PHILOSOPHY & OPERATING PRINCIPLE
        </span>
      </div>

      {/* The 3 Interactive Glowing Pillars */}
      <div className="space-y-2 pt-1">
        {pillars.map((pillar, idx) => {
          const isCurrent = (hoveredIdx !== null ? hoveredIdx === idx : activeIdx === idx);

          return (
            <motion.div
              key={pillar.id}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              onClick={() => setActiveIdx(idx)}
              className="relative cursor-pointer transition-all duration-300"
              whileHover={{ x: 4 }}
            >
              {/* Main Typography Statement */}
              <div className="flex items-baseline gap-x-2.5">
                {/* Glowing Highlighted Keyword */}
                <span
                  className={`text-2xl sm:text-3xl lg:text-[33px] font-black tracking-tight leading-tight font-['Syne',sans-serif] transition-all duration-300 ${
                    isCurrent
                      ? `text-transparent bg-clip-text bg-gradient-to-r ${pillar.gradient} ${pillar.glowFilter} scale-[1.01]`
                      : 'text-neutral-950 hover:text-orange-950'
                  }`}
                >
                  {pillar.lead}
                </span>

                {/* Suffix Text */}
                <span
                  className={`text-2xl sm:text-3xl lg:text-[33px] font-extrabold tracking-tight leading-tight font-['Syne',sans-serif] transition-colors duration-300 ${
                    isCurrent ? 'text-neutral-950' : 'text-neutral-900/80'
                  }`}
                >
                  {pillar.rest}
                </span>
              </div>

              {/* Micro Insight Badge on Hover / Active */}
              <div className="min-h-[22px] flex items-center mt-0.5">
                {isCurrent && (
                  <motion.div
                    initial={{ opacity: 0, y: -2 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`inline-flex items-center gap-1.5 text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full border ${pillar.badgeBg}`}
                  >
                    <span>{pillar.number}</span>
                    <ArrowRight className="w-2.5 h-2.5" />
                    <span>{pillar.sub}</span>
                  </motion.div>
                )}
              </div>

              {/* Luminous Accent Underline on Active / Hover */}
              {isCurrent && (
                <motion.div
                  layoutId="glowingUnderline"
                  className={`h-[2px] w-24 sm:w-44 mt-1 rounded-full bg-gradient-to-r ${pillar.gradient} shadow-[0_0_12px_rgba(249,115,22,0.8)]`}
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
