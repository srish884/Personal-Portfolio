import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutPhilosophy } from './components/AboutPhilosophy';
import { Experience } from './components/Experience';
import { WhyMe } from './components/WhyMe';
import { ValueProposition } from './components/ValueProposition';
import { Constellation } from './components/Constellation';
import { Projects } from './components/Projects';
import { Skills } from './components/Skills';
import { Education } from './components/Education';
import { ContactFooter } from './components/ContactFooter';

export default function App() {
  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0c10] text-[#e0e2ec] flex flex-col font-sans selection:bg-neutral-100 selection:text-neutral-950">
      {/* Sticky Capsule Navigation */}
      <Navbar onContactClick={() => scrollToSection('contact')} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Section 01: Hero / Editorial Silhouette & Massive Typography */}
        <Hero
          onProjectsClick={() => scrollToSection('projects')}
          onExperienceClick={() => scrollToSection('experience')}
          onContactClick={() => scrollToSection('contact')}
        />

        {/* Section 02: About / Personal Philosophy */}
        <AboutPhilosophy />

        {/* Section 03: Professional Experience (ION Group & Tier 1 Banks) */}
        <Experience />

        {/* Section 04: "Why Companies Keep Me Around" Signature Section */}
        <WhyMe />

        {/* Section 05: "The Value I Bring" 8-Card Matrix */}
        <ValueProposition />

        {/* Section 06: "If You Hire Me, You're Not Getting One Person." Interconnected Constellation */}
        <Constellation />

        {/* Section 07: "Things I've Built" - Substantial Case Studies with Architecture Flow */}
        <Projects />

        {/* Section 08: Skills Ecosystem with Search and Category Filtering */}
        <Skills />

        {/* Section 09: Education & Academics (Thapar Institute of Eng. & Tech.) */}
        <Education />
      </main>

      {/* Section 10: Closing Manifesto & Contact Hub */}
      <ContactFooter />
    </div>
  );
}
